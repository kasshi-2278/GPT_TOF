#!/usr/bin/env python3
"""Local browser UI and headless launcher for the unmodified sonic program."""
import argparse
import ast
import base64
import copy
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import multiprocessing as mp
import os
from pathlib import Path
import secrets
import sys
import threading
import time
import urllib.parse
import webbrowser
import engine

ROOT = Path(__file__).resolve().parent
PROGRAMS = ROOT / 'programs'
RESULTS = ROOT / 'results'

class Session:
    def __init__(self):
        self.lock = threading.RLock()
        self.ctx = mp.get_context('spawn')
        self.process = None
        self.conn = None
        self.run_id = 0
        self.frame = None
        self.trail = []
        self.summary = None
        self.error = None
        self.out_dir = None
        self.course = engine.make_course(engine.DEFAULTS['course'])
        self.config = copy.deepcopy(engine.DEFAULTS)
        self.program = 'sonic_drive_v23_log_on_stop.py'
        self.sha256 = None
        self.saved = False
        self.version = 0
        self.started = False

    def programs(self):
        entries = []
        PROGRAMS.mkdir(exist_ok=True)
        for path in sorted(PROGRAMS.glob('*.py')):
            if path.resolve().parent != PROGRAMS.resolve():
                continue
            entries.append({'name': path.name, 'size': path.stat().st_size,
                            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        return entries

    def resolve_program(self, name):
        path = (PROGRAMS / str(name)).resolve()
        if path.parent != PROGRAMS.resolve() or path.suffix.lower() != '.py' or not path.is_file():
            raise ValueError('programsフォルダー内のPythonファイルを選んでください。')
        return path

    def stop(self):
        with self.lock:
            process, conn = self.process, self.conn
        if process and process.is_alive():
            try:
                conn.send({'cmd': 'stop'})
            except (OSError, EOFError, BrokenPipeError):
                pass
            process.join(timeout=3)
            if process.is_alive():
                process.terminate()
                process.join(timeout=2)
        return True

    def start(self, name, settings):
        program = self.resolve_program(name)
        config = engine.validate_config(settings)
        # Reject invalid poses before replacing the current run.
        engine.World(config)
        self.stop()
        parent, child = self.ctx.Pipe(duplex=True)
        out = RESULTS / (time.strftime('%Y%m%d_%H%M%S') + '_' + secrets.token_hex(3))
        with self.lock:
            self.run_id += 1
            run_id = self.run_id
            self.conn = parent
            self.config = config
            self.course = config['custom_course'] or engine.make_course(config['course'])
            self.frame = self.summary = self.error = None
            self.trail = []
            self.program = name
            self.sha256 = hashlib.sha256(program.read_bytes()).hexdigest()
            self.out_dir = str(out.relative_to(ROOT))
            self.saved = False
            self.started = True
            self.version += 1
            self.process = self.ctx.Process(target=engine.worker, args=(str(program), config, child, str(out)), daemon=True)
            self.process.start()
            process = self.process
        child.close()
        threading.Thread(target=self.collect, args=(run_id, parent, process), daemon=True).start()
        return {'ok': True, 'run_id': run_id}

    def collect(self, run_id, conn, process):
        try:
            while True:
                if not conn.poll(0.25):
                    if not process.is_alive():
                        break
                    continue
                message = conn.recv()
                with self.lock:
                    if run_id != self.run_id:
                        continue
                    kind = message['type']
                    if kind == 'begin':
                        self.course = message['course']
                        self.sha256 = message['sha256']
                    elif kind == 'frame':
                        self.frame = message['frame']
                        f = self.frame
                        p = [f['x'], f['y'], f['t'], f['speed']]
                        if not self.trail or ((p[0] - self.trail[-1][0])**2 + (p[1] - self.trail[-1][1])**2 >= 1):
                            self.trail.append(p)
                            if len(self.trail) > 5000:
                                self.trail = self.trail[::2]
                    elif kind == 'done':
                        self.summary = message['summary']
                    elif kind == 'saved':
                        self.saved = True
                    elif kind == 'error':
                        self.error = message['error']
                    self.version += 1
        except (EOFError, OSError):
            pass
        finally:
            conn.close()
            with self.lock:
                if run_id == self.run_id and not self.summary and not self.error:
                    self.error = '実行プロセスが終了しました。プログラムのエラー、または強制停止を確認してください。'
                    self.version += 1

    def control(self, command, value=None):
        if command not in ('pause', 'resume', 'step', 'stop', 'speed'):
            raise ValueError('Unknown control command')
        with self.lock:
            if not self.process or not self.process.is_alive() or not self.conn:
                raise ValueError('実行中ではありません。「開始」を押してください。')
            message = {'cmd': command}
            if command == 'speed':
                message['value'] = float(value)
                if not 0 <= message['value'] <= 50:
                    raise ValueError('Invalid playback speed')
            self.conn.send(message)
        return {'ok': True}

    def state(self):
        with self.lock:
            return {'run_id': self.run_id, 'version': self.version, 'frame': self.frame,
                    'trail': list(self.trail), 'summary': self.summary, 'error': self.error,
                    'course': self.course, 'program': self.program, 'sha256': self.sha256,
                    'config': self.config, 'out_dir': self.out_dir, 'saved': self.saved,
                    'started': self.started, 'alive': bool(self.process and self.process.is_alive())}

class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    @property
    def session(self):
        return self.server.session

    def send_bytes(self, data, ctype, code=200, filename=None):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'")
        if filename:
            self.send_header('Content-Disposition', 'attachment; filename="{}"'.format(filename))
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def json_response(self, obj, code=200):
        self.send_bytes(json.dumps(obj, ensure_ascii=False, allow_nan=False).encode('utf-8'), 'application/json; charset=utf-8', code)

    def host_ok(self):
        host = self.headers.get('Host', '')
        return host in ('127.0.0.1:{}'.format(self.server.server_port), 'localhost:{}'.format(self.server.server_port))

    def do_GET(self):
        if not self.host_ok():
            return self.json_response({'error': 'Local host required'}, 403)
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        try:
            if path == '/':
                text = (ROOT / 'web/index.html').read_text(encoding='utf-8').replace('__TOKEN__', self.server.token)
                self.send_bytes(text.encode('utf-8'), 'text/html; charset=utf-8')
            elif path == '/log-viewer':
                self.send_bytes((ROOT / 'web/log_viewer.html').read_bytes(), 'text/html; charset=utf-8')
            elif path in ('/app.js', '/style.css', '/drive_log_data.js',
                          '/log_viewer.js', '/log_viewer.css'):
                p = ROOT / 'web' / path.lstrip('/')
                ctype = 'text/javascript; charset=utf-8' if p.suffix == '.js' else 'text/css; charset=utf-8'
                self.send_bytes(p.read_bytes(), ctype)
            elif path == '/api/meta':
                self.json_response({'defaults': engine.DEFAULTS, 'programs': self.session.programs(),
                                    'courses': [engine.make_course(k) for k in engine.COURSE_IDS]})
            elif path == '/api/state':
                self.json_response(self.session.state())
            elif path == '/api/download':
                kind = urllib.parse.parse_qs(parsed.query).get('kind', ['summary'])[0]
                filenames = {'summary': 'summary.json', 'csv': 'telemetry.csv', 'pwm': 'pwm_events.csv',
                             'log': 'program_output.txt', 'replay': 'replay.json',
                             'visual': 'visual_log.html'}
                if kind not in filenames:
                    raise ValueError('Unknown download type')
                state = self.session.state()
                if not state['saved'] or not state['out_dir']:
                    raise ValueError('終了後にログが保存されます。')
                file = ROOT / state['out_dir'] / filenames[kind]
                self.send_bytes(file.read_bytes(), 'application/octet-stream', filename=filenames[kind])
            else:
                self.json_response({'error': 'Not found'}, 404)
        except (ValueError, OSError) as e:
            self.json_response({'error': str(e)}, 400)

    def do_POST(self):
        if not self.host_ok() or self.headers.get('X-Sim-Token') != self.server.token:
            return self.json_response({'error': 'Local session token required'}, 403)
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 4000000:
                raise ValueError('Request size must be between 1 byte and 4 MB')
            data = json.loads(self.rfile.read(length))
            if self.path == '/api/start':
                result = self.session.start(data['program'], data.get('config', {}))
            elif self.path == '/api/control':
                result = self.session.control(data['cmd'], data.get('value'))
            elif self.path == '/api/upload':
                # Copy original bytes, never rewrite or overwrite an existing source.
                name = str(data['name']).replace('\\', '/').split('/')[-1]
                if not name.lower().endswith('.py') or name in ('.py', '..py') or any(ord(c) < 32 or c in '<>:\x22|?*' for c in name):
                    raise ValueError('Python (.py) ファイルを選んでください。')
                raw = base64.b64decode(data['base64'], validate=True)
                if len(raw) > 2000000:
                    raise ValueError('Python file limit: 2 MB')
                ast.parse(raw, filename=name)
                sha = hashlib.sha256(raw).hexdigest()
                path = PROGRAMS / name
                if path.exists() and path.read_bytes() != raw:
                    path = PROGRAMS / (Path(name).stem + '_' + sha[:10] + '.py')
                if not path.exists():
                    path.write_bytes(raw)
                result = {'ok': True, 'name': path.name, 'sha256': sha, 'programs': self.session.programs()}
            else:
                return self.json_response({'error': 'Not found'}, 404)
            self.json_response(result)
        except (ValueError, KeyError, TypeError, OSError, SyntaxError) as e:
            self.json_response({'error': str(e)}, 400)


def main():
    parser = argparse.ArgumentParser(description='PC simulation; original sonic source is not edited')
    parser.add_argument('--headless', action='store_true', help='Run without a browser; write CSV/JSON logs')
    parser.add_argument('--program', help='Path to the ORIGINAL trusted .py (headless) or name in programs/')
    parser.add_argument('--course', choices=engine.COURSE_IDS, default=None)
    parser.add_argument('--seconds', type=float, default=None)
    parser.add_argument('--config', help='JSON configuration path; changes the simulator only')
    parser.add_argument('--out', default=str(RESULTS / 'headless'))
    parser.add_argument('--port', type=int, default=8765, help='localhost port; 0 selects an unused port')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if sys.version_info < (3, 8):
        parser.error('Python 3.8 or newer is required')
    config = {}
    if args.config:
        config.update(json.loads(Path(args.config).read_text(encoding='utf-8-sig')))
    if args.course:
        config['course'] = args.course
    if args.seconds:
        config['seconds'] = args.seconds
    if args.headless:
        config['realtime'] = 0
        program = Path(args.program) if args.program else PROGRAMS / 'sonic_drive_v23_log_on_stop.py'
        if not program or not program.is_file():
            parser.error('No program found. Add your .py to programs/ or use --program PATH')
        result = engine.execute(program, config)
        engine.save_result(result, args.out)
        print(json.dumps(result['summary'], ensure_ascii=False, indent=2))
        return 1 if result['summary']['error'] else 0
    session = Session()
    if config:
        session.config = engine.validate_config(config)
        session.course = session.config['custom_course'] or engine.make_course(session.config['course'])
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    except OSError:
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.session = session
    server.token = secrets.token_urlsafe(32)
    url = 'http://127.0.0.1:{}/'.format(server.server_port)
    print('\nSONIC PC SIMULATOR / original program unchanged\n')
    print('Open in your browser: ' + url)
    print('Compatibility geometric model; later HC-SR04 acoustic model is NOT restored. Only run trusted Python programs.')
    print('Ctrl+C stops the server. Simulation never connects to GPIO hardware.\n')
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping...')
    finally:
        session.stop()
        server.server_close()
    return 0

if __name__ == '__main__':
    mp.freeze_support()
    raise SystemExit(main())
