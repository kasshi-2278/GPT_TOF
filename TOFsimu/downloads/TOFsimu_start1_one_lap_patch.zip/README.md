# TOFsimu

既存の `rc_simulator_v5` とは独立したフォルダです。古いZIPから不足していた実行基盤を補い、コース形状と開始位置プリセットを維持しています。現在の初期位置はスタート1です。

## 開く

- Windows: `START_WINDOWS.bat`
- macOS/Linux: `./START_MAC_LINUX.sh`
- 保存済み走行の再生: `restored.html` をブラウザで開く
- [新しい軌跡画像](trajectory_restored_v16.png)

画面はスタート1と `programs/sonic_drive_v23_log_on_stop.py` を初期選択します。停止後ログを保存する実機用プログラムを、そのまま仮想GPIO/PWM環境で動かします。

スタート1の1周判定用にコースへ4つの仮想ゲートを追加しました。ゲートは計測だけに使い、走行判断へは渡しません。位置は図面からの近似です。

**後期HC-SR04音響モデルは未復元です。** 旧版の幾何射線による互換実行と、元の音響条件は区別しています。[補完内容・起動方法・制限](RESTORATION_JA.md)を参照してください。実機の完走は未検証です。

## 保存している過去の記録

- `trial_results/`: 元の結果ZIP全22ファイルの原本
- `programs/sonic_drive_smooth_v13_direction_safety.py`: 添付走行プログラムの原本
- `index.html`, `trajectory.png`: 元v13の保存済み試験
- `closed_loop.py`, `v16.html`, `trajectory_v16.png`: 前回作成した独立簡易モデルとその結果
- v14〜v16の判断コード・検証文書

`configs/current_trial.json` は元試験設定、`configs/current_course.json` は現行コース、`IMPORT_MANIFEST.json` は古いZIPからの取込記録です。

## 最適化の比較候補v18

[v18の変更・比較・トレードオフ](V18_JA.md)。同じ互換モデルで1周109.82秒→104.69秒、操舵変動約8.3%減を確認しました。ただし最小壁間隔が4.65cm→3.81cmになり、広いビームでの停止も未解決だったため、当時はv17を初期選択にしていました。v18は比較用に選択できます。

[▶ v18の等速走行動画](videos/v18_optimized_one_lap.mp4)

## 下側への寄り込みを抑えるv19

[v19の変更・検証](V19_JA.md)。駐車枠の凹みを追わず、観測できる左壁との間隔を保つ判断を追加しました。同じ互換モデルで下側の最小壁間隔7.29cm→44.87cm、約103.55秒で1周相当を確認しました。低速条件・広いビームと実機の検証課題は残るため、当時はv17を初期選択にしていました。

[▶ v19とv18の比較動画](videos/v19_wall_clearance_one_lap.mp4)

## GapFinder＋Pure Pursuitの比較版v20

[v20の実装内容と比較結果](V20_JA.md)。10cmヒステリシス、最遠＋隣接面積按分、車体余裕チェック、Pure Pursuitをカーブ補助として追加しました。GPIO/PWM設定と狭路の指令30は維持しています。同条件では1周103.87秒、接触0ですが、v19の103.55秒より速くはなっていません。比較用として追加しました。

[▶ v20とv19の比較動画](videos/v20_gap_pursuit_one_lap.mp4)

## ショートカットの寄り込みを抑えるv21

[v21の変更・検証](V21_JA.md)。壁端で右へ切り込むタイミングと通過後の旋回方向を修正しました。同じモデルでショートカットの最小車体壁間隔3.29cm→12.46cm、約104.25秒で1周相当、160秒間の接触0を確認しました。GPIO/PWM初期設定と狭路のアクセル指令30は維持しています。低速・広いビームと実機は検証課題が残ります。

[▶ v21の比較動画](videos/v21_shortcut_clearance_one_lap.mp4) / [壁端の拡大比較](videos/v21_shortcut_comparison.png) / [走行プログラム](programs/sonic_drive_smooth_v21_shortcut_clearance.py)

## 1周の走行距離を短縮するv22

[v22の変更・検証](V22_JA.md)。左側の開きを確認したカーブで旋回を早め、ショートカットの方向継続も修正しました。同じモデルで1周28.53m→27.69m（約3.0%短縮）、104.25秒→101.39秒。ショートカットの最小車体壁間隔は12.46cm→24.31cmです。GPIO/PWM初期設定と狭路のアクセル指令30は維持しています。数学的な最短の保証ではなく、半角12度での停止と実機未検証の制限があります。

[▶ v22の比較動画](videos/v22_shorter_lap_one_lap.mp4) / [軌跡画像](videos/v22_distance_comparison.png) / [走行プログラム](programs/sonic_drive_smooth_v22_shorter_lap.py)

## 図付き走行ログ

`log_viewer.html` をブラウザで開くと、実機のTXTログから車体図・5センサーの測距・操舵・アクセル・元の出力を記録順に再生できます。実機の位置や軌跡は推定しません。シミュレータの `replay.json` では保存済みの軌跡とログを時刻に合わせて表示します。

走行終了後は「図付きログHTML」ボタン、または保存先の `visual_log.html` を使ってください。HTMLは単独で開き直せます。[使い方](VISUAL_LOGS_JA.md)

実機走行を止めた後に判断を分析するには [`sonic_drive_v23_log_on_stop.py`](programs/sonic_drive_v23_log_on_stop.py) を使います。Ctrl+Cで停止すると、各制御周期の測距・判断・操舵/スロットルPWMを `drive_trace_日時.jsonl` と `drive_log_日時.txt` に保存し、場所を端末に表示します。JSONLには実行したプログラムのSHA256と制御内部値も入るため、修正時はJSONLをこのチャットに添付してください。TXTはログビューアーで図示できます。実機の位置・車体角度は測定していません。

送付されたログで見えた短周期の切り返しを抑えるため、距離フィルターを維持し、旋回解除を最低0.12秒・2回連続の確認にしました。ログのセンサー列で判断を再生した比較では操舵総変化量が約35%減り、強い符号反転は6回から3回に減りました。GPIO/PWM初期設定・実機入出力は元v23から変えていません。

## スタート1の1周確認

スタート1から4ゲートを順番に通過して戻る1周を確認しました。60秒上限で51.69秒に完走し、接触0・後退0回です。[走行リプレイ](exports/start1_one_lap.html) 再現コマンドは `python3 simulator.py --headless --config configs/legacy_geometric.json --seconds 60 --out results/start1_one_lap` です。コース・ゲートは図面からの近似です。旧幾何モデルの結果であり、後期HC-SR04音響モデルと実機の動作は未検証です。ダウンロード版は [`downloads/README.md`](downloads/README.md) にあります。
