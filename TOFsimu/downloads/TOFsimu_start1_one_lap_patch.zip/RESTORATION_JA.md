# 古いZIPから不足していた実行基盤だけを補完

## 取り込んだ部分

`sonic_pc_simulator_wall_removed.zip` から以下だけを使用しました。

- `engine.py` → `legacy_runtime/engine.py`（原本のまま）
- `simulator.py` → `simulator.py`（現行構成への起動調整）
- `web/index.html`, `web/app.js`, `web/style.css` → `web/`（表示と開始位置の説明を現行化）

古いv12走行プログラム、古い結果、古い設定・コースは取り込んでいません。取込元とSHA-256は `IMPORT_MANIFEST.json` に記録しています。既存のrc_simulator_v5、添付v13、修正版v14〜v16、過去の試験原本は変更していません。

新しい `engine.py` は互換アダプタです。現在のコースと設定を渡して旧実行基盤を呼び出します。`main()`、Mesure、仮想GPIO、PCA9685、PWM換算、出力時間、車体運動まで実行します。走行プログラムの書換えやコントローラの差替えはしません。

## 維持した内容と未復元の内容

`configs/current_course.json` は、これまで使っていた `trial_results/run/replay.json` のcourseです。壁31本・開口・駐車枠・開始位置プリセットを維持しています。現在の初期位置はスタート1（後車軸x=330.78cm、y=169.41cm、右向き0度）です。図面に合わせた周回計測用の仮想ゲートを追加しています。

`configs/current_trial.json` は元の試験config.jsonのバイト単位のコピーです。現在の全設定を保存しています。

**古いZIPには後期の `sensor_model: hcsr04` 実装がありません。** 反射強度・入射角・温度・HIGHタイムアウトなどを再現できません。したがって、この設定をそのまま指定した場合は、黙って無視せずエラーにします。

`configs/legacy_geometric.json` は明示的な互換プロファイルです。現在と共通する物理・車体・センサー取付・GPIO/PWM対応・開始位置・試験上限などを維持し、旧版の幾何射線モデルを選びます。上位のbeam_half_angle_deg=0、sensor_noise_cm=0も現在の共通設定どおりです。後期モデルの半角12度等が再現されたという意味ではありません。

`configs/legacy_beam12_comparison.json` は旧版の簡易5射線ビームを12度にした比較用です。これも後期音響モデルとは別物です。

## 開き方

Windows: `START_WINDOWS.bat`

macOS/Linux: `./START_MAC_LINUX.sh`

またはTOFsimuフォルダで:

```sh
python3 simulator.py --config configs/legacy_geometric.json
```

Python 3.8以降・標準ライブラリで動作します。画面の初期選択はログ付きv23走行プログラムとスタート1です。標準の実行上限60秒で1周できます。

再計算せず保存済みの軌跡を開く場合は `restored.html` をブラウザで直接開いてください。

## 再実行結果

v16を、保持した現行コース・理想幾何射線・上限160秒で実行しました。

- main・測距・仮想GPIO/PWMまで実行し、原本SHA-256は実行前後一致
- 160秒で41.09m走行、接触0、プログラムエラーなし
- 約109.40秒・約28.3mに1周相当の通過順序を確認
- 当時の元コースはゲート未設定だったため、エンジンのlaps/finishedは0

この記録時点では、1周相当を「右上→左上→左下→開始xを右向きに通過」の順に実行後の軌跡で評価していました。現在は図面上の推定位置に4つの仮想ゲートを設け、エンジンが周回数を記録します。ゲートは評価専用で、走行判断へは入力されません。

再現コマンド:

```sh
python3 simulator.py --headless --program programs/sonic_drive_smooth_v16_wall_follow.py --config configs/legacy_geometric.json --seconds 160 --out results/restored_v16
python3 evaluate_lap.py results/restored_v16/replay.json
```

結果は `results/restored_v16/`、1周の画像は `trajectory_restored_v16.png`、160秒のリプレイは `restored.html` です。元v13も同じ互換モードで実行し、31.62秒に接触終了しました（`results/restored_v13/`）。これらは後期音響条件の再現試験ではありません。以前のv13試験・独立簡易モデルの結果はそのまま残しています。

現在のログ付き走行プログラムも、スタート1から4ゲートを通過して1周を完了しました。51.69秒、接触0、後退0回です。リプレイは `exports/start1_one_lap.html` です。再現するには `python3 simulator.py --headless --config configs/legacy_geometric.json --seconds 60 --out results/start1_one_lap` を実行してください。

## 確認範囲

全19テスト成功。取込元エンジンのハッシュ一致、現行コース・開始位置・共通設定の保持、音響設定の誤適用防止、main/GPIO/PWM実行、原本不変、従来の判断テストを含みます。JS構文確認済みです。

この作業環境ではローカルサーバーのソケット作成が禁止されており、ブラウザUIのサーバー起動は確認できていません。ヘッドレス実行と出力保存は確認済みです。
