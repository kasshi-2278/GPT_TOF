TOFsimu（現在使っていた実行基盤・現行コース）

ZIPを解凍し、TOFsimuフォルダを開いてください。
Windows: START_WINDOWS.bat
ラズパイ/macOS/Linux: ターミナルで sh START_MAC_LINUX.sh
または python3 simulator.py --config configs/legacy_geometric.json
Python 3.8以降が必要です。シミュレータ本体は標準ライブラリで動きます。
ブラウザが開かない場合はターミナルに表示されるURLを開いてください。

画面の初期選択は従来のv17です。
戻した実機用コードを試す場合は sonic_drive_restored_v23.py を選択してください。
アクセル60・後退上限999を含め、送ってもらった実機v23と同一です。
v24の修正案は同梱していません。
1周確認時は実行時間を160秒に変更してください。

保存済みの走行を再生する場合は restored.html をブラウザで開いてください。
これは以前のv16の保存記録であり、現在選択したプログラムの再計算ではありません。

現行コースは維持しています。古いZIPから補ったのは不足していた実行基盤です。
幾何射線モデルによる互換実行です。後期HC-SR04音響モデルは未復元で、実機の動作保証ではありません。
configs/current_trial.jsonは原本保存用であり、この実行基盤ではその音響設定を再現できません。
起動には configs/legacy_geometric.json を使用してください。

大量の試験結果・動画・最適化探索・キャッシュは省略しています。
収録ファイルとSHA256は PACKAGE_MANIFEST.json を参照してください。
