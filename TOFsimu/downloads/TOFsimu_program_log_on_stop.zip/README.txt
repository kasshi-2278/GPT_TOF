v23 drive program with run log saved when stopped

File: sonic_drive_v23_log_on_stop.py

On the Raspberry Pi, open a terminal in the folder containing the file and run:
  python3 sonic_drive_v23_log_on_stop.py

Press Enter to start the run. Press Ctrl+C in that terminal to stop. After the
program centers the steering and stops the throttle, it finishes a UTF-8 text
log named drive_log_YYYYMMDD_HHMMSS_microseconds.txt in the current folder and
prints its full path. The file contains the same sensor, steering, throttle,
cycle, and decision lines shown during the run, plus the stop reason, duration,
and number of records. Open that .txt file with TOFsimu/log_viewer.html to see
the real-run readings as a diagram.

This is the restored v23 program with log-file output added. Its GPIO, sensor,
and PWM initialization values are unchanged. This source has not been run on
the actual RC car; test it with the vehicle safely supported before driving.
