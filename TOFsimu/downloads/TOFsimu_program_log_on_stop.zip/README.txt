v23 drive program with run log saved when stopped

File: sonic_drive_v23_log_on_stop.py

On the Raspberry Pi, open a terminal in the folder containing the file and run:
  python3 sonic_drive_v23_log_on_stop.py

Press Enter to start the run. Press Ctrl+C in that terminal to stop. After the
program centers the steering and stops the throttle, it saves two files in the
current folder and prints their full paths:

- drive_log_YYYYMMDD_HHMMSS_microseconds.txt: every sensor/control cycle in a
  readable format. Open it with TOFsimu/log_viewer.html to see the readings as
  a diagram.
- drive_trace_YYYYMMDD_HHMMSS_microseconds.jsonl: structured details for every
  cycle, including raw sensor distances, controller decisions and debug values,
  steering/throttle PWM commands, reverse pulse timing, monotonic timestamps,
  program SHA256, sensor pins, and PWM setup. Attach this file to the chat for
  driving-decision analysis.

The car has no position/heading sensor in this program, so it cannot record an
actual x/y trajectory. The simulation replay.json includes simulated position
and heading, but is separate from a real run.

This is the restored v23 program with control changes based on the supplied
start-1 log and detailed logging. It begins avoiding a close front diagonal
sensor earlier, speeds steering reversal during a turn, and steers away from a
near side wall while reversing. It limits one recovery episode to five pulses
instead of repeating up to 999 times. GPIO, sensor, and PWM initialization are
unchanged. It has not completed a lap in the simulator or been run on the actual
RC car. The local compatibility simulator had zero contact but stopped after
five recovery pulses at 46.8 seconds; its initial sensor readings differ from
the provided run log, so this is not a successful validation of that course
run. Logging adds small CPU and buffered file work during each control cycle.
