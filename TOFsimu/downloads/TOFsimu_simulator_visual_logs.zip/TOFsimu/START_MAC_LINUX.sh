#!/bin/sh
cd "$(dirname "$0")" || exit 1
exec python3 simulator.py --config configs/legacy_geometric.json
