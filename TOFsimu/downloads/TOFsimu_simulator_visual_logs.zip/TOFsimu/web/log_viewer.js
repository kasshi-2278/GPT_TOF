/* Recorded observations only: no hardware IO, pose estimation or drive control. */
'use strict';
(() => {
  const $ = id => document.getElementById(id), api = window.DriveLogData;
  const names = ['Fr', 'FrLh', 'FrRh', 'RrLh', 'RrRh'];
  const mounts = [{name:'Fr',x:23,y:0,angle:0},{name:'FrLh',x:20,y:7.5,angle:45},{name:'FrRh',x:20,y:-7.5,angle:-45},{name:'RrLh',x:14,y:9,angle:90},{name:'RrRh',x:14,y:-9,angle:-90}];
  const scene=$('scene'), overview=$('overview');
  let data=null, index=0, playing=false, anchor=0, anchorIndex=0, raf=0, events=[], eventRows=[], sceneBounds=null;
  const finite=Number.isFinite, fmt=(v,n=1)=>finite(v)?v.toFixed(n):'—';
  const signed=v=>finite(v)?(v>=0?'+':'')+v.toFixed(1):'—';
  const text=(id,value)=>{$(id).textContent=value;};
  function error(message){text('load-error',message||'');$('load-error').hidden=!message;}
  function mismatch(f){
    return /左旋回/.test(f.comment||'')&&f.requested_handle < -3 || /右旋回/.test(f.comment||'')&&f.requested_handle > 3;
  }
  function tags(f,previous){
    const out=[];
    if(f.requested_accel<0)out.push('reverse');
    if(f.requested_accel===0)out.push('stop');
    if(/旋回/.test(f.comment||'')||f.debug?.corner>0)out.push('turn');
    if(mismatch(f))out.push('mismatch');
    if(f.collisions>(previous?.collisions||0))out.push('collision');
    return out;
  }
  function pause(){playing=false;cancelAnimationFrame(raf);text('play','▶ 再生');}
  function setIndex(next){index=Math.max(0,Math.min(data.frames.length-1,next));$('frame-range').value=index;render();}
  function activate(value,name){
    let next;
    if(value.kind==='real'){
      if(!Array.isArray(value.frames)||value.frames.length>api.MAX_FRAMES)throw new Error('実機ログの記録数が不正です。');
      next=api.parseText(value.frames.map(f=>typeof f.rawText==='string'?f.rawText:'').join('\n'));
      if(next.frames.length===value.frames.length)next.frames.forEach((f,i)=>{const n=value.frames[i].sourceLine;if(Number.isSafeInteger(n)&&n>0&&n<10000000)f.sourceLine=f.line=n;});
      next.warnings=[...new Set([...(Array.isArray(value.warnings)?value.warnings.filter(w=>typeof w==='string').slice(0,100):[]),...next.warnings])];
    }else next=api.normalizeReplay(value);
    if(!Array.isArray(next.frames)||!next.frames.length)throw new Error('表示できる記録がありません。');
    pause();data=next;index=0;events=[];eventRows=[];$('event-list').dataset.window='';$('event-list').replaceChildren();
    let previous='';
    data.frames.forEach((f,i)=>{const ts=tags(f,data.frames[i-1]),key=[f.comment,ts.join(','),f.reverse_pulses,f.collisions].join('|');if(key!==previous){events.push({index:i,tags:ts});previous=key;}});
    $('viewer').hidden=false;$('empty-state').hidden=true;$('export-html').disabled=false;
    $('frame-range').max=data.frames.length-1;$('frame-range').value=0;
    $('event-filter').value='all';text('file-name',name||'読み込んだ記録');
    sceneBounds=null;
    if(data.kind==='simulation'){
      const points=[...(data.course.outer||[]),...(data.course.walls||[]).flatMap(v=>[[v[0],v[1]],[v[2],v[3]]])];
      sceneBounds={xmin:Infinity,ymin:Infinity,xmax:-Infinity,ymax:-Infinity};
      for(const [x,y] of points){sceneBounds.xmin=Math.min(sceneBounds.xmin,x);sceneBounds.xmax=Math.max(sceneBounds.xmax,x);sceneBounds.ymin=Math.min(sceneBounds.ymin,y);sceneBounds.ymax=Math.max(sceneBounds.ymax,y);}
      for(const f of data.frames){sceneBounds.xmin=Math.min(sceneBounds.xmin,f.x);sceneBounds.xmax=Math.max(sceneBounds.xmax,f.x);sceneBounds.ymin=Math.min(sceneBounds.ymin,f.y);sceneBounds.ymax=Math.max(sceneBounds.ymax,f.y);}
    }
    const real=data.kind==='real';
    text('mode-badge',real?'実機ログ / 測距と指令':'シミュレーション / 記録済み軌跡');
    text('mode-note',real?'車体の位置は固定。射線はその記録の測距値です。実際の壁の形や走行軌跡は復元しません。':'保存した車体位置・測距・操舵・出力を表示します。この画面では再シミュレーションしません。');
    text('play-note',real?'記録順に1件ずつ表示（1倍は0.5秒/件）。ログは間引かれているため、実際の走行時間とは一致しません。':'シミュレーション時刻に沿って再生します。矢印キーで1フレームずつ確認できます。');
    text('drawing-title',real?'車体から見た測距':'コースと計算済みの走行軌跡');
    text('drawing-note',real?'仮配置：前方0°・斜め±45°・側方±90°。表示は120cmまで。上限付近の値は遠方と無検出を区別できません。':'測距線は保存された座標です。計算した軌跡であり、実機の軌跡ではありません。');
    $('trail-control').hidden=real;
    const warnings=data.warnings||[];text('warnings',warnings.slice(0,5).join('\n')+(warnings.length>5?'\nほか '+(warnings.length-5)+' 件':''));$('warnings').hidden=!warnings.length;
    error('');render();
  }
  function render(){
    if(!data)return;
    const f=data.frames[index], real=data.kind==='real', d=f.debug||{};
    text('position',real?`${index+1} / ${data.frames.length} 件`:`${fmt(f.t,3)} 秒 · ${index+1} / ${data.frames.length}`);
    text('source-line',real?`元ログ ${f.sourceLine||f.line} 行目`:`フレーム ${index+1}`);
    text('decision',f.comment||'判断の記録なし');text('handle',signed(f.requested_handle));text('accel',signed(f.requested_accel));
    text('turn-direction',!finite(f.requested_handle)?'記録なし':f.requested_handle>0?'左方向':f.requested_handle<0?'右方向':'中央');
    text('drive-direction',!finite(f.requested_accel)?'記録なし':f.requested_accel>0?'前進指令':f.requested_accel<0?'後退指令':'停止指令');
    for(const n of names){const v=f.measured?.[n],el=$('value-'+n);el.querySelector('b').textContent=fmt(v,1);const valid=finite(v)&&v>0&&v<=500;el.querySelector('small').textContent=!finite(v)?'記録なし':!valid?'異常値':v>=339?'cm / 上限付近':'cm';el.classList.toggle('close',valid&&v<(n==='Fr'?35:n.startsWith('Rr')?12:18));}
    $('mismatch').hidden=!mismatch(f);text('mismatch','判断名と操舵指令の向きが異なっています。近接回避などの上書きもあるため、前後の記録を確認してください。');
    const rows=[['実行周期',fmt(real?f.cycle_s:f.dt,3)+' s'],['制御の内訳',`P ${signed(d.p)} / D ${signed(d.d)} / C ${fmt(d.corner,2)}`],['Gap / PP',`${d.gap||'—'} / ${signed(d.pp)}`],['目標距離',fmt(d.lookahead_cm,1)+' cm'],['狭路',d.narrow===true?'ON':d.narrow===false?'OFF':'記録なし'],['判定メッセージ',d.safety_reason||'—']];
    if(!real)rows.push(['モデル上の速度',fmt(f.speed,1)+' cm/s'],['PWM 舵 / 駆動',`${fmt(f.steer_pwm,0)} / ${fmt(f.throttle_pwm,0)}`],['接触 / 後退パルス',`${fmt(f.collisions,0)} / ${fmt(f.reverse_pulses,0)}`]);
    $('details').replaceChildren();for(const [label,value]of rows){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=value;$('details').append(dt,dd);}
    let raw=f.rawText||'';
    if(!real){
      const logs=data.logs?.length?data.logs:(f.logs||[]);
      const at=upperLog(logs,f.t);raw=logs.slice(Math.max(0,at-16),at).map(x=>`[${fmt(x.t,3)}] ${x.text}`).join('\n');
    }
    text('raw-log',raw||'この時点の文字出力はありません。');$('raw-log').scrollTop=$('raw-log').scrollHeight;
    $('prev-frame').disabled=index===0;$('next-frame').disabled=index===data.frames.length-1;
    drawScene();drawOverview();renderEvents();
  }
  function upperLog(logs,t){let a=0,b=logs.length;while(a<b){const m=(a+b)>>1;if(logs[m].t<=t)a=m+1;else b=m;}return a;}
  function canvasCtx(c){const rect=c.getBoundingClientRect();if(!c.isConnected||rect.width<1||rect.height<1)return null;const dpr=window.devicePixelRatio||1,w=Math.max(1,rect.width),h=Math.max(1,rect.height);if(c.width!==Math.round(w*dpr)||c.height!==Math.round(h*dpr)){c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);}const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);return{ctx,w,h};}
  function line(ctx,points,color,width=1,dash=[]){if(!points.length)return;ctx.beginPath();ctx.moveTo(...points[0]);for(const p of points.slice(1))ctx.lineTo(...p);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);}
  function label(ctx,value,p,color='#b8cada',align='center'){ctx.font='11px system-ui, sans-serif';ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(value,...p);}
  function dot(ctx,p,color,r=3){ctx.beginPath();ctx.arc(...p,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
  function drawScene(){
    const surface=canvasCtx(scene);if(!surface)return;const {ctx,w,h}=surface,f=data.frames[index];
    if(data.kind==='simulation'){drawSimulation(ctx,w,h,f);return;}
    const scale=Math.min((w-55)/280,(h-55)/190),cx=w/2,cy=h*.77;
    const xy=(x,y)=>[cx-y*scale,cy-x*scale];
    for(const radius of [25,50,100]){ctx.beginPath();ctx.arc(cx,cy,radius*scale,Math.PI,2*Math.PI);ctx.strokeStyle='#24384b';ctx.lineWidth=1;ctx.stroke();label(ctx,radius+'cm',[cx+radius*scale+12,cy-4],'#70899f');}
    const body=[xy(24,10),xy(-4,10),xy(-4,-10),xy(24,-10)];ctx.beginPath();ctx.moveTo(...body[0]);body.slice(1).forEach(p=>ctx.lineTo(...p));ctx.closePath();ctx.fillStyle='#285c50';ctx.fill();ctx.strokeStyle='#62ddbf';ctx.lineWidth=2;ctx.stroke();
    label(ctx,'前',[cx,cy-30*scale],'#bff1e3');label(ctx,'左',[18,cy],'#91a9bd');label(ctx,'右',[w-18,cy],'#91a9bd');
    for(const s of mounts){const v=f.measured?.[s.name],color=s.name.startsWith('Rr')?'#8ebcff':'#f6c474',p=xy(s.x,s.y),a=s.angle*Math.PI/180,valid=finite(v)&&v>0&&v<=500;
      if(!valid){label(ctx,s.name+' 異常 / 未記録',[p[0],p[1]-8],'#ffaaa2');continue;}
      const length=Math.min(v,120),q=xy(s.x+length*Math.cos(a),s.y+length*Math.sin(a));line(ctx,[p,q],color,1.8,v>120||v>=339?[5,5]:[]);dot(ctx,p,color,3);if(v<=120)dot(ctx,q,color,4);
      const r=xy(s.x+(length+10)*Math.cos(a),s.y+(length+10)*Math.sin(a));label(ctx,s.name+' '+fmt(v,0)+'cm',[Math.min(w-48,Math.max(48,r[0])),Math.min(h-12,Math.max(18,r[1]))],color);
    }
    const command=finite(f.requested_handle)?Math.max(-100,Math.min(100,f.requested_handle)):0;
    const end=[cx-command*.55,cy+40];line(ctx,[[cx,cy+12],[cx-command*.22,cy+25],end],'#62ddbf',3);dot(ctx,end,'#62ddbf',4);
    label(ctx,'操舵指令（実舵角ではありません）',[cx,h-10],'#a2b8ca');
  }
  function drawSimulation(ctx,w,h,f){
    const c=data.course,{xmin,ymin,xmax,ymax}=sceneBounds;
    const scale=Math.min((w-45)/Math.max(1,xmax-xmin),(h-45)/Math.max(1,ymax-ymin)),ox=(w-(xmax-xmin)*scale)/2,oy=(h-(ymax-ymin)*scale)/2;
    const xy=(x,y)=>[ox+(x-xmin)*scale,h-oy-(y-ymin)*scale];
    for(const wall of c.walls||[])line(ctx,[xy(wall[0],wall[1]),xy(wall[2],wall[3])],'#94a5b7',2.5);
    for(const polygon of c.solids||[]){const points=polygon.map(p=>xy(...p));if(points.length){ctx.beginPath();ctx.moveTo(...points[0]);points.slice(1).forEach(p=>ctx.lineTo(...p));ctx.closePath();ctx.fillStyle='#2c3c50';ctx.fill();}}
    if($('show-trail').checked){const step=Math.max(1,Math.ceil((index+1)/2000)),points=[];for(let i=0;i<=index;i+=step)points.push(xy(data.frames[i].x,data.frames[i].y));points.push(xy(f.x,f.y));line(ctx,points,'#6d9eff',1.8);}
    for(const [name,ray]of Object.entries(f.rays||{})){if(!Array.isArray(ray.line)||ray.line.length!==4)continue;const p=ray.line;line(ctx,[xy(p[0],p[1]),xy(p[2],p[3])],name.startsWith('Rr')?'#8ebcff':'#f6c474',1.2,ray.hit?[]:[4,4]);}
    const cfg=data.config,co=Math.cos(f.heading),si=Math.sin(f.heading),body=f.body?.length?f.body:[[cfg.body_front_cm,cfg.body_width_cm/2],[-cfg.body_rear_cm,cfg.body_width_cm/2],[-cfg.body_rear_cm,-cfg.body_width_cm/2],[cfg.body_front_cm,-cfg.body_width_cm/2]].map(([x,y])=>[f.x+co*x-si*y,f.y+si*x+co*y]);
    const points=body.map(p=>xy(...p));if(points.length){ctx.beginPath();ctx.moveTo(...points[0]);points.slice(1).forEach(p=>ctx.lineTo(...p));ctx.closePath();ctx.fillStyle=f.collisions?'#ffaaa2':'#62ddbf';ctx.fill();ctx.strokeStyle='#d6fff4';ctx.stroke();}
    line(ctx,[xy(f.x,f.y),xy(f.x+30*co,f.y+30*si)],'#e4fff8',2);label(ctx,'記録時刻 '+fmt(f.t,2)+' 秒',[w-12,18],'#bed3e5','right');
  }
  function drawOverview(){
    const surface=canvasCtx(overview);if(!surface)return;const {ctx,w,h}=surface,fs=data.frames,n=fs.length,step=Math.max(1,Math.ceil(n/w));
    line(ctx,[[0,h/2],[w,h/2]],'#3b5065');const points=[];
    for(let i=0;i<n;i+=step){const v=fs[i].requested_handle;if(finite(v))points.push([i/Math.max(1,n-1)*w,h/2-Math.max(-100,Math.min(100,v))*(h-8)/200]);}
    line(ctx,points,'#62ddbf',1.3);const x=index/Math.max(1,n-1)*w;line(ctx,[[x,0],[x,h]],'#f6c474',2);label(ctx,'左＋ / 右− · 操舵指令',[8,12],'#9fb2c6','left');
  }
  function renderEvents(){
    const filter=$('event-filter').value,filtered=events.filter(e=>filter==='all'||e.tags.includes(filter));
    let at=filtered.findIndex(e=>e.index>=index);if(at<0)at=filtered.length;const start=Math.max(0,Math.min(filtered.length-100,at-35));
    const key=filter+':'+start+':'+filtered.length;
    if($('event-list').dataset.window!==key){
      $('event-list').dataset.window=key;$('event-list').replaceChildren();eventRows=[];
      for(const e of filtered.slice(start,start+100)){const f=data.frames[e.index],b=document.createElement('button'),stamp=document.createElement('span'),desc=document.createElement('span');b.className='event-row';stamp.className='stamp';desc.className='event-text';stamp.textContent=data.kind==='real'?`${e.index+1}件目`:`${fmt(f.t,2)}秒`;desc.textContent=(f.comment||'判断の記録なし')+` · 舵 ${signed(f.requested_handle)} / アクセル ${signed(f.requested_accel)}`;b.append(stamp,desc);b.addEventListener('click',()=>{pause();setIndex(e.index);});$('event-list').append(b);eventRows.push({button:b,index:e.index});}
    }
    for(const row of eventRows)row.button.classList.toggle('active',row.index===index);
    text('event-count',`${filtered.length}件の判断変化${filtered.length>100?'（現在位置に近い100件を表示）':''}。クリックでその記録へ移動。`);
    $('prev-event').disabled=!filtered.some(e=>e.index<index);$('next-event').disabled=!filtered.some(e=>e.index>index);
  }
  function jumpEvent(direction){if(!data)return;const filter=$('event-filter').value,found=events.filter(e=>(filter==='all'||e.tags.includes(filter))&&(direction>0?e.index>index:e.index<index));if(found.length){pause();setIndex((direction>0?found[0]:found[found.length-1]).index);}}
  function tick(now){
    if(!playing||!data)return;const speed=Number($('play-speed').value),elapsed=now-anchor;
    const next=data.kind==='real'?anchorIndex+Math.floor(elapsed*speed/500):api.frameIndexAtTime(data.frames,data.frames[anchorIndex].t+elapsed*speed/1000);
    if(next!==index)setIndex(next);
    if(index>=data.frames.length-1){pause();return;}raf=requestAnimationFrame(tick);
  }
  function play(){if(!data)return;if(playing){pause();return;}if(index===data.frames.length-1)setIndex(0);playing=true;anchor=performance.now();anchorIndex=index;text('play','❚❚ 一時停止');raf=requestAnimationFrame(tick);}
  async function loadFile(file){if(!file)return;if(file.size>100*1024*1024)throw new Error('ファイルは100 MiB以内にしてください。');const content=await file.text();const json=file.name.toLowerCase().endsWith('.json')||content.trimStart().startsWith('{');activate(json?JSON.parse(content):api.parseText(content),file.name);}
  $('load-file').addEventListener('change',async e=>{try{await loadFile(e.target.files[0]);}catch(ex){error(ex.message);}e.target.value='';});
  $('load-paste').addEventListener('click',()=>{try{activate(api.parseText($('paste-log').value),'貼り付けた実機ログ');$('paste-details').open=false;}catch(ex){error(ex.message);}});
  $('play').addEventListener('click',play);$('prev-frame').addEventListener('click',()=>{pause();setIndex(index-1);});$('next-frame').addEventListener('click',()=>{pause();setIndex(index+1);});
  $('frame-range').addEventListener('input',e=>{pause();setIndex(Number(e.target.value));});$('play-speed').addEventListener('change',()=>{if(playing){anchor=performance.now();anchorIndex=index;}});
  $('overview').addEventListener('click',e=>{if(!data)return;const r=overview.getBoundingClientRect();pause();setIndex(Math.round((e.clientX-r.left)/r.width*(data.frames.length-1)));});
  $('show-trail').addEventListener('change',()=>{if(data)drawScene();});$('event-filter').addEventListener('change',()=>{if(data)renderEvents();});$('prev-event').addEventListener('click',()=>jumpEvent(-1));$('next-event').addEventListener('click',()=>jumpEvent(1));
  document.addEventListener('keydown',e=>{if(!data||/INPUT|TEXTAREA|SELECT|BUTTON|SUMMARY/.test(e.target.tagName))return;if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();pause();setIndex(index+(e.key==='ArrowLeft'?-1:1));}else if(e.code==='Space'){e.preventDefault();play();}});
  new ResizeObserver(()=>{if(data){drawScene();drawOverview();}}).observe(scene.parentElement);
  $('export-html').addEventListener('click',async()=>{
    if(!data)return;const button=$('export-html');button.disabled=true;
    try{
      pause();
      // File reports already inline these assets; the local-server viewer fetches
      // only its own static scripts/styles before producing a portable file.
      const assets=[];
      for(const el of document.querySelectorAll('link[rel="stylesheet"],script[src]')){const url=el.href||el.src;const response=await fetch(url);if(!response.ok)throw new Error('表示用ファイルを読み込めません。');assets.push({el,text:await response.text()});}
      const doc=document.documentElement.cloneNode(true);
      const css=doc.querySelector('link[rel="stylesheet"]');
      if(css){const style=document.createElement('style');style.textContent=assets.find(a=>a.el.tagName==='LINK').text;css.replaceWith(style);}
      const code=[];
      for(const el of doc.querySelectorAll('script[src]')){const path=el.getAttribute('src');const a=assets.find(a=>a.el.tagName==='SCRIPT'&&a.el.getAttribute('src')===path);code.push(a.text);el.remove();}
      // Inline scripts must run after DOM parsing, not inline-defer in the head.
      for(const source of code){const script=document.createElement('script');script.textContent=source;doc.querySelector('body').append(script);}
      const safeJSON=JSON.stringify(data).replace(/[<>&\u2028\u2029]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
      doc.querySelector('#log-data').textContent=safeJSON;doc.querySelector('#paste-log').textContent='';
      const blob=new Blob(['<!doctype html>\n'+doc.outerHTML],{type:'text/html;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='TOFsimu_visual_log.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
    }catch(ex){error('保存できません：'+ex.message);}finally{button.disabled=false;}
  });
  $('sensors').replaceChildren();
  for(const n of names){const el=document.createElement('div');el.id='value-'+n;el.className='sensor-value'+(n.startsWith('Rr')?' side':'');const label=document.createElement('span'),v=document.createElement('b'),unit=document.createElement('small');label.textContent=n;v.textContent='—';unit.textContent='cm';el.append(label,v,unit);$('sensors').append(el);}
  try{const initial=JSON.parse($('log-data').textContent);if(initial){activate(initial,initial.kind==='real'?'保存した実機ログ':'保存したシミュレーション');}}catch(ex){error('保存データを開けません：'+ex.message);}
})();
