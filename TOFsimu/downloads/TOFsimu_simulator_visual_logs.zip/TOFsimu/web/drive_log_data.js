/* Shared data handling for browser-only visual logs. No hardware access. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.DriveLogData = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const NAMES = Object.freeze(['Fr', 'FrLh', 'FrRh', 'RrLh', 'RrRh']);
  const MAX_CHARS = 10 * 1024 * 1024;
  const MAX_FRAMES = 50000;
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const object = o => o !== null && typeof o === 'object' && !Array.isArray(o);
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const short = (s, n = 2000) => typeof s === 'string' ? s.slice(0, n) : '';
  const number = s => {
    if (typeof s !== 'string' || !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(s)) return null;
    const n = Number(s); return Number.isFinite(n) ? n : null;
  };
  const fail = text => { throw new Error(text); };

  function parseText(text) {
    if (typeof text !== 'string') fail('文字ログを選んでください。');
    if (text.length > MAX_CHARS) fail('文字ログは10 MiB相当の文字数以内にしてください。');
    const lines = text.replace(/^\uFEFF/, '').split(/\r\n?|\n/);
    const frames = [], warnings = [];
    let pending = null, orphan = false;
    const warn = message => { if (warnings.length < 100) warnings.push(message); };
    function finish() {
      if (!pending) return;
      if (!pending.complete || pending.badSensors) {
        warn(`${pending.sourceLine}行目：測距または操舵・アクセルが不完全な記録を除外しました。`);
      } else {
        if (frames.length >= MAX_FRAMES) fail('文字ログは50,000記録以内にしてください。');
        const {complete, badSensors, lines: recordLines, ...frame} = pending;
        frame.index = frames.length;
        frame.rawText = recordLines.join('\n');
        frames.push(frame);
      }
      pending = null;
    }
    for (let i = 0; i < lines.length; i++) {
      const originalLine = lines[i];
      const line = originalLine.replace(/^\s*\[\s*(?:\d+(?:\.\d*)?|\.\d+)\s*\]\s*/, '');
      if (/^\s*Fr\s*[:：]/.test(line)) {
        finish();
        const measured = {}, seen = new Set(); let badSensors = false;
        const tokens = line.matchAll(/\b(FrLh|FrRh|RrLh|RrRh|Fr)\s*[:：]\s*([^\s]+)/g);
        for (const m of tokens) {
          const n = number(m[2]);
          if (seen.has(m[1]) || n === null) badSensors = true;
          seen.add(m[1]); measured[m[1]] = n;
        }
        if (!NAMES.every(n => seen.has(n))) badSensors = true;
        pending = {
          index: 0, line: i + 1, sourceLine: i + 1, measured,
          requested_handle: null, requested_accel: null, cycle_s: null,
          comment: '', debug: {p: null, d: null, corner: null, gap: null,
            pp: null, lookahead_cm: null, narrow: null, safety_reason: ''},
          lines: [originalLine], complete: false, badSensors
        };
        continue;
      }
      if (!pending) { if (/ハンドル\s*[=＝]/.test(line)) orphan = true; continue; }
      pending.lines.push(originalLine);
      const cmd = line.match(/^(.*?)\s*ハンドル\s*[=＝]\s*([^\s]+)\s+アクセル\s*[=＝]\s*([^\s]+)\s+周期\s*[=＝]\s*([^\s]+?)s(?:\s|$)(.*)$/);
      if (cmd) {
        if (pending.complete) { warn(`${i + 1}行目：同じ測距記録に複数の操舵出力があります。先の出力を表示します。`); continue; }
        const h = number(cmd[2]), a = number(cmd[3]), dt = number(cmd[4]);
        if (h === null || a === null || dt === null || dt < 0) {
          warn(`${i + 1}行目：操舵・アクセル・周期の数値が不正です。`); continue;
        }
        pending.requested_handle = h; pending.requested_accel = a;
        pending.cycle_s = dt; pending.comment = cmd[1].trim(); pending.complete = true;
        for (const [key, label] of [['p', 'P'], ['d', 'D'], ['corner', 'C']]) {
          const m = cmd[5].match(new RegExp('(?:^|\\s)' + label + '\\s*[=＝]\\s*([^\\s]+)'));
          if (m) pending.debug[key] = number(m[1]);
        }
      } else if (/^\s*Gap\s*[=＝]/.test(line)) {
        const gap = line.match(/Gap\s*[=＝]\s*([^\s]+)/);
        const pp = line.match(/\bPP\s*[=＝]\s*([^\s]+)/);
        const look = line.match(/目標距離\s*[=＝]\s*(.*?)\s*cm(?:\s|$)/);
        if (gap) pending.debug.gap = gap[1];
        if (pp) pending.debug.pp = number(pp[1]);
        if (look) pending.debug.lookahead_cm = number(look[1]);
      } else if (/^\s*狭路\s*[=＝]/.test(line)) {
        const narrow = line.match(/狭路\s*[=＝]\s*(True|False|true|false)\b/);
        const reason = line.match(/安全判定\s*[=＝]\s*(.*)$/);
        if (narrow) pending.debug.narrow = narrow[1].toLowerCase() === 'true';
        if (reason) pending.debug.safety_reason = reason[1];
      }
    }
    finish();
    if (orphan) warn('先頭などの測距値を伴わない操舵出力は、対応する測距記録がないため表示から除外しました。');
    if (!frames.length) fail('5センサーの測距とハンドル・アクセル・周期を含む記録が見つかりません。');
    return {kind: 'real', frames, warnings, timing: 'sequence'};
  }

  function vec(value, n, description) {
    if (!Array.isArray(value) || value.length !== n || !value.every(v => finite(v) && Math.abs(v) <= 1e7)) fail(description + 'の座標が不正です。');
    return value.slice();
  }
  function list(value, max, description) {
    if (!Array.isArray(value) || value.length > max) fail(description + 'の形式または件数が不正です。');
    return value;
  }
  function scalar(value, description, min = -1e7, max = 1e7) {
    if (!finite(value) || value < min || value > max) fail(description + 'の数値が不正です。');
    return value;
  }
  function readings(value, description) {
    if (!object(value)) fail(description + 'の測距値が不正です。');
    const result = {};
    for (const name of NAMES) if (own(value, name)) {
      // Exported sensor faults use null; retain them as invalid/missing, never 0.
      result[name] = value[name] === null ? null : scalar(value[name], description + ' ' + name);
    }
    return result;
  }
  function debugValues(value) {
    const out = {};
    if (!object(value)) return out;
    for (const key of ['p','d','corner','pp','lookahead_cm','gap_angle_deg','goal_x','goal_y','curvature','edge_recent_seconds','turn_elapsed','turn_settle_seconds']) {
      if (own(value, key)) out[key] = finite(value[key]) ? value[key] : null;
    }
    for (const key of ['gap','gap_method','safety_reason','wall_reference','planner_reason']) if (own(value, key)) out[key] = short(value[key]);
    for (const key of ['narrow','pp_applied','edge_guard']) if (own(value, key)) out[key] = value[key] === true;
    return out;
  }
  function logs(value, description) {
    if (value === undefined) return [];
    let lastT = -1;
    return list(value, 200000, description).map(v => {
      if (!object(v) || typeof v.text !== 'string') fail(description + 'のログが不正です。');
      const t = scalar(v.t, description + '時刻', 0);
      if (t < lastT) fail(description + 'ログの時刻が順番に並んでいません。');
      lastT = t;
      return {t, text: short(v.text, 20000)};
    });
  }
  function normalizeReplay(data) {
    if (!object(data) || !object(data.course) || !object(data.config)) fail('course・config・framesを含むreplay.jsonを選んでください。');
    const sourceFrames = list(data.frames, MAX_FRAMES, 'リプレイ');
    if (!sourceFrames.length) fail('リプレイに走行フレームがありません。');
    const c = data.course;
    let solidVertices = 0;
    const course = {
      id: short(c.id, 100), name: short(c.name, 256),
      width: scalar(c.width, 'コース幅', 1, 1e7), height: scalar(c.height, 'コース高さ', 1, 1e7),
      walls: list(c.walls, 4096, '壁').map(w => vec(w, 4, '壁')),
      outer: c.outer === undefined ? [] : list(c.outer, 4096, '外周').map(v => vec(v, 2, '外周')),
      start: c.start === undefined ? [0, 0, 0] : vec(c.start, 3, '開始姿勢'),
      note: short(c.note, 4000),
      gates: c.gates === undefined ? [] : list(c.gates, 4096, 'ゲート').map(v => vec(v, Array.isArray(v) && v.length === 6 ? 6 : 4, 'ゲート')),
      solids: c.solids === undefined ? [] : list(c.solids, 512, '障害物').map(p => {
        const vertices = list(p, 4096, '障害物頂点'); solidVertices += vertices.length;
        if (solidVertices > 16384) fail('障害物頂点の総数は16,384以内にしてください。');
        return vertices.map(v => vec(v, 2, '障害物頂点'));
      }),
      labels: c.labels === undefined ? [] : list(c.labels, 4096, 'ラベル').map(v => {
        if (!Array.isArray(v) || v.length !== 3 || typeof v[2] !== 'string') fail('コースラベルが不正です。');
        return [scalar(v[0], 'ラベルx'), scalar(v[1], 'ラベルy'), short(v[2], 1000)];
      })
    };
    const config = {};
    for (const key of ['body_width_cm','body_front_cm','body_rear_cm','wheelbase_cm','max_steer_deg','range_max_cm']) {
      config[key] = scalar(data.config[key], '設定 ' + key, 0, 100000);
    }
    if (config.body_width_cm <= 0 || config.wheelbase_cm <= 0) fail('車幅・ホイールベースは0より大きい値が必要です。');
    const sensorNames = new Set();
    config.sensors = list(data.config.sensors, 32, 'センサー設定').map(v => {
      if (!object(v) || !NAMES.includes(v.name) || sensorNames.has(v.name)) fail('センサー名が不正または重複しています。');
      sensorNames.add(v.name);
      return {name: v.name, x: scalar(v.x, 'センサーx'), y: scalar(v.y, 'センサーy'), angle: scalar(v.angle, 'センサー角度', -360, 360)};
    });
    if (!NAMES.every(n => sensorNames.has(n))) fail('5個のセンサー設定が必要です。');
    let lastT = -1;
    const frames = sourceFrames.map((v, index) => {
      if (!object(v)) fail('フレームの形式が不正です。');
      const f = {index, t: scalar(v.t, 'フレーム時刻', 0),
        x: scalar(v.x, '車体x'), y: scalar(v.y, '車体y'), heading: scalar(v.heading, '車体角度'),
        measured: readings(v.measured, 'フレーム'), debug: debugValues(v.debug), comment: short(v.comment), logs: logs(v.logs, 'フレーム')};
      if (f.t < lastT) fail('リプレイの時刻が順番に並んでいません。');
      lastT = f.t;
      f.body = list(v.body, 4, '車体頂点').map(p => vec(p, 2, '車体頂点'));
      if (f.body.length !== 4) fail('車体には4つの頂点が必要です。');
      for (const k of ['speed','steer_deg','handle','accel','requested_handle','requested_accel','steer_pwm','throttle_pwm','dt','cycles','collisions','gate','gates_total','laps','finished','distance_cm','reverse_distance_cm','reverse_pulses','brake_pulses']) {
        if (own(v, k)) f[k] = scalar(v[k], 'フレーム ' + k);
      }
      f.cycle_s = finite(v.dt) ? v.dt : null;
      for (const k of ['phase','status','reason']) f[k] = short(v[k]);
      f.rays = {};
      if (v.rays !== undefined && !object(v.rays)) fail('測距線の形式が不正です。');
      for (const n of NAMES) if (v.rays && own(v.rays, n)) {
        const ray = v.rays[n]; if (!object(ray)) fail('測距線が不正です。');
        f.rays[n] = {line: vec(ray.line, 4, '測距線'), hit: ray.hit === true};
      }
      if (v.decision_pose != null) f.decision_pose = vec(v.decision_pose, 3, '判断時姿勢');
      if (v.contact_point != null) f.contact_point = vec(v.contact_point, 2, '接触点');
      return f;
    });
    const summary = {};
    if (object(data.summary)) {
      for (const k of ['reason','program','final_comment','model_note']) summary[k] = short(data.summary[k]);
      for (const k of ['sim_seconds','distance_cm','collisions','laps']) if (finite(data.summary[k])) summary[k] = data.summary[k];
      summary.original_unchanged = data.summary.original_unchanged === true;
    }
    return {kind: 'simulation', timing: 'simulation', course, config, frames, logs: logs(data.logs, '保存'), summary, warnings: []};
  }

  function frameIndexAtTime(frames, t) {
    if (!Array.isArray(frames) || !frames.length) return -1;
    if (!finite(t)) return 0;
    let lo = 0, hi = frames.length;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (frames[mid].t <= t) lo = mid + 1; else hi = mid;
    }
    return Math.max(0, lo - 1);
  }
  return Object.freeze({NAMES, MAX_CHARS, MAX_FRAMES, parseText, normalizeReplay, frameIndexAtTime});
});
