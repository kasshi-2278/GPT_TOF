'use strict';
const $ = id => document.getElementById(id);
const clone = x => JSON.parse(JSON.stringify(x));
const token = document.querySelector('meta[name="sim-token"]').content;
let meta, cfg, state = {}, preview = true, replay = null, replayIndex = 0;
let editableCourse = null, editing = false, dragging = null, hover = null;
let transform = {s:1, ox:0, oy:0}, fittedKey = '', runningRequest = false;
const canvas = $('map'), ctx = canvas.getContext('2d');
const numeric = ['seconds','realtime','speed_scale','scan_overhead_s','wheelbase_cm','max_steer_deg',
  'body_width_cm','body_front_cm','body_rear_cm','sensor_noise_cm','beam_half_angle_deg','seed','fault_after_s','stuck_seconds'];
const optional = ['start_x','start_y','start_heading_deg'];
const selectors = ['fault_sensor','fault_mode','no_hit_mode'];
const reasons = {finished:'設定した全ゲートを順番に通過',collision:'車体と壁の接触を検出',
  stuck:'停滞を検出して検証を打ち切り',time_limit:'設定時間に到達',stopped:'手動で終了',
  error:'実行エラー',program_returned:'元プログラムが終了'};
const phases = {neutral:'停止 / 中立',forward:'前進',brake:'ブレーキ',reverse:'後退'};
function error(text){$('error').hidden=!text; $('error').textContent=text || '';}
async function api(path, data){
  const options = data ? {method:'POST',headers:{'Content-Type':'application/json','X-Sim-Token':token},body:JSON.stringify(data)} : {};
  const response = await fetch(path, options), obj=await response.json();
  if(!response.ok) throw new Error(obj.error || `HTTP ${response.status}`);
  return obj;
}
function downloadJSON(name,obj){
  const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}));
  const a=document.createElement('a'); a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function setPrograms(items,chosen){
  const select=$('program'); select.innerHTML='';
  for(const p of items){const o=document.createElement('option');o.value=p.name;o.textContent=p.name;select.append(o);}
  if(chosen && items.some(p=>p.name===chosen))select.value=chosen;
  showHash();
}
function showHash(){
  if(state.summary?.original_unchanged && !preview && !replay){
    $('hash').textContent='✓ 実行前後のSHA-256一致\n'+state.summary.sha256_after;
    return;
  }
  const item=meta?.programs.find(p=>p.name===$('program').value);
  $('hash').textContent=item ? '原本 SHA-256\n'+item.sha256 : 'Pythonファイルを読み込んでください。';
}
function sensorEditor(){
  const root=$('sensor-editor');root.innerHTML='';
  const header=document.createElement('div');header.className='sensor-edit-row heading';
  for(const text of ['センサー','前後 x','左右 y','角度 °']){const v=document.createElement('span');v.textContent=text;header.append(v);}root.append(header);
  for(const s of cfg.sensors){
    const row=document.createElement('div');row.className='sensor-edit-row';const n=document.createElement('span');n.textContent=s.name;row.append(n);
    for(const key of ['x','y','angle']){const i=document.createElement('input');i.type='number';i.step='0.1';i.value=s[key];i.dataset.sensor=s.name;i.dataset.field=key;i.title=`${s.name} ${key}`;i.addEventListener('change',()=>{if(!state.alive){preview=true;draw();}});row.append(i);}root.append(row);
  }
}
function updateDimensionSummary(){
  const front=Number($('body_front_cm').value),rear=Number($('body_rear_cm').value);
  const wheelbase=Number($('wheelbase_cm').value),width=Number($('body_width_cm').value);
  const valid=[front,rear,wheelbase,width].every(Number.isFinite)&&front>=wheelbase&&wheelbase>0&&rear>=0&&width>0;
  const m=x=>Math.round(x*10).toLocaleString('ja-JP');
  $('dimension-summary').textContent=valid?
    `車体全長 ${m(front+rear)} mm × 幅 ${m(width)} mm ／ 前端→前輪中心 ${m(front-wheelbase)} mm ／ 前端→後輪中心 ${m(front)} mm`:
    '寸法が不正です。前輪軸は車体前端より後ろに配置してください。';
}
function fillControls(config){
  cfg=clone(config); for(const k of numeric)$(k).value=cfg[k];
  for(const k of optional)$(k).value=cfg[k]===null?'':cfg[k];
  for(const k of selectors)$(k).value=cfg[k];
  $('stop_on_collision').checked=cfg.stop_on_collision; $('stop_on_finish').checked=cfg.stop_on_finish;
  $('course').value=cfg.course;editableCourse=cfg.custom_course?clone(cfg.custom_course):null;
  sensorEditor();$('advanced').value=JSON.stringify(cfg,null,2);updateCourseNote();updateDimensionSummary();
}
function collectConfig(){
  const c=clone(cfg); for(const k of numeric){const v=Number($(k).value);if(!Number.isFinite(v))throw new Error(k+'の値が不正です');c[k]=v;}
  for(const k of optional)c[k]=$(k).value.trim()===''?null:Number($(k).value);
  for(const k of selectors)c[k]=$(k).value;
  c.stop_on_collision=$('stop_on_collision').checked;c.stop_on_finish=$('stop_on_finish').checked;
  c.course=$('course').value;c.custom_course=editableCourse?clone(editableCourse):null;
  document.querySelectorAll('[data-sensor]').forEach(i=>{c.sensors.find(s=>s.name===i.dataset.sensor)[i.dataset.field]=Number(i.value);});
  return c;
}
function courseForPreview(){return editableCourse || meta.courses.find(c=>c.id===$('course').value) || meta.courses[0];}
function shownCourse(){return replay ? replay.course : (!preview && state.course ? state.course : courseForPreview());}
function shownFrame(){return replay ? replay.frames[replayIndex] : (preview ? null : state.frame);}
function shownCfg(){return replay?replay.config:(!preview && state.config ? state.config:collectConfig());}
function shownTrail(){return replay?replay.frames.slice(0,replayIndex+1).map(f=>[f.x,f.y,f.t,f.speed]):(preview?[]:state.trail||[]);}
function updateCourseNote(){if(!meta)return;const c=courseForPreview();$('course-note').textContent=c.note;$('map-title').textContent=c.name;}
function size(){const r=canvas.getBoundingClientRect();return {w:r.width,h:r.height};}
function fit(){
  if(!meta)return;const c=shownCourse(),v=size();
  const s=Math.min((v.w-85)/c.width,(v.h-80)/c.height);
  transform={s,ox:(v.w-c.width*s)/2,oy:(v.h+c.height*s)/2};draw();
}
function xy(x,y){return [transform.ox+x*transform.s,transform.oy-y*transform.s];}
function world(x,y){return [(x-transform.ox)/transform.s,(transform.oy-y)/transform.s];}
function path(points,close=false){ctx.beginPath();for(let i=0;i<points.length;i++){const p=xy(...points[i]);i?ctx.lineTo(...p):ctx.moveTo(...p);}if(close)ctx.closePath();}
function textAt(text,x,y,color='#778ba2',font=10){ctx.fillStyle=color;ctx.font=`${font}px "Segoe UI", "Meiryo", sans-serif`;ctx.textAlign='center';ctx.fillText(text,...xy(x,y));}
function previewBody(course,c){
  const x=c.start_x??course.start[0],y=c.start_y??course.start[1],heading=(c.start_heading_deg??course.start[2])*Math.PI/180;
  const f=c.body_front_cm,r=c.body_rear_cm,w=c.body_width_cm/2,co=Math.cos(heading),si=Math.sin(heading);
  return {x,y,heading,body:[[f,w],[-r,w],[-r,-w],[f,-w]].map(p=>[x+co*p[0]-si*p[1],y+si*p[0]+co*p[1]]),debug:{},rays:{}};
}
function draw(){
  if(!meta)return;
  const v=size(),dpr=window.devicePixelRatio||1;
  if(canvas.width!==Math.round(v.w*dpr)||canvas.height!==Math.round(v.h*dpr)){canvas.width=Math.round(v.w*dpr);canvas.height=Math.round(v.h*dpr);}
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,v.w,v.h);
  let course=shownCourse(),c=shownCfg(),f=shownFrame()||previewBody(course,c);
  const key=course.id+':'+course.width+':'+course.height;
  if(fittedKey!==key){fittedKey=key;const s=Math.min((v.w-85)/course.width,(v.h-80)/course.height);transform={s,ox:(v.w-course.width*s)/2,oy:(v.h+course.height*s)/2};}
  const bounds=[world(0,v.h),world(v.w,0)],spacing=transform.s>1.4?25:transform.s>0.5?50:100;
  ctx.strokeStyle='#1a2738';ctx.lineWidth=1;
  for(let x=Math.ceil(bounds[0][0]/spacing)*spacing;x<=bounds[1][0];x+=spacing){path([[x,bounds[0][1]],[x,bounds[1][1]]]);ctx.stroke();}
  for(let y=Math.ceil(bounds[0][1]/spacing)*spacing;y<=bounds[1][1];y+=spacing){path([[bounds[0][0],y],[bounds[1][0],y]]);ctx.stroke();}
  path(course.outer,true);ctx.fillStyle='#1b2a3d';ctx.fill();ctx.strokeStyle='#74859b';ctx.lineWidth=3;ctx.stroke();
  for(const poly of course.solids){path(poly,true);ctx.fillStyle='#0c1521';ctx.fill();ctx.strokeStyle='#64768e';ctx.lineWidth=2.5;ctx.stroke();}
  for(const w of course.walls){path([[w[0],w[1]],[w[2],w[3]]]);ctx.strokeStyle='#d59a69';ctx.lineWidth=3;ctx.stroke();}
  for(const [i,g] of course.gates.entries()){
    path([[g[0],g[1]],[g[2],g[3]]]);ctx.strokeStyle=i===(f.gate||0)?'#56848c':'#3b535f';ctx.lineWidth=1.5;ctx.setLineDash([5,6]);ctx.stroke();ctx.setLineDash([]);
    textAt('G'+(i+1),(g[0]+g[2])/2,(g[1]+g[3])/2+10,'#85a8b0',9);
  }
  for(const lab of course.labels||[])textAt(lab[2],lab[0],lab[1],'#5e7189',11);
  const start=previewBody(course,c);textAt('START',start.x,start.y-24,'#688393',9);
  // Length markers refer only to the current fictional/custom course.
  textAt(`${course.width} cm`,course.width/2,-28,'#7890a9',10);
  textAt(`${course.height} cm`,-34,course.height/2,'#7890a9',10);
  const trail=shownTrail();
  if($('show-trail').checked&&trail.length>1){path(trail.map(p=>[p[0],p[1]]));ctx.strokeStyle='#649dff';ctx.lineWidth=2;ctx.lineJoin='round';ctx.stroke();}
  if($('show-rays').checked){
    for(const [name,ray] of Object.entries(f.rays||{})){
      const line=ray.line;path([[line[0],line[1]],[line[2],line[3]]]);ctx.strokeStyle=name.startsWith('Rr')?'#79a9d499':'#edbc70b0';ctx.lineWidth=1.3;ctx.stroke();
      const p=xy(line[2],line[3]);ctx.fillStyle=ray.hit?'#eabd79':'#5b6977';ctx.beginPath();ctx.arc(...p,2.5,0,Math.PI*2);ctx.fill();
    }
  }
  const debug=f.debug||{};
  if($('show-goal').checked&&debug.goal_x!=null&&debug.goal_y!=null){
    const pos=f.decision_pose||[f.x,f.y,f.heading],co=Math.cos(pos[2]),si=Math.sin(pos[2]);
    const gx=pos[0]+co*debug.goal_x-si*debug.goal_y,gy=pos[1]+si*debug.goal_x+co*debug.goal_y;
    path([[pos[0],pos[1]],[gx,gy]]);ctx.strokeStyle='#c298f5';ctx.setLineDash([4,5]);ctx.lineWidth=1;ctx.stroke();ctx.setLineDash([]);
    const p=xy(gx,gy);ctx.beginPath();ctx.arc(...p,6,0,Math.PI*2);ctx.strokeStyle='#c298f5';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#c298f5';ctx.font='10px monospace';ctx.textAlign='left';ctx.fillText('PP',p[0]+10,p[1]-7);
  }
  path(f.body,true);ctx.fillStyle=f.collisions?'#f09483':'#4bcdb8';ctx.fill();ctx.strokeStyle='#c9fff3';ctx.lineWidth=1;ctx.stroke();
  // Highlight all five sensor mounts, including Rr* side-facing units in front half.
  for(const sensor of c.sensors){
    const cs=Math.cos(f.heading),sn=Math.sin(f.heading);
    const sx=f.x+cs*sensor.x-sn*sensor.y,sy=f.y+sn*sensor.x+cs*sensor.y;
    const theta=f.heading+sensor.angle*Math.PI/180;
    const tip=[sx+18*Math.cos(theta),sy+18*Math.sin(theta)];
    path([[sx,sy],tip]);ctx.strokeStyle=sensor.name==='Fr'?'#ffd880':(sensor.name.startsWith('Rr')?'#9bc7ff':'#ffac96');
    ctx.lineWidth=1.7;ctx.stroke();
    const point=xy(sx,sy);ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.arc(...point,3.2,0,2*Math.PI);ctx.fill();
    if(transform.s>=0.62){const text=xy(...tip);ctx.fillStyle='#d6e6ed';ctx.font='10px sans-serif';ctx.fillText(sensor.name,text[0]+5,text[1]-5);}
  }
  // Two axles and steerable front tires, using the same rear-axle origin.
  const cp=xy(f.x,f.y),s=transform.s;
  ctx.save();ctx.translate(...cp);ctx.rotate(-f.heading);
  for(const axle of [0,c.wheelbase_cm]){
    ctx.strokeStyle='#172331';ctx.lineWidth=Math.max(1,1.5*s);ctx.beginPath();ctx.moveTo(axle*s,-c.body_width_cm/2*s);ctx.lineTo(axle*s,c.body_width_cm/2*s);ctx.stroke();
    for(const side of [-1,1]){ctx.save();ctx.translate(axle*s,side*c.body_width_cm/2*s);if(axle!==0)ctx.rotate(-(f.steer_deg||0)*Math.PI/180);ctx.fillStyle='#d7e4ea';ctx.fillRect(-4*s,-1.8*s,8*s,3.6*s);ctx.restore();}
  }
  ctx.fillStyle='#13332f';ctx.beginPath();ctx.moveTo(c.body_front_cm*s-3*s,0);ctx.lineTo(c.body_front_cm*s-11*s,-4*s);ctx.lineTo(c.body_front_cm*s-11*s,4*s);ctx.closePath();ctx.fill();ctx.restore();
  if(f.contact_point){const p=xy(...f.contact_point);ctx.strokeStyle='#ff978c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(...p,17,0,Math.PI*2);ctx.stroke();}
  if(editing&&dragging?.mode==='wall'&&hover){path([dragging.point,hover]);ctx.strokeStyle='#efb77c';ctx.lineWidth=3;ctx.setLineDash([6,4]);ctx.stroke();ctx.setLineDash([]);}
  if(editing&&hover){const p=xy(...hover);ctx.strokeStyle='#a3bed780';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p[0]-8,p[1]);ctx.lineTo(p[0]+8,p[1]);ctx.moveTo(p[0],p[1]-8);ctx.lineTo(p[0],p[1]+8);ctx.stroke();}
  $('map-title').textContent=course.name;
}
function fmt(n,d=1){return Number.isFinite(n)?n.toFixed(d):'—';}
function telemetry(){
  const f=shownFrame();
  if(!f){
    $('m-time').innerHTML='0.00 <small>s</small>';$('m-speed').innerHTML='0.0 <small>cm/s</small>';$('m-handle').innerHTML='0.0 <small>%</small>';
    $('m-progress').innerHTML=`0 <small>/ 0 of ${shownCourse().gates.length}</small>`;
    $('canvas-label').textContent=editing?'EDIT MODE · SIMULATOR SIDE ONLY':'READY · ORIGINAL CODE UNCHANGED';
    $('status').textContent=editing?'コース編集中':'準備完了';
    for(const name of ['Fr','FrLh','FrRh','RrLh','RrRh']){const el=$('sensor-'+name);if(el){el.querySelector('b').textContent='—';el.classList.remove('near','invalid');}}
    $('accel').textContent='0.0';$('pwm').textContent='— / —';$('phase').textContent='停止';$('cycle').textContent='—';
    $('comment').textContent='「開始」で元の実機プログラムを実行します。';$('debug').textContent='Gap — · PP — · 狭路 — · 後退パルス 0';
    $('log').textContent='Press Enter to start... はPC側で自動入力します。';
    return;
  }
  $('m-time').innerHTML=fmt(f.t,2)+' <small>s</small>';
  $('m-speed').innerHTML=fmt(f.speed)+' <small>cm/s</small>';
  $('m-handle').innerHTML=(f.requested_handle>=0?'+':'')+fmt(f.requested_handle)+' <small>%</small>';
  $('m-progress').innerHTML=`${f.collisions} <small>/ ${f.finished?f.gates_total:f.gate} of ${f.gates_total}</small>`;
  for(const name of ['Fr','FrLh','FrRh','RrLh','RrRh']){
    const el=$('sensor-'+name),v=f.measured?.[name],valid=Number.isFinite(v)&&v>0&&v<=500;
    el.querySelector('b').textContent=v==null?'—':valid?fmt(v,1):'ERR';
    el.classList.toggle('invalid',v!=null&&!valid);el.classList.toggle('near',valid&&v<35);
    el.title=Number.isFinite(v)?`元のMesure()の戻り値: ${v}`:'未計測';
  }
  $('accel').textContent=fmt(f.requested_accel);$('pwm').textContent=`${f.steer_pwm} / ${f.throttle_pwm}`;
  $('phase').textContent=phases[f.phase]||f.phase;$('cycle').textContent=fmt(f.dt,3)+' s';
  $('comment').textContent=f.comment||'測距中…';const d=f.debug||{};
  $('debug').textContent=`Gap ${d.gap||'—'} · PP ${fmt(d.pp)} · P ${fmt(d.p)} / D ${fmt(d.d)} · 狭路 ${d.narrow?'ON':'OFF'} · 後退パルス ${f.reverse_pulses}`;
  const txt=(f.logs||[]).map(x=>`[${fmt(x.t,3)}] ${x.text}`).join('\n');if($('log').textContent!==txt){$('log').textContent=txt;$('log').scrollTop=$('log').scrollHeight;}
  const status=replay?'リプレイ':f.status==='paused'?'一時停止':f.status==='running'?'実行中':reasons[f.reason]||'終了';
  $('status').textContent=status;
  $('canvas-label').textContent=(replay?'REPLAY':f.status.toUpperCase())+' · '+fmt(f.t,2)+' s · '+(phases[f.phase]||'');
}
function refresh(){
  if(!meta)return;
  const alive=state.alive&&!state.summary&&!state.error;
  $('pause').disabled=!alive||!!replay;$('step').disabled=!alive||!!replay;$('stop').disabled=!alive||!!replay;
  $('pause').textContent=state.frame?.status==='paused'?'再開':'一時停止';
  $('start').disabled=runningRequest||!$('program').value;
  $('program').disabled=alive;$('course').disabled=alive;$('upload').disabled=alive;
  $('edit-toggle').disabled=alive||!!replay;
  const summary=replay?.summary||(!preview?state.summary:null);
  $('result').hidden=!summary;
  if(summary){
    $('result-badge').textContent=summary.original_unchanged?'✓ 原本ハッシュ一致':'⚠ 原本の変更を検出';
    $('result-text').textContent=`${reasons[summary.reason]||summary.reason}。${fmt(summary.sim_seconds,2)}秒 / 走行距離 ${fmt(summary.distance_cm/100,2)}m / 接触 ${summary.collisions}回 / ${summary.laps}周。`+(summary.final_comment?' 最終判断：'+summary.final_comment:'');
    $('saved-path').textContent=replay?'保存済みリプレイを表示中。':state.saved?'保存先：'+state.out_dir:'ログを保存中…';
    document.querySelectorAll('[data-download]').forEach(b=>b.disabled=!state.saved||!!replay);
  }
  if(state.error)error(state.error);
  showHash();telemetry();draw();
}
async function poll(){try{state=await api('/api/state');refresh();}catch(e){$('status').textContent='接続を確認してください';}setTimeout(poll,120);}
async function control(cmd,value){try{await api('/api/control',{cmd,value});}catch(e){error(e.message);}}
function markPreview(){if(!state.alive){preview=true;replay=null;$('exit-replay').hidden=true;$('replay-range').hidden=true;refresh();}}
function ensureCustom(){if(!editableCourse){editableCourse=clone(courseForPreview());editableCourse.id='custom';editableCourse.name='カスタム / '+editableCourse.name;editableCourse.note='シミュレーター上で編集した検証コース。実機コードは変更していません。';}return editableCourse;}
function canvasPoint(e){const r=canvas.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
function snap(p){const step=Math.max(1,Number($('snap').value)||5);return p.map(v=>Math.round(v/step)*step);}
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('wheel',e=>{e.preventDefault();const p=canvasPoint(e),ratio=Math.exp(-e.deltaY*.001);const old=transform.s,next=Math.min(8,Math.max(.05,old*ratio));const k=next/old;transform.ox=p[0]-(p[0]-transform.ox)*k;transform.oy=p[1]-(p[1]-transform.oy)*k;transform.s=next;draw();},{passive:false});
canvas.addEventListener('pointerdown',e=>{
  canvas.setPointerCapture(e.pointerId);const p=canvasPoint(e);
  if(e.button===2||e.button===1||(!editing&&e.button===0)){dragging={mode:'pan',point:p,ox:transform.ox,oy:transform.oy};return;}
  if(!editing)return;
  const point=snap(world(...p)),mode=$('edit-mode').value;
  if(mode==='start'){const c=ensureCustom();c.start[0]=point[0];c.start[1]=point[1];$('start_x').value='';$('start_y').value='';updateCourseNote();draw();return;}
  if(mode==='delete'){
    const c=ensureCustom();let best=-1,dist=15/transform.s;
    c.walls.forEach((w,i)=>{const dx=w[2]-w[0],dy=w[3]-w[1],t=Math.max(0,Math.min(1,((point[0]-w[0])*dx+(point[1]-w[1])*dy)/(dx*dx+dy*dy||1)));const d=Math.hypot(point[0]-w[0]-t*dx,point[1]-w[1]-t*dy);if(d<dist){dist=d;best=i;}});
    if(best>=0)c.walls.splice(best,1);draw();return;
  }
  dragging={mode:'wall',point};hover=point;
});
canvas.addEventListener('pointermove',e=>{const p=canvasPoint(e),wp=world(...p);$('cursor-coordinate').textContent=`x ${wp[0].toFixed(0)} cm / y ${wp[1].toFixed(0)} cm`;
  if(dragging?.mode==='pan'){transform.ox=dragging.ox+p[0]-dragging.point[0];transform.oy=dragging.oy+p[1]-dragging.point[1];}
  hover=editing?snap(wp):null;if(dragging||editing)draw();
});
canvas.addEventListener('pointerup',e=>{if(dragging?.mode==='wall'){const end=snap(world(...canvasPoint(e)));if(Math.hypot(end[0]-dragging.point[0],end[1]-dragging.point[1])>=1){ensureCustom().walls.push([...dragging.point,...end]);updateCourseNote();}}dragging=null;draw();});
canvas.addEventListener('pointercancel',()=>{dragging=null;});
$('fit').addEventListener('click',fit);
['show-rays','show-trail','show-goal'].forEach(id=>$(id).addEventListener('change',draw));
$('start').addEventListener('click',async()=>{
  error('');runningRequest=true;replay=null;editing=false;$('editor-tools').hidden=true;$('edit-toggle').textContent='コース編集';
  $('exit-replay').hidden=true;$('replay-range').hidden=true;
  try{const c=collectConfig();await api('/api/start',{program:$('program').value,config:c});cfg=c;preview=false;state=await api('/api/state');fittedKey='';}
  catch(e){error(e.message);}finally{runningRequest=false;refresh();}
});
$('pause').addEventListener('click',()=>control(state.frame?.status==='paused'?'resume':'pause'));
$('step').addEventListener('click',()=>control('step'));
$('stop').addEventListener('click',()=>control('stop'));
$('realtime').addEventListener('change',()=>{if(state.alive)control('speed',Number($('realtime').value));});
$('program').addEventListener('change',()=>{markPreview();showHash();});
$('course').addEventListener('change',()=>{editableCourse=null;optional.forEach(k=>$(k).value='');fittedKey='';updateCourseNote();markPreview();});
[...numeric,...optional,...selectors,'stop_on_collision','stop_on_finish'].forEach(id=>$(id).addEventListener('change',()=>{if(id!=='realtime')markPreview();if(['body_front_cm','body_rear_cm','wheelbase_cm','body_width_cm'].includes(id))updateDimensionSummary();}));
$('upload').addEventListener('change',async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    if(file.size>2000000)throw new Error('Pythonファイルは2 MB以内にしてください。');
    const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
    const response=await api('/api/upload',{name:file.name,base64:btoa(binary)});meta.programs=response.programs;setPrograms(response.programs,response.name);markPreview();error('');
  }catch(ex){error(ex.message);}e.target.value='';
});
$('edit-toggle').addEventListener('click',()=>{editing=!editing;preview=true;$('editor-tools').hidden=!editing;$('edit-toggle').textContent=editing?'編集を終了':'コース編集';refresh();});
$('undo-wall').addEventListener('click',()=>{if(editableCourse)editableCourse.walls.pop();draw();});
$('export-course').addEventListener('click',()=>downloadJSON('course.json',clone(courseForPreview())));
$('import-course').addEventListener('change',async e=>{try{const c=JSON.parse(await e.target.files[0].text());if(!c.outer||!c.start||!c.walls||!c.gates)throw new Error('コースJSONに outer/start/walls/gates が必要です。');editableCourse=c;editableCourse.id='custom';markPreview();updateCourseNote();fittedKey='';fit();}catch(ex){error(ex.message);}e.target.value='';});
$('apply-config').addEventListener('click',()=>{try{const c={...clone(meta.defaults),...JSON.parse($('advanced').value)};fillControls(c);markPreview();fittedKey='';fit();error('');}catch(e){error(e.message);}});
$('export-config').addEventListener('click',()=>{try{const c=collectConfig();$('advanced').value=JSON.stringify(c,null,2);downloadJSON('simulator_config.json',c);}catch(e){error(e.message);}});
$('import-config').addEventListener('change',async e=>{try{fillControls({...clone(meta.defaults),...JSON.parse(await e.target.files[0].text())});markPreview();fittedKey='';fit();error('');}catch(ex){error(ex.message);}e.target.value='';});
$('copy-log').addEventListener('click',()=>navigator.clipboard.writeText($('log').textContent).catch(e=>error(e.message)));
document.querySelectorAll('[data-download]').forEach(b=>b.addEventListener('click',()=>{const a=document.createElement('a');a.href='/api/download?kind='+b.dataset.download;a.download='';a.click();}));
$('import-replay').addEventListener('change',async e=>{try{
  const file=e.target.files[0];if(file.size>100000000)throw new Error('リプレイは100 MB以内にしてください。');
  const data=JSON.parse(await file.text());if(!Array.isArray(data.frames)||!data.frames.length||!data.course||!data.config)throw new Error('replay.json を選んでください。');
  replay=data;replayIndex=data.frames.length-1;$('replay-range').max=data.frames.length-1;$('replay-range').value=replayIndex;$('replay-range').hidden=false;$('exit-replay').hidden=false;
  $('replay-label').textContent='スライダーで走行時点を選択。元プログラムの測距・判断・PWMを表示します。';fittedKey='';refresh();
}catch(ex){error(ex.message);}e.target.value='';});
$('replay-range').addEventListener('input',e=>{replayIndex=Number(e.target.value);refresh();});
$('exit-replay').addEventListener('click',()=>{replay=null;preview=!state.started;$('replay-range').hidden=true;$('exit-replay').hidden=true;fittedKey='';refresh();});
new ResizeObserver(()=>{if(meta)fit();}).observe(canvas.parentElement);
async function init(){
  try{
    [meta,state]=await Promise.all([api('/api/meta'),api('/api/state')]);
    for(const c of meta.courses){const o=document.createElement('option');o.value=c.id;o.textContent=c.name;$('course').append(o);}
    setPrograms(meta.programs,state.program);fillControls(state.config||meta.defaults);preview=!state.started;
    for(const name of ['Fr','FrLh','FrRh','RrLh','RrRh']){const div=document.createElement('div');div.id='sensor-'+name;div.className='sensor-card'+(name.startsWith('Rr')?' side':'');const span=document.createElement('span');span.textContent=name;const b=document.createElement('b');b.textContent='—';const small=document.createElement('small');small.textContent='cm';div.append(span,b,small);$('sensor-cards').append(div);}
    fit();refresh();poll();
  }catch(e){error('起動できません：'+e.message);}
}
init();
