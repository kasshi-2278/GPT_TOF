"""Current course/settings + missing legacy execution runtime.

This adapter does NOT recreate the missing HC-SR04 acoustic model. Unsupported
current-trial keys raise a diagnostic; only explicit compatible profiles run.
"""
import json
from pathlib import Path
from legacy_runtime import engine as legacy

ROOT = Path(__file__).resolve().parent
CURRENT_SETTINGS = json.loads((ROOT / 'configs/current_trial.json').read_text(encoding='utf-8'))
CURRENT_COURSE = json.loads((ROOT / 'configs/current_course.json').read_text(encoding='utf-8'))
# Retain every shared current setting. Acoustic keys are intentionally NOT
# accepted/ignored: compatibility profiles explicitly select geometric rays.
DEFAULTS = json.loads(json.dumps(legacy.DEFAULTS))
DEFAULTS.update({k:v for k,v in CURRENT_SETTINGS.items() if k in DEFAULTS})
DEFAULTS['custom_course'] = CURRENT_COURSE
COURSE_IDS = ['diagram_v4']
MODEL_NOTE = '旧実行基盤の幾何射線モデル。後期HC-SR04音響モデルは未復元。'

def make_course(key):
    if key != 'diagram_v4':
        raise ValueError('Only the preserved current diagram_v4 course is available')
    return json.loads(json.dumps(CURRENT_COURSE))

def validate_config(settings=None):
    settings = settings or {}
    unsupported = set(settings) - set(legacy.DEFAULTS)
    if unsupported:
        raise ValueError('This restored runtime cannot reproduce the later acoustic model; '
                         'unsupported settings: '+', '.join(sorted(unsupported))+
                         '. Use configs/legacy_geometric.json explicitly; do not discard acoustic settings silently.')
    cfg = json.loads(json.dumps(DEFAULTS))
    cfg.update(settings)
    if cfg['course'] not in COURSE_IDS:
        raise ValueError('Legacy example courses are not part of the restored current simulator')
    if cfg.get('custom_course') is None:
        cfg['custom_course'] = make_course(cfg['course'])
    return legacy.validate_config(cfg)

def execute(program, settings=None, send=None, conn=None):
    result = legacy.execute(program, validate_config(settings), send=send, conn=conn)
    result['summary']['runtime_profile'] = 'legacy_geometric_with_current_course'
    result['summary']['acoustic_model_restored'] = False
    result['summary']['model_note'] = MODEL_NOTE
    return result

def save_result(result, out_dir):
    # Keep the execution runtime and raw outputs unchanged. Add a portable
    # view of the saved result beside the existing JSON/CSV/text files.
    from visual_logs import save_report
    saved = legacy.save_result(result, out_dir)
    save_report(result, Path(out_dir) / 'visual_log.html')
    return saved


def worker(program, config, conn, out_dir):
    try:
        result = execute(program, config, send=conn.send, conn=conn)
        save_result(result, out_dir)
        conn.send({'type':'saved','out_dir':str(out_dir)})
    except BaseException as exc:
        try: conn.send({'type':'error','error':str(exc)})
        except (EOFError, BrokenPipeError, OSError): pass
    finally:
        conn.close()

# Expose the unmodified runtime's geometry/classes for diagnostics and UI.
for _name in ('World','Runner','SimulationEnd','NAMES','validate_course','ray_segment',
              'segments_intersect','rect','point_in_polygon'):
    globals()[_name] = getattr(legacy,_name)
