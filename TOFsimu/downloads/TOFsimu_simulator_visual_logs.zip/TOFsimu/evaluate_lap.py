"""Post-process the same ordered regions used by the independent checker.
This is not a gate configuration or steering input to the execution runtime.
"""
import argparse
import json
import math
from pathlib import Path

def evaluate(frames):
    gate=0;passes=[]
    for f in frames:
        x,y=f['x'],f['y']
        yes=((gate==0 and x>900 and y>500) or (gate==1 and x<400 and y>550)
             or (gate==2 and x<200 and y<300)
             or (gate==3 and x>=660 and 110<y<230 and math.cos(f['heading'])>.8))
        if yes:
            gate+=1;passes.append(dict(checkpoint=gate,t=f['t'],x=x,y=y))
            if gate==4:break
    return dict(evaluation='Post-processing only; no gates supplied to controller',
                checkpoints=passes,one_circuit=gate==4)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('replay',type=Path);args=p.parse_args()
    result=evaluate(json.loads(args.replay.read_text(encoding='utf-8'))['frames'])
    out=args.replay.with_name('lap_evaluation.json');out.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
