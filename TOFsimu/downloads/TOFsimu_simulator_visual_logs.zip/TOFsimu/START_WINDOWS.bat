@echo off
cd /d "%~dp0"
python simulator.py --config configs/legacy_geometric.json
pause
