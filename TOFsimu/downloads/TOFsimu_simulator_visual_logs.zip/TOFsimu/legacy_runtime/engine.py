"""Deterministic PC-only GPIO/PCA9685 emulator. Python 3.8+, standard library.

The supplied program is executed as __main__ from its ORIGINAL bytes. No AST
rewrites, controller replacements, constant overrides or Mesure monkeypatches.
The fake hardware modules exist only inside this execution context/worker.
"""
import builtins
import csv
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import random
import runpy
import sys
import time as real_time
import traceback
import types
from collections import deque

# Load runpy's helper before virtualizing time; these modules retain real clocks.
import pkgutil

NAMES = ('Fr', 'FrLh', 'FrRh', 'RrLh', 'RrRh')
DEFAULTS = {
    'course': 'diagram_v4', 'seconds': 90.0, 'realtime': 1.0, 'seed': 1,
    'stop_on_collision': True, 'stop_on_finish': True, 'stuck_seconds': 12.0,
    'wheelbase_cm': 17.0, 'body_width_cm': 20.0,
    'body_front_cm': 24.0, 'body_rear_cm': 4.0,
    'max_steer_deg': 25.0, 'servo_tau_s': 0.07,
    'servo_rate_deg_s': 180.0, 'motor_accel_cm_s2': 120.0,
    'brake_cm_s2': 240.0, 'speed_scale': 1.0,
    'speed_table': [[-100, -75], [-50, -35], [0, 0], [30, 30], [50, 55], [80, 100], [100, 125]],
    'scan_overhead_s': 0.02, 'scan_jitter_s': 0.0, 'pwm_write_s': 0.001,
    'range_max_cm': 340.0, 'sensor_noise_cm': 0.0, 'beam_half_angle_deg': 0.0,
    'dropout_probability': 0.0, 'no_hit_mode': 'capped_echo',
    'fault_sensor': '', 'fault_mode': 'none', 'fault_after_s': 0.0,
    'start_x': None, 'start_y': None, 'start_heading_deg': None,
    'sensors': [
        # User-specified directions; positions are examples inside the FRONT HALF
        # of a 28cm x 20cm body. Rear axle is x=0, front bumper x=+24cm.
        # Despite their legacy Rr* names, BOTH side-facing sensors are up front.
        {'name': 'Fr', 'trig': 15, 'echo': 33, 'x': 23.0, 'y': 0.0, 'angle': 0.0},
        {'name': 'FrLh', 'trig': 13, 'echo': 40, 'x': 20.0, 'y': 7.5, 'angle': 45.0},
        {'name': 'FrRh', 'trig': 32, 'echo': 31, 'x': 20.0, 'y': -7.5, 'angle': -45.0},
        {'name': 'RrLh', 'trig': 35, 'echo': 37, 'x': 14.0, 'y': 9.0, 'angle': 90.0},
        {'name': 'RrRh', 'trig': 36, 'echo': 38, 'x': 14.0, 'y': -9.0, 'angle': -90.0}],
    'pwm': {'steer_channel': 1, 'right': 330, 'center': 435, 'left': 540,
            'throttle_channel': 7, 'forward': 500, 'neutral': 375, 'reverse': 220},
    'custom_course': None,
}

def clip(x, a, b):
    return max(a, min(b, x))

def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]

def edges(polygon):
    return [[*polygon[i], *polygon[(i + 1) % len(polygon)]] for i in range(len(polygon))]

def rect(x1, y1, x2, y2):
    return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]

def ray_segment(ox, oy, dx, dy, wall):
    ax, ay, bx, by = wall
    sx, sy = bx - ax, by - ay
    denom = dx * sy - dy * sx
    if abs(denom) < 1e-10:
        return None
    qx, qy = ax - ox, ay - oy
    t = (qx * sy - qy * sx) / denom
    u = (qx * dy - qy * dx) / denom
    if t >= -1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return max(0.0, t)
    return None

def segments_intersect(a, b):
    ax, ay, bx, by = a
    cx, cy, dx, dy = b
    v = (bx - ax, by - ay)
    w = (dx - cx, dy - cy)
    d = cross(v, w)
    q = (cx - ax, cy - ay)
    if abs(d) < 1e-10:
        if abs(cross(q, v)) > 1e-8:
            return False
        return (max(min(ax, bx), min(cx, dx)) <= min(max(ax, bx), max(cx, dx)) + 1e-8
                and max(min(ay, by), min(cy, dy)) <= min(max(ay, by), max(cy, dy)) + 1e-8)
    t, u = cross(q, w) / d, cross(q, v) / d
    return -1e-8 <= t <= 1 + 1e-8 and -1e-8 <= u <= 1 + 1e-8

def point_in_polygon(x, y, poly):
    inside = False
    for ax, ay, bx, by in edges(poly):
        if ((ay > y) != (by > y)) and x < (bx - ax) * (y - ay) / (by - ay) + ax:
            inside = not inside
    return inside

def make_course(key):
    """All full-course geometry is an editable demonstration, NOT a survey."""
    if key == 'diagram_v4':
        # Approximate tracing of the supplied 1030cm-wide screenshot (not CAD).
        # Pixel-to-cm conversion: grid 50cm ~ 44.65px, with a 80cm margin.
        # Only apparent boards/walls are modeled; cyan/orange/green shaded areas,
        # training paths and sensor rays are NOT obstacles.
        def pt(p):
            return [round(80.0 + (p[0]-99.0)/0.8932,2),
                    round(100.0 + (737.0-p[1])/0.8932,2)]
        paths = [
            [(121,238),(502,238)], [(528,238),(880,238)],
            [(121,238),(99,323),(99,737),(262,737)],
            [(880,238),(965,270),(1019,336),(1019,420)],
            [(1019,420),(943,488),(1019,554),(1019,667),(979,737)],
            [(593,737),(979,737)],
            [(262,737),(262,782),(372,782),(372,737)],
            [(372,737),(372,782),(483,782),(483,737)],
            [(483,737),(483,782),(593,782),(593,737)],
            [(175,238),(175,422)],
            [(250,393),(323,363),(483,363)],
            [(527,363),(769,363)],
            [(250,393),(250,554),(323,613),(813,613)],
            [(381,301),(537,301)],
            [(421,488),(673,488)],[(770,488),(943,488)],
        ]
        walls=[]
        for path in paths:
            for a,b in zip(path,path[1:]):
                ax,ay=pt(a);bx,by=pt(b)
                walls.append([ax,ay,bx,by])
        start=pt((175,467))
        # User-confirmed counterclockwise travel: descend the left corridor first.
        # Screen Y goes downward; our world Y goes upward, so heading=-90deg.
        return {
            'id':'diagram_v4', 'name':'提供図面 V4（反時計回り・線分を概略再現）',
            'width':1190,'height':760, 'outer':rect(0,0,1190,760),
            'solids':[], 'walls':walls,'start':[start[0],start[1],-90.0],
            'gates':[], 'loop':False,
            'note':'画像の板の配置を近似。反時計回り指定に合わせ、左側スタート地点は下方向（-90°）を向きます。センサー5個はすべて車体前半分。元の実機コードは無変更です。壁の寸法・開口は仮定。ガイド線で自動誘導しません。ゲート未設定につき完走判定はしません。',
            'labels':[[*pt((175,510)),'反時計回り ↓'], [*pt((710,500)),'中央の板（要確認）'],[*pt((380,300)),'上段'],[*pt((760,630)),'下段'],[*pt((335,765)),'P1'],[*pt((425,765)),'P2'],[*pt((545,765)),'P3']]
        }
    if key in ('oval', 'divider_loop'):
        outer = rect(0, 0, 1030, 700)
        solids = [rect(140, 140, 890, 560)]
        if key == 'divider_loop':
            solids.append(rect(450, 69, 640, 71))
        return {
            'id': key,
            'name': '中央仕切り板つき周回（仮コース）' if key == 'divider_loop' else '反時計回り周回（仮コース）',
            'width': 1030, 'height': 700, 'outer': outer, 'solids': solids,
            'walls': [], 'start': [180, 48 if key == 'divider_loop' else 70, 0],
            'gates': [[890, 350, 1030, 350, 0, 1], [515, 560, 515, 700, -1, 0],
                      [0, 350, 140, 350, 0, -1], [180, 0, 180, 140, 1, 0]],
            'loop': True, 'note': '外周1030×700cmは検証用仮寸法。通路140cm、中央板厚2cmで各側約69cm。板位置も仮定。',
            'labels': [[530, 355, '仮想コース / 反時計回り'], [545, 95, '中央仕切り板' if key == 'divider_loop' else '通路140 cm']]}
    if key in ('straight_140', 'narrow_70', 'reverse_front'):
        width = 70 if key == 'narrow_70' else 280 if key == 'reverse_front' else 140
        length = 600 if key == 'reverse_front' else 1000
        start = [540, 140, 0] if key == 'reverse_front' else [120, width / 2, 0]
        return {'id': key, 'name': {'straight_140': '直線140cm', 'narrow_70': '狭路70cm', 'reverse_front': '正面接近・後退手順テスト'}[key],
                'width': length, 'height': width, 'outer': rect(0, 0, length, width),
                'solids': [], 'walls': [], 'start': start,
                'gates': [] if key == 'reverse_front' else [[800, 0, 800, width, 1, 0]],
                'loop': False, 'note': '長さ・開始位置は検証用。後退テストは正面30cmから開始。', 'labels': []}
    if key == 'corner_left':
        poly = [[0, 0], [600, 0], [600, 600], [460, 600], [460, 140], [0, 140]]
        return {'id': key, 'name': '左90度カーブ', 'width': 600, 'height': 600, 'outer': poly,
                'solids': [], 'walls': [], 'start': [120, 70, 0],
                'gates': [[460, 450, 600, 450, 0, 1]], 'loop': False,
                'note': '幅140cmのL字。実コースの再現ではなく旋回応答の検証用。', 'labels': []}
    if key == 'shortcut_demo':
        return {'id': key, 'name': '右Uターン→上側開口（模式コース）',
                'width': 1030, 'height': 700, 'outer': rect(0, 0, 1030, 700),
                'solids': [rect(0, 138, 890, 142), rect(140, 278, 650, 282),
                           rect(810, 278, 1030, 282), rect(0, 418, 890, 422)],
                'walls': [], 'start': [180, 70, 0],
                'gates': [[890, 140, 1030, 140, 0, 1], [890, 420, 1030, 420, 0, 1],
                          [180, 422, 180, 700, -1, 0]], 'loop': False,
                'note': '右へ発進→右端Uターン→左向き時の右側（上側）に開口。実画像の形状・位置を保証しない模式図。',
                'labels': [[725, 300, '上側への開口'], [490, 615, '模式コース / 実図面ではありません']]}
    raise ValueError('Unknown course: ' + str(key))

COURSE_IDS = ['diagram_v4', 'divider_loop', 'oval', 'straight_140', 'narrow_70', 'corner_left', 'reverse_front', 'shortcut_demo']

def validate_config(settings=None):
    cfg = json.loads(json.dumps(DEFAULTS))
    if settings:
        unknown = set(settings) - set(cfg)
        if unknown:
            raise ValueError('Unknown setting(s): ' + ', '.join(sorted(unknown)))
        cfg.update(settings)
    bounds = {
        'seconds': (0.1, 3600), 'realtime': (0, 50), 'wheelbase_cm': (5, 150),
        'body_width_cm': (2, 150), 'body_front_cm': (1, 200), 'body_rear_cm': (0, 100),
        'max_steer_deg': (1, 60), 'servo_tau_s': (0, 2), 'servo_rate_deg_s': (1, 2000),
        'motor_accel_cm_s2': (1, 3000), 'brake_cm_s2': (1, 5000), 'speed_scale': (0.01, 10),
        'scan_overhead_s': (0, 2), 'scan_jitter_s': (0, 1), 'pwm_write_s': (0, 0.1),
        'range_max_cm': (10, 340), 'sensor_noise_cm': (0, 50), 'beam_half_angle_deg': (0, 45),
        'dropout_probability': (0, 1), 'fault_after_s': (0, 3600), 'stuck_seconds': (0, 120)}
    for key, (low, high) in bounds.items():
        x = float(cfg[key])
        if not math.isfinite(x) or not low <= x <= high:
            raise ValueError('{} must be between {} and {}'.format(key, low, high))
        cfg[key] = x
    cfg['seed'] = int(cfg['seed'])
    if cfg['fault_sensor'] not in ('', *NAMES):
        raise ValueError('Unknown fault sensor')
    if cfg['fault_mode'] not in ('none', 'no_echo', 'near_10', 'far_340'):
        raise ValueError('Unknown fault mode')
    if cfg['no_hit_mode'] not in ('capped_echo', 'no_echo'):
        raise ValueError('Unknown no-hit mode')
    sensors = cfg['sensors']
    if len(sensors) != 5 or set(s['name'] for s in sensors) != set(NAMES):
        raise ValueError('Exactly five named sensors are required')
    used = []
    for s in sensors:
        for field in ('x', 'y', 'angle'):
            s[field] = float(s[field])
            if not math.isfinite(s[field]) or abs(s[field]) > 10000:
                raise ValueError('Invalid sensor geometry')
        for field in ('trig', 'echo'):
            s[field] = int(s[field])
            used.append(s[field])
    if len(set(used)) != len(used):
        raise ValueError('Sensor GPIO pins must be unique')
    table = cfg['speed_table']
    if len(table) < 3:
        raise ValueError('Speed table needs at least 3 points')
    table = [[float(p[0]), float(p[1])] for p in table]
    if any(not all(math.isfinite(x) for x in p) for p in table):
        raise ValueError('Invalid speed table')
    if any(table[i][0] >= table[i+1][0] for i in range(len(table)-1)):
        raise ValueError('Speed table throttle values must be strictly increasing')
    if not any(abs(a) < 1e-10 and abs(v) < 1e-10 for a, v in table):
        raise ValueError('Speed table must include [0,0]')
    if table[0][0] > -100 or table[-1][0] < 100:
        raise ValueError('Speed table must cover -100 to +100')
    if any(abs(v) > 2000 or a * v < 0 for a, v in table):
        raise ValueError('Invalid speed-table direction or excessive speed')
    cfg['speed_table'] = table
    p = cfg['pwm']
    for k in ('steer_channel', 'throttle_channel', 'right', 'center', 'left', 'reverse', 'neutral', 'forward'):
        p[k] = int(p[k])
    if not (p['right'] < p['center'] < p['left'] and p['reverse'] < p['neutral'] < p['forward']):
        raise ValueError('PWM profile endpoint order is invalid')
    if p['steer_channel'] == p['throttle_channel']:
        raise ValueError('PWM channels must differ')
    course = cfg['custom_course'] if cfg['custom_course'] is not None else make_course(cfg['course'])
    validate_course(course)
    cfg['custom_course'] = course if cfg['custom_course'] is not None else None
    for k in ('start_x', 'start_y', 'start_heading_deg'):
        if cfg[k] is not None:
            cfg[k] = float(cfg[k])
            if not math.isfinite(cfg[k]):
                raise ValueError('Invalid start pose')
    return cfg

def validate_course(course):
    for key in ('width', 'height', 'outer', 'solids', 'walls', 'start', 'gates'):
        if key not in course:
            raise ValueError('Course field missing: ' + key)
    for key in ('width', 'height'):
        if not math.isfinite(float(course[key])) or not 10 <= float(course[key]) <= 20000:
            raise ValueError('Invalid course dimensions')
    if len(course['outer']) < 3 or len(course['start']) != 3:
        raise ValueError('Invalid course boundary or start pose')
    if sum(len(p) for p in course['solids']) + len(course['walls']) + len(course['outer']) > 1500:
        raise ValueError('Course geometry too large (limit: 1500 edges)')
    for poly in [course['outer']] + course['solids']:
        if len(poly) < 3 or any(len(v) != 2 for v in poly):
            raise ValueError('Each polygon needs at least 3 [x,y] vertices')
    for wall in course['walls']:
        if len(wall) != 4:
            raise ValueError('Walls use [x1,y1,x2,y2]')
    for gate in course['gates']:
        if len(gate) != 6:
            raise ValueError('Gates use [x1,y1,x2,y2,normal_x,normal_y]')
    def numbers(x):
        if isinstance(x, (list, tuple)):
            return all(numbers(v) for v in x)
        return isinstance(x, (int, float)) and math.isfinite(x) and abs(x) <= 100000
    if not all(numbers(course[k]) for k in ('outer', 'solids', 'walls', 'start', 'gates')):
        raise ValueError('Course coordinates must be finite numbers')
    course.setdefault('name', 'カスタムコース')
    course.setdefault('id', 'custom')
    course.setdefault('loop', False)
    course.setdefault('labels', [])
    course.setdefault('note', 'ユーザー定義コース')
    return course

class SimulationEnd(BaseException):
    pass

class World:
    def __init__(self, cfg):
        self.cfg = cfg
        self.course = json.loads(json.dumps(cfg['custom_course'] or make_course(cfg['course'])))
        self.walls = edges(self.course['outer'])
        for solid in self.course['solids']:
            self.walls.extend(edges(solid))
        self.walls.extend(self.course['walls'])
        start = list(self.course['start'])
        for i, k in enumerate(('start_x', 'start_y', 'start_heading_deg')):
            if cfg[k] is not None:
                start[i] = cfg[k]
        self.x, self.y, heading = start
        self.heading = math.radians(heading)
        self.speed = self.steer = self.handle = self.throttle = 0.0
        self.phase = 'neutral'
        self.distance = self.reverse_distance = 0.0
        self.collisions = 0
        self.contact = False
        self.gate = self.laps = self.finished = 0
        self.contact_point = None
        self.min_clearance = float('inf')
        self.elapsed = 0.0
        if self.collides():
            raise ValueError('開始位置で車体が壁に重なっています。車体・開始位置を確認してください。')

    def transform(self, x, y):
        c, s = math.cos(self.heading), math.sin(self.heading)
        return self.x + c * x - s * y, self.y + s * x + c * y

    def body(self):
        f, r, w = self.cfg['body_front_cm'], self.cfg['body_rear_cm'], self.cfg['body_width_cm'] / 2
        return [self.transform(x, y) for x, y in ((f, w), (-r, w), (-r, -w), (f, -w))]

    def collides(self):
        body = self.body()
        # Endpoints inside the body catch thin dividers fully surrounded by it.
        c, s = math.cos(self.heading), math.sin(self.heading)
        f, r, half = self.cfg['body_front_cm'], self.cfg['body_rear_cm'], self.cfg['body_width_cm'] / 2
        def in_body(x, y):
            dx, dy = x - self.x, y - self.y
            bx, by = c * dx + s * dy, -s * dx + c * dy
            return -r <= bx <= f and -half <= by <= half
        minx, maxx = min(p[0] for p in body), max(p[0] for p in body)
        miny, maxy = min(p[1] for p in body), max(p[1] for p in body)
        car_edges = edges(body)
        for wall in self.walls:
            ax, ay, bx, by = wall
            if max(ax, bx) < minx or min(ax, bx) > maxx or max(ay, by) < miny or min(ay, by) > maxy:
                continue
            if in_body(ax, ay) or in_body(bx, by) or any(segments_intersect(e, wall) for e in car_edges):
                return True
        if not point_in_polygon(self.x, self.y, self.course['outer']):
            return True
        return any(point_in_polygon(self.x, self.y, poly) for poly in self.course['solids'])

    def ray(self, sensor, angle_offset=0.0):
        ox, oy = self.transform(sensor['x'], sensor['y'])
        a = self.heading + math.radians(sensor['angle'] + angle_offset)
        dx, dy = math.cos(a), math.sin(a)
        maximum = self.cfg['range_max_cm']
        distance, hit = maximum, False
        for wall in self.walls:
            d = ray_segment(ox, oy, dx, dy, wall)
            if d is not None and d <= distance:
                distance, hit = d, True
        return distance, hit, [ox, oy, ox + distance * dx, oy + distance * dy]

    def speed_for_throttle(self):
        if self.phase != 'forward' and self.phase != 'reverse':
            return 0.0
        table = self.cfg['speed_table']
        x = clip(self.throttle, table[0][0], table[-1][0])
        for a, b in zip(table, table[1:]):
            if a[0] <= x <= b[0]:
                return (a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])) * self.cfg['speed_scale']
        return 0.0

    def step(self, dt):
        self.elapsed += dt
        cfg = self.cfg
        target_steer = math.radians(cfg['max_steer_deg'] * self.handle / 100.0)
        alpha = 1.0 if cfg['servo_tau_s'] == 0 else 1 - math.exp(-dt / cfg['servo_tau_s'])
        change = (target_steer - self.steer) * alpha
        limit = math.radians(cfg['servo_rate_deg_s']) * dt
        self.steer += clip(change, -limit, limit)
        target = self.speed_for_throttle()
        old_speed = self.speed
        rate = cfg['brake_cm_s2'] if target == 0 or old_speed * target < 0 or abs(target) < abs(old_speed) else cfg['motor_accel_cm_s2']
        self.speed += clip(target - self.speed, -rate * dt, rate * dt)
        v = (self.speed + old_speed) * 0.5
        dh = v * math.tan(self.steer) / cfg['wheelbase_cm'] * dt
        old = (self.x, self.y, self.heading)
        self.x += v * math.cos(self.heading + dh / 2) * dt
        self.y += v * math.sin(self.heading + dh / 2) * dt
        self.heading = math.atan2(math.sin(self.heading + dh), math.cos(self.heading + dh))
        if abs(v) > 1e-8 and self.collides():
            self.contact_point = [self.x, self.y]
            self.x, self.y, self.heading = old
            self.speed = 0.0
            if not self.contact:
                self.collisions += 1
            self.contact = True
            return 'collision' if cfg['stop_on_collision'] else None
        self.contact = False
        traveled = abs(v) * dt
        self.distance += traveled
        if v < 0:
            self.reverse_distance += traveled
        gates = self.course['gates']
        if gates and traveled > 0:
            g = gates[self.gate]
            motion = [old[0], old[1], self.x, self.y]
            if ((self.x - old[0]) * g[4] + (self.y - old[1]) * g[5] > 1e-8
                    and segments_intersect(motion, g[:4])):
                self.gate += 1
                if self.gate == len(gates):
                    self.finished += 1
                    if self.course.get('loop'):
                        self.laps += 1
                    self.gate = 0
                    if cfg['stop_on_finish']:
                        return 'finished'
        return None

class Runner:
    def __init__(self, program, cfg, send=None, conn=None):
        self.program = Path(program).resolve()
        self.original_bytes = self.program.read_bytes()
        self.sha = hashlib.sha256(self.original_bytes).hexdigest()
        self.cfg, self.world = cfg, World(cfg)
        self.rng = random.Random(cfg['seed'])
        self.t = 0.0
        self.real_start = real_time.perf_counter()
        self.pace_real = self.real_start
        self.pace_sim = 0.0
        self.send, self.conn = send, conn
        self.status = 'running'
        self.reason = ''
        self.halted = False
        self.paused = False
        self.step_until = None
        self.next_publish = 0.0
        self.next_poll = 0.0
        self.frames = []
        self.logs = deque(maxlen=100)
        self.all_logs = []
        self.pwm_events = []
        self.pwm_count = 0
        self.measured = {}
        self.generated = {}
        self.rays = {}
        self.cycles = 0
        self.requested_handle = self.requested_accel = 0.0
        self.cycle_dt = 0.0
        self.debug = {}
        self.decision_pose = None
        self.comment = ''
        self.steer_pwm = cfg['pwm']['center']
        self.throttle_pwm = cfg['pwm']['neutral']
        self.reverse_armed = False
        self.brake_started = None
        self.neutral_started = None
        self.brake_completed = False
        self.reverse_pulses = self.brake_pulses = 0
        self.last_motion = 0.0
        self.anchor_pose = (self.world.x, self.world.y)
        self.steering_variation = 0.0
        self.last_handle = 0.0
        self.error = None

    def finish(self, reason):
        self.reason = reason
        self.halted = True
        raise SimulationEnd()

    def advance(self, dt):
        if self.halted:
            return
        if not math.isfinite(dt) or dt < 0:
            raise ValueError('Invalid virtual time advance')
        end = self.t + dt
        while self.t < end - 1e-12:
            h = min(0.01, end - self.t)
            # Step/pause and max-duration boundaries are not allowed to overshoot.
            if self.step_until is not None and self.t < self.step_until:
                h = min(h, self.step_until - self.t)
            h = min(h, max(1e-9, self.cfg['seconds'] - self.t))
            result = self.world.step(h)
            self.t += h
            if result:
                self.finish(result)
            if self.t >= self.cfg['seconds'] - 1e-9:
                self.finish('time_limit')
            if math.hypot(self.world.x - self.anchor_pose[0], self.world.y - self.anchor_pose[1]) > 2.0:
                self.last_motion = self.t
                self.anchor_pose = (self.world.x, self.world.y)
            if self.cfg['stuck_seconds'] and self.t - self.last_motion >= self.cfg['stuck_seconds']:
                self.finish('stuck')
            if self.t >= self.next_poll or (self.step_until is not None and self.t >= self.step_until - 1e-9):
                self.next_poll = self.t + 0.02
                self.poll()
            if self.t >= self.next_publish:
                self.next_publish = self.t + 0.08
                self.publish()
                self.pace()

    def poll(self):
        if self.step_until is not None and self.t >= self.step_until - 1e-9:
            self.step_until = None
            self.paused = True
        while True:
            if self.conn:
                while self.conn.poll():
                    message = self.conn.recv()
                    cmd = message.get('cmd')
                    if cmd == 'stop':
                        self.finish('stopped')
                    elif cmd == 'pause':
                        self.paused = True
                    elif cmd in ('resume', 'step'):
                        self.paused = False
                        self.step_until = self.t + 0.1 if cmd == 'step' else None
                        self.pace_real, self.pace_sim = real_time.perf_counter(), self.t
                    elif cmd == 'speed':
                        self.cfg['realtime'] = clip(float(message['value']), 0, 50)
                        self.pace_real, self.pace_sim = real_time.perf_counter(), self.t
            if not self.paused:
                return
            self.publish(store=False)
            real_time.sleep(0.08)

    def pace(self):
        rate = self.cfg['realtime']
        if not rate or not self.conn:
            return
        expected = self.pace_real + (self.t - self.pace_sim) / rate
        while real_time.perf_counter() < expected:
            self.poll()
            real_time.sleep(min(0.015, max(0.0, expected - real_time.perf_counter())))

    def snapshot(self):
        w = self.world
        return {'t': round(self.t, 6), 'status': 'paused' if self.paused else self.status,
                'reason': self.reason, 'x': w.x, 'y': w.y, 'heading': w.heading,
                'body': w.body(), 'speed': w.speed, 'steer_deg': math.degrees(w.steer),
                'handle': w.handle, 'accel': w.throttle, 'phase': w.phase,
                'requested_handle': self.requested_handle, 'requested_accel': self.requested_accel,
                'steer_pwm': self.steer_pwm, 'throttle_pwm': self.throttle_pwm,
                'measured': dict(self.measured), 'generated': dict(self.generated),
                'rays': dict(self.rays), 'debug': dict(self.debug), 'decision_pose': self.decision_pose, 'comment': self.comment,
                'dt': self.cycle_dt, 'cycles': self.cycles, 'collisions': w.collisions,
                'gate': w.gate, 'gates_total': len(w.course['gates']), 'laps': w.laps,
                'finished': w.finished, 'distance_cm': w.distance,
                'reverse_distance_cm': w.reverse_distance, 'reverse_pulses': self.reverse_pulses,
                'brake_pulses': self.brake_pulses, 'contact_point': w.contact_point,
                'realtime': self.cfg['realtime'], 'logs': list(self.logs)[-20:]}

    def publish(self, store=True):
        frame = self.snapshot()
        if store:
            self.frames.append(frame)
        if self.send:
            self.send({'type': 'frame', 'frame': frame})

    def log(self, *args, **kwargs):
        if kwargs.get('file') not in (None, sys.stdout, sys.stderr):
            return self.original_print(*args, **kwargs)
        sep, end = kwargs.get('sep', ' '), kwargs.get('end', '\n')
        text = sep.join(str(a) for a in args) + end
        for line in text.splitlines():
            entry = {'t': round(self.t, 4), 'text': line}
            self.logs.append(entry)
            self.all_logs.append(entry)

    def observe(self, caller, is_steer):
        if self.halted:
            return
        # Read-only access to the original main() frame for visualization.
        # No locals, class methods, state or return values are written.
        loc = caller.f_locals
        if 'Accel' not in loc or 'Handle' not in loc:
            return
        self.decision_pose = [self.world.x, self.world.y, self.world.heading]
        self.requested_accel = float(loc['Accel'])
        self.requested_handle = float(loc['Handle'])
        self.comment = str(loc.get('comment', ''))
        self.cycle_dt = float(loc.get('dt', 0))
        self.measured = {name: float(loc[name]) for name in NAMES if name in loc}
        controller = loc.get('controller')
        if controller is not None and isinstance(getattr(controller, 'debug', None), dict):
            self.debug = json.loads(json.dumps(controller.debug))
        if is_steer:
            self.cycles += 1
            self.steering_variation += abs(self.requested_handle - self.last_handle)
            self.last_handle = self.requested_handle

    def pwm(self, channel, on, off, caller):
        cfg, w = self.cfg['pwm'], self.world
        off = int(off)
        if on != 0 or not 0 <= off <= 4095:
            raise ValueError('This profile supports PCA9685 on=0 and off=0..4095 only')
        is_steer = channel == cfg['steer_channel']
        self.observe(caller, is_steer)
        if is_steer:
            self.steer_pwm = off
            span = cfg['left'] - cfg['center'] if off >= cfg['center'] else cfg['center'] - cfg['right']
            w.handle = clip((off - cfg['center']) / span * 100.0, -100, 100)
        elif channel == cfg['throttle_channel']:
            self.throttle_pwm = off
            span = cfg['forward'] - cfg['neutral'] if off >= cfg['neutral'] else cfg['neutral'] - cfg['reverse']
            throttle = clip((off - cfg['neutral']) / span * 100.0, -100, 100)
            prev_phase = w.phase
            w.throttle = throttle
            if throttle > 0:
                w.phase = 'forward'
                self.reverse_armed = self.brake_completed = False
                self.brake_started = self.neutral_started = None
            elif throttle == 0:
                if prev_phase == 'brake' and self.brake_started is not None:
                    self.brake_completed = self.t - self.brake_started >= 0.015
                if prev_phase != 'neutral':
                    self.neutral_started = self.t
                w.phase = 'neutral'
            else:
                if (self.brake_completed and self.neutral_started is not None
                        and self.t - self.neutral_started >= 0.015):
                    self.reverse_armed = True
                if self.reverse_armed:
                    w.phase = 'reverse'
                    if prev_phase != 'reverse':
                        self.reverse_pulses += 1
                else:
                    w.phase = 'brake'
                    if prev_phase != 'brake':
                        self.brake_pulses += 1
                        self.brake_started = self.t
        else:
            raise ValueError('PWM channel {} is not mapped in this profile'.format(channel))
        self.pwm_count += 1
        self.pwm_events.append({'t': round(self.t, 6), 'channel': channel, 'on': on, 'off': off,
                                'phase': w.phase, 'speed_cm_s': w.speed})
        self.advance(self.cfg['pwm_write_s'])

    def trigger(self, sensor):
        if sensor['name'] == 'Fr':
            overhead = max(0.0, self.cfg['scan_overhead_s'] + self.rng.gauss(0, self.cfg['scan_jitter_s']))
            self.advance(overhead)
        half = self.cfg['beam_half_angle_deg']
        offsets = [0] if half == 0 else [-half, -half/2, 0, half/2, half]
        candidates = [self.world.ray(sensor, a) for a in offsets]
        distance, hit, ray = min(candidates, key=lambda r: r[0])
        self.rays[sensor['name']] = {'line': ray, 'hit': hit, 't': self.t}
        no_echo = (not hit and self.cfg['no_hit_mode'] == 'no_echo')
        no_echo = no_echo or self.rng.random() < self.cfg['dropout_probability']
        mode = self.cfg['fault_mode'] if (sensor['name'] == self.cfg['fault_sensor']
                    and self.t >= self.cfg['fault_after_s']) else 'none'
        if mode == 'no_echo':
            no_echo = True
        elif mode == 'near_10':
            distance, no_echo = 10.0, False
        elif mode == 'far_340':
            distance, no_echo = 340.0, False
        if no_echo:
            self.generated[sensor['name']] = None
            return None
        distance = clip(distance + self.rng.gauss(0, self.cfg['sensor_noise_cm']), 0.2, self.cfg['range_max_cm'])
        self.generated[sensor['name']] = distance
        start = self.t + 0.00015
        return start, start + 2.0 * distance / 34000.0

    def summary(self):
        unchanged = self.program.read_bytes() == self.original_bytes
        return {'program': self.program.name, 'sha256_before': self.sha,
                'sha256_after': hashlib.sha256(self.program.read_bytes()).hexdigest(),
                'original_unchanged': unchanged, 'execution': 'original __main__ + Mesure + GPIO + PCA9685',
                'course': self.world.course['id'], 'course_name': self.world.course['name'],
                'reason': self.reason, 'sim_seconds': round(self.t, 6),
                'wall_seconds': round(real_time.perf_counter() - self.real_start, 4),
                'cycles': self.cycles, 'pwm_writes': self.pwm_count,
                'distance_cm': round(self.world.distance, 3),
                'reverse_distance_cm': round(self.world.reverse_distance, 3),
                'reverse_pulses': self.reverse_pulses, 'brake_pulses': self.brake_pulses,
                'collisions': self.world.collisions, 'laps': self.world.laps,
                'finished': self.world.finished, 'gate_index': self.world.gate,
                'steering_total_variation': round(self.steering_variation, 3),
                'final_comment': self.comment, 'final_measured': self.measured,
                'final_x': self.world.x, 'final_y': self.world.y,
                'error': self.error, 'assumptions': 'Editable hypothetical geometry/kinematics/ESC/acoustics; no real-vehicle completion guarantee.'}

class VirtualTime(types.ModuleType):
    def __init__(self, runner):
        super().__init__('time')
        self.runner = runner
    def time(self):
        self.runner.advance(0.000002)
        return 1000000.0 + self.runner.t
    def monotonic(self):
        self.runner.advance(0.000002)
        return self.runner.t
    def perf_counter(self):
        return self.monotonic()
    def sleep(self, seconds):
        self.runner.advance(float(seconds))
    def __getattr__(self, name):
        if name in ('time_ns', 'monotonic_ns', 'perf_counter_ns'):
            return lambda: int((self.time() if name == 'time_ns' else self.monotonic()) * 1e9)
        return getattr(real_time, name)

class FakeGPIO(types.ModuleType):
    BOARD, BCM, OUT, IN, HIGH, LOW = 10, 11, 0, 1, 1, 0
    def __init__(self, runner):
        super().__init__('RPi.GPIO')
        self.runner = runner
        self.values = {}
        self.pulses = {}
        self.by_trig = {s['trig']: s for s in runner.cfg['sensors']}
        self.by_echo = {s['echo']: s for s in runner.cfg['sensors']}
        self.mode = None
    def setmode(self, mode):
        if mode != self.BOARD:
            raise ValueError('This hardware profile expects GPIO.BOARD physical pin numbering')
        self.mode = mode
    def setwarnings(self, flag):
        pass
    def setup(self, pins, direction, initial=0, **kwargs):
        for pin in pins if isinstance(pins, (tuple, list)) else [pins]:
            self.values[pin] = initial
    def cleanup(self, *args):
        self.values.clear()
        self.pulses.clear()
    def output(self, pin, value):
        if isinstance(pin, (tuple, list)):
            for p in pin:
                self.output(p, value)
            return
        previous = self.values.get(pin, 0)
        self.values[pin] = value
        if previous == self.HIGH and value == self.LOW:
            if pin not in self.by_trig:
                raise ValueError('Unmapped trigger GPIO {}'.format(pin))
            sensor = self.by_trig[pin]
            self.pulses[sensor['echo']] = self.runner.trigger(sensor)
    def input(self, pin):
        if pin not in self.by_echo:
            raise ValueError('Unmapped echo GPIO {}'.format(pin))
        r = self.runner
        pulse = self.pulses.get(pin)
        if pulse is None:
            # Missing echo: original Mesure timeout and invalid-distance behavior
            # really run; we do not replace them with an invented safe reading.
            r.advance(0.002)
            return self.LOW
        start, end = pulse
        if r.t < start:
            if start - r.t > 0.000010:
                r.advance(start - r.t - 0.000008)
            else:
                r.advance(0.000001)
            return self.LOW if r.t < start else self.HIGH
        if r.t < end:
            # Event-driven fast-forward of an electrically steady HIGH period.
            # Stop before the falling edge so the original loop records sigon.
            if end - r.t > 0.000010:
                r.advance(end - r.t - 0.000008)
            else:
                r.advance(0.000001)
            return self.HIGH if r.t < end else self.LOW
        r.advance(0.000001)
        return self.LOW

class FakePCA(types.ModuleType):
    def __init__(self, runner):
        super().__init__('Adafruit_PCA9685')
        class PCA9685:
            def __init__(self, address=0x40, **kwargs):
                if address != 0x40:
                    raise ValueError('This profile expects PCA9685 address 0x40')
                self.frequency = None
            def set_pwm_freq(self, frequency):
                self.frequency = float(frequency)
                if not 1 <= self.frequency <= 1600:
                    raise ValueError('Invalid PCA9685 frequency')
            def set_pwm(self, channel, on, off):
                runner.pwm(channel, on, off, sys._getframe(1))
        self.PCA9685 = PCA9685

def execute(program, settings=None, send=None, conn=None):
    """Execute only trusted Python: virtualization is NOT a security sandbox."""
    cfg = validate_config(settings)
    runner = Runner(program, cfg, send, conn)
    old_modules = {name: sys.modules.get(name) for name in ('time', 'RPi', 'RPi.GPIO', 'Adafruit_PCA9685')}
    old_input, old_print = builtins.input, builtins.print
    runner.original_print = old_print
    old_path = list(sys.path)
    old_dont_write = sys.dont_write_bytecode
    try:
        gpio = FakeGPIO(runner)
        rpi = types.ModuleType('RPi')
        rpi.__path__ = []
        rpi.GPIO = gpio
        sys.modules.update({'RPi': rpi, 'RPi.GPIO': gpio,
                            'Adafruit_PCA9685': FakePCA(runner), 'time': VirtualTime(runner)})
        builtins.input = lambda prompt='': ''
        builtins.print = runner.log
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(Path(program).resolve().parent))
        if send:
            send({'type': 'begin', 'course': runner.world.course, 'sha256': runner.sha,
                  'program': Path(program).name})
        runner.publish()
        # run_path reads the original on-disk program; every original statement,
        # including the __main__ guard, Mesure and finally cleanup, is executed.
        runpy.run_path(str(Path(program).resolve()), run_name='__main__')
        runner.reason = runner.reason or 'program_returned'
    except SimulationEnd:
        pass
    except BaseException:
        runner.reason = 'error'
        runner.error = traceback.format_exc()
    finally:
        runner.halted = True
        builtins.input, builtins.print = old_input, old_print
        sys.path[:] = old_path
        sys.dont_write_bytecode = old_dont_write
        for name, value in old_modules.items():
            if value is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value
    runner.status = 'error' if runner.error else 'ended'
    runner.publish()
    result = {'summary': runner.summary(), 'config': cfg, 'course': runner.world.course,
              'frames': runner.frames, 'pwm_events': runner.pwm_events, 'logs': runner.all_logs}
    if send:
        send({'type': 'done', 'summary': result['summary']})
    return result

def save_result(result, out_dir):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    for name, value in (('summary.json', result['summary']), ('config.json', result['config']),
                        ('replay.json', result)):
        (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    fields = ['t', 'x', 'y', 'heading', 'speed', 'steer_deg', 'handle', 'accel',
              'requested_handle', 'requested_accel', 'steer_pwm', 'throttle_pwm', 'phase',
              'dt', 'cycles', 'collisions', 'gate', 'laps', 'distance_cm', 'reverse_distance_cm', 'comment', *NAMES]
    with (out / 'telemetry.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fields)
        writer.writeheader()
        for frame in result['frames']:
            row = {key: frame.get(key, '') for key in fields}
            row.update(frame['measured'])
            writer.writerow(row)
    with (out / 'pwm_events.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, ['t', 'channel', 'on', 'off', 'phase', 'speed_cm_s'])
        writer.writeheader()
        writer.writerows(result['pwm_events'])
    (out / 'program_output.txt').write_text('\n'.join('[{:8.3f}] {}'.format(e['t'], e['text']) for e in result['logs']), encoding='utf-8')
    return str(out)

def worker(program, config, conn, out_dir):
    try:
        result = execute(program, config, send=conn.send, conn=conn)
        save_result(result, out_dir)
        conn.send({'type': 'saved', 'out_dir': str(out_dir)})
    except BaseException:
        try:
            conn.send({'type': 'error', 'error': traceback.format_exc()})
        except (BrokenPipeError, EOFError, OSError):
            pass
    finally:
        conn.close()
