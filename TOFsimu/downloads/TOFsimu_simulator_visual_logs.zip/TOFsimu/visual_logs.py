"""Portable, offline HTML reports for recorded TOFsimu data.

The report contains recorded poses, observations and timestamped output. It does
not synthesize a path from a real vehicle's text log. Opening or exporting a
report does not execute a driving program.
"""
import argparse
import html
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'
DEFAULT_TITLE = 'TOFsimu 図付き走行ログ'


def _json_values(value):
    """Represent invalid numeric samples as JSON null, without mutating inputs."""
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {key: _json_values(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_values(item) for item in value]
    return value


def report_data(result):
    """Remove duplicated per-frame output; preserve the original global log."""
    if result is None:
        return None
    data = dict(result)
    frames = data.get('frames')
    if not isinstance(frames, list):
        raise ValueError('Report data must contain a frames list')
    data['frames'] = [
        {key: value for key, value in frame.items()
         if key not in ('logs', 'generated')}
        for frame in frames
    ]
    # Older/custom replay records may contain only per-frame log windows.
    # Keep a deduplicated timestamped log when a global one is unavailable.
    if not isinstance(data.get('logs'), list) or not data['logs']:
        logs = []
        seen = set()
        for frame in frames:
            for entry in frame.get('logs', []):
                if not isinstance(entry, dict):
                    continue
                timestamp, text = entry.get('t'), entry.get('text')
                if (isinstance(timestamp, bool)
                        or not isinstance(timestamp, (int, float))
                        or not math.isfinite(timestamp)
                        or not isinstance(text, str)):
                    continue
                key = (timestamp, text)
                if key not in seen:
                    seen.add(key)
                    logs.append(dict(entry))
        data['logs'] = sorted(logs, key=lambda entry: entry['t'])
    return _json_values(data)


def _safe_json(value):
    # A JSON data script is still parsed by the HTML tokenizer. Escape the
    # opening angle bracket so a log containing </script> cannot end the tag.
    text = json.dumps(value, ensure_ascii=False, separators=(',', ':'),
                      allow_nan=False)
    for old, escaped in (('&', '\\u0026'), ('<', '\\u003c'),
                         ('>', '\\u003e'), ('\u2028', '\\u2028'),
                         ('\u2029', '\\u2029')):
        text = text.replace(old, escaped)
    return text


def render_report(result=None, title=DEFAULT_TITLE):
    """Return a self-contained HTML viewer with optional recorded run data."""
    template = (WEB / 'log_viewer.html').read_text(encoding='utf-8')
    css = (WEB / 'log_viewer.css').read_text(encoding='utf-8')
    scripts = {
        name: (WEB / name).read_text(encoding='utf-8')
        for name in ('drive_log_data.js', 'log_viewer.js')
    }
    style_pattern = re.compile(
        r'<link\b(?=[^>]*\brel=[\"\']stylesheet[\"\'])'
        r'(?=[^>]*\bhref=[\"\'](?:\./)?log_viewer\.css[\"\'])[^>]*>',
        re.IGNORECASE)
    style, count = style_pattern.subn(
        lambda match: '<style>\n' + re.sub(
            r'</style', r'<\\/style', css, flags=re.IGNORECASE)
        + '\n</style>', template)
    if count != 1:
        raise ValueError('Viewer template must link log_viewer.css exactly once')
    template = style
    inline_scripts = []
    for name, script in scripts.items():
        pattern = re.compile(
            r'<script\b(?=[^>]*\bsrc=[\"\'](?:\./)?' + re.escape(name)
            + r'[\"\'])[^>]*>\s*</script\s*>', re.IGNORECASE)
        # No fetched code or user logs are inserted into executable script.
        script = re.sub(r'</script', r'<\\/script', script,
                        flags=re.IGNORECASE)
        template, count = pattern.subn('', template)
        inline_scripts.append('<script>\n' + script + '\n</script>')
        if count != 1:
            raise ValueError('Viewer template must load '+name+' exactly once')
    pattern = re.compile(
        r'(<script\b(?=[^>]*\bid=[\"\']log-data[\"\'])'
        r'(?=[^>]*\btype=[\"\']application/json[\"\'])[^>]*>)'
        r'.*?(</script\s*>)', re.IGNORECASE | re.DOTALL)
    payload = _safe_json(report_data(result))
    template, count = pattern.subn(
        lambda match: match.group(1) + payload + match.group(2), template)
    if count != 1:
        raise ValueError('Viewer template must contain one log-data JSON script')
    # External defer scripts run after parsing; inline scripts do not honor
    # defer. Place them after the full body to preserve that ordering offline.
    template, count = re.subn(r'</body\s*>',
                              lambda match: '\n'.join(inline_scripts) + '\n</body>',
                              template, count=1, flags=re.IGNORECASE)
    if count != 1:
        raise ValueError('Viewer template must contain a closing body tag')
    template = re.sub(r'<title>.*?</title>',
                      lambda match: '<title>' + html.escape(str(title)) + '</title>',
                      template, count=1, flags=re.IGNORECASE | re.DOTALL)
    return template


def save_report(result, path, title=DEFAULT_TITLE):
    """Write a portable report and return its path as a string."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_report(result, title), encoding='utf-8')
    return str(path)


def main():
    parser = argparse.ArgumentParser(description='Export an offline visual driving log')
    parser.add_argument('--replay', type=Path, help='Recorded replay.json; omit for an empty log viewer')
    parser.add_argument('--out', type=Path, default=ROOT/'log_viewer.html')
    parser.add_argument('--title', default=DEFAULT_TITLE)
    args = parser.parse_args()
    data = json.loads(args.replay.read_text(encoding='utf-8')) if args.replay else None
    print(save_report(data, args.out, args.title))


if __name__ == '__main__':
    main()
