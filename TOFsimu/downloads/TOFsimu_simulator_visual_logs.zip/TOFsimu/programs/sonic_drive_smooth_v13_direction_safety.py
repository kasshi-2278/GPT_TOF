#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sonic_drive 第6版: 疎な Follow the Gap + 局所目標 Pure Pursuit。

前方3センサーで進路候補を選び、その目標点へPure Pursuitで舵角を計算。
直線では第3版の左右距離PD補正を使い、カーブに近づくほどPPへ移行する。
地図・自己位置を使う経路追従ではなく、毎回作り直す近くの目標を追う方式。
3本の射線間は未観測なので、LiDARと同じ精度で隙間を測れるわけではない。
後方2センサーは左右距離の補正と、従来の接近判定に使う。

GPIO・PWMの設定、Mesure、PWM換算式、短い後退手順は添付版と同じ。
添付版の前進上限80・カーブ下限50を維持。直進中の誤後退を抑える。
距離はcm、時間は秒。車体寸法・実舵角・センサー位置/角度は下の仮設定。
Python 3.6以降。標準ライブラリと既存の実機ライブラリだけで実行できる。

方式の参考（この車両向けの調整値を示す資料ではありません）:
Pure Pursuit: R. Craig Coulter, CMU-RI-TR-92-01 (1992)
https://www.ri.cmu.edu/pub_files/pub3/coulter_r_craig_1992_1/coulter_r_craig_1992_1.pdf
Follow the Gap: F1TENTH Lab 4
https://f1tenth-coursekit.readthedocs.io/en/stable/assignments/labs/lab4.html
"""

import math
import time


# ===== 走行判断の調整値（GPIO・PWMの設定ではありません） =====
FORWARD_ACCEL = 80.0              # 今回の添付版の前進上限を維持。実速度cm/sではない
CURVE_ACCEL = 50.0                # 元と同じカーブのアクセル下限
REVERSE_ACCEL = -50.0             # 元と同じ後退アクセル
REVERSE_HANDLE = 40.0             # 元と同じ後退時のハンドル量
REVERSE_DISTANCE_CM = 35.0        # 元と同じ後退判定距離。生の測定値で判定
BRAKE_SECONDS = 0.20             # 後退に入れる最初のブレーキ時間は維持
REVERSE_NEUTRAL_SECONDS = 0.02   # 元のニュートラル時間。後退パルスの終了時にも確保
REVERSE_PULSE_SECONDS = 0.12     # 1回の後退指令。終了後は必ず停止して再測距

FRONT_WALL_GAIN = 0.28            # 前方左右の距離差 → ハンドル量。前方の補正を主に使う
REAR_WALL_GAIN = 0.20             # 後方の補正を弱め、戻り始めても切り続ける動きを抑える
FRONT_DEADBAND_CM = 6.0           # 前方左右の差がこの範囲なら補正しない
REAR_DEADBAND_CM = 4.0            # 後方左右の差がこの範囲なら補正しない
FRONT_COMPARE_MAX_CM = 160.0      # 遠い開口部に急に引っ張られないよう上限を設ける
REAR_COMPARE_MAX_CM = 80.0
WALL_HANDLE_LIMIT = 22.0          # 直線の通常補正は±22まで。カーブは別に最大±100
WALL_DAMPING_SECONDS = 0.55       # 距離差の変化に応じ、中央へ戻る途中から舵を戻す強さ
WALL_DAMPING_TAU = 0.12           # 変化率だけを平滑化して測距ノイズの増幅を抑える
WALL_DAMPING_LIMIT = 12.0         # 変化率による補正の上限 [%ポイント]
WALL_RATE_LIMIT = 100.0           # 変化率の異常な跳ねを抑える [%ポイント/秒]
WALL_DAMPING_DEADBAND = 1.0       # 小さな変化率の補正は出さない [%ポイント]
WALL_HISTORY_GAP_SECONDS = 0.25   # 間隔が空いたら変化率の履歴を捨てる
CORRECTION_SLOW_HANDLE = 6.0      # 強めの直線補正中は加速を抑える

DISTANCE_FILTER_TAU = 0.10        # 距離の平滑化。大きいほど穏やか、反応は遅い
STEERING_FILTER_TAU = 0.07        # 戻す指令が遅れないよう、通常の出力側の遅れを小さく
STEERING_RATE = 140.0            # 通常の最大ハンドル変化量 [%ポイント/秒]
CORNER_STEERING_TAU = 0.055       # カーブ中は平滑化による遅れを小さくする
CORNER_STEERING_RATE = 360.0      # カーブ中の最大ハンドル変化量
NEAR_STEERING_RATE = 400.0        # 壁が近いときは曲がり遅れを抑える

CORNER_START_CM = 260.0           # 正面260cmからPD→PPを移行。後退距離とは別
CORNER_FULL_CM = 150.0             # この距離でPPの寄与100%。最大舵角100%の意味ではない
CORNER_EXIT_CM = 280.0            # 解除を別の距離にして境目での切替を防ぐ
CORNER_EXIT_SECONDS = 0.15
TURN_CHOICE_MARGIN_CM = 12.0     # 左右の開き具合がほぼ同じなら方向を維持
TURN_SWITCH_MARGIN_CM = 45.0     # 反対側が明確に開いている場合だけ方向変更
TURN_SWITCH_SECONDS = 0.15       # 明確な逆カーブへの切り返しも早める
ACCEL_RISE_RATE = 15.0           # 前進中の加速を穏やかにする [%ポイント/秒]
ACCEL_FALL_RATE = 60.0
LOG_INTERVAL_SECONDS = 0.20      # 毎周期の大量表示による処理時間のばらつきを抑える


# ===== 車体モデルの仮設定（GPIO・PWM設定は変更しません） =====
# 元コードに実測値がないため仮置き。取り付け位置と実タイヤ舵角に合わせること。
# 後輪軸中心を(0,0)、x=前方、y=左とする。長さはすべてcm。
WHEELBASE_CM = 25.0               # 前後輪の軸間距離。車体の全長ではない
MAX_ROAD_WHEEL_STEER_DEG = 25.0   # Handle±100に対応するタイヤの実舵角の絶対値
VEHICLE_WIDTH_CM = 18.0           # 車幅。隙間候補の障害物余裕に使用
# 右FrRh → 正面Fr → 左FrLh。位置も角度も仮定であり実測値ではない。
FRONT_RAY_ANGLES_DEG = (-45.0, 0.0, 45.0)
FRONT_RAY_ORIGINS_CM = ((25.0, -8.0), (30.0, 0.0), (25.0, 8.0))

# ===== Follow the Gap / Pure Pursuit の調整値 =====
GAP_SIDE_MARGIN_CM = 8.0          # 車幅の半分に加える、観測障害物周囲の余裕
GAP_END_MARGIN_CM = 20.0          # 測距した終端より手前に目標を置く余裕
GAP_REENTRY_MARGIN_CM = 5.0       # 一度無効になった射線は5cmの余裕が戻るまで再使用しない
PP_MIN_ADVANCE_CM = 25.0          # センサーから目標までに必要な最小距離
PP_STRAIGHT_ADVANCE_CM = 95.0     # センサーから目標までの通常の距離
PP_FAST_ADVANCE_CM = 125.0        # 大きい前進指令で遠くを見る（速度計測ではない）
PP_CORNER_ADVANCE_CM = 45.0       # カーブでは近い目標へ。32cmより過大な初動操舵を抑える

# 中央仕切り板（直線140cmの中央に障害物、左右どちらかに通行帯）
# 3本の超音波射線で「候補方向」を推定するだけで、70cmの実幅は保証できない。
DIVIDER_DETECT_CM = 260.0
DIVIDER_OPEN_EXTRA_CM = 20.0       # 斜め側が正面よりどれだけ遠いか
DIVIDER_MIN_SIDE_CM = 80.0       # 安全を優先し、短い側方射線では進入しない
DIVIDER_CONFIRM_CYCLES = 2
DIVIDER_ACCEL_LIMIT = 50.0
DIVIDER_REVERSE_CONFIRM_CYCLES = 3  # 逆側への切替は連続観測で確認
DIVIDER_SIDE_DIFFERENCE_CM = 18.0  # 左右が曖昧な場合は方向を決めない
DIVIDER_MIN_CORNER_WEIGHT = 0.55
# 仕切り板は「左右双方が見通せる」形を優先。通常のL字カーブを横取りしない。
DIVIDER_OTHER_SIDE_MIN_CM = 75.0
DIVIDER_OTHER_SIDE_FRONT_RATIO = 0.38  # 正面距離に対する短い側の必要割合

# 狭路モード: 前方左右が両方壁を見ている場合のみ確認する。角度は仮設定。
NARROW_FRONT_CLEAR_CM = 90.0
NARROW_SIDE_MIN_CM = 18.0
NARROW_SIDE_MAX_CM = 65.0
NARROW_BALANCE_CM = 18.0
NARROW_CONFIRM_CYCLES = 3
NARROW_EXIT_CYCLES = 5
NARROW_ACCEL_LIMIT = 50.0
NARROW_HANDLE_LIMIT = 18.0
NARROW_SIDE_GAIN = 0.40
NARROW_EMERGENCY_CM = 15.0
# 側方の1回だけの近距離エコーでは後退しない（停止して再測距）。
SIDE_REVERSE_CONFIRM_CYCLES = 3
SIDE_REVERSE_CRITICAL_CM = 15.0  # 単発値は即後退せず停止確認
TURN_CONFIRM_CYCLES = 2  # 初回旋回方向は2測定で確認
# 狭路の判定が確定するまで、候補中は停止して確認する。
# 正面の後退判定（35cm未満）は必ず優先する。



def _clip(value, low, high):
    return max(low, min(high, value))


def _deadband(value, width):
    if value > width:
        return value - width
    if value < -width:
        return value + width
    return 0.0


def _smoothstep(value):
    value = _clip(value, 0.0, 1.0)
    return value * value * (3.0 - 2.0 * value)


def _sparse_gaps(ranges, avoid_front, depth_usable):
    """右/正面/左の3本だけから、隣接する進路候補の組を返す。

    射線間に架空の測距点を増やさない。連続した候補は通行保証ではない。
    中央は早めの旋回計画のため150cmから除外する。一方、左右には
    近い局所目標を置ける長さが必要。中央と左右の計画距離を分ける。
    """
    minimum_range = PP_MIN_ADVANCE_CM + GAP_END_MARGIN_CM
    blocked = [not usable or distance < minimum_range
               for usable, distance in zip(depth_usable, ranges)]
    if avoid_front:
        blocked[1] = True

    # 障害物の周囲に車幅+余裕の角度領域を設け、近隣の候補も除外する。
    # 十分遠い直線で、最短の射線を無条件に消して左右へ逸れる処理はしない。
    # 角度領域は共通原点での近似。実センサーのビーム幅は不明である。
    radius = VEHICLE_WIDTH_CM / 2.0 + GAP_SIDE_MARGIN_CM
    seeds = list(blocked)
    for index, is_blocked in enumerate(seeds):
        if not is_blocked:
            continue
        half_angle = math.degrees(math.asin(_clip(radius / ranges[index], 0.0, 1.0)))
        for other, angle in enumerate(FRONT_RAY_ANGLES_DEG):
            if abs(angle - FRONT_RAY_ANGLES_DEG[index]) <= half_angle:
                blocked[other] = True

    gaps = []
    start = None
    for index in range(len(ranges) + 1):
        is_free = index < len(ranges) and not blocked[index]
        if is_free and start is None:
            start = index
        elif not is_free and start is not None:
            gaps.append(tuple(range(start, index)))
            start = None
    return gaps, tuple(blocked)


def _pure_pursuit_handle(goal_x_cm, goal_y_cm):
    """後輪軸から見た局所目標 → (Handle, 曲率[1/cm])。正は左。

    車両への舵角指令は atan(L * 2y / (x*x+y*y))。
    PWMではなく実タイヤ舵角を使ってHandleへ換算する線形モデル。
    """
    distance_squared = goal_x_cm * goal_x_cm + goal_y_cm * goal_y_cm
    if distance_squared <= 1e-9:
        return 0.0, 0.0
    curvature = 2.0 * goal_y_cm / distance_squared
    steer_degrees = math.degrees(math.atan(WHEELBASE_CM * curvature))
    handle = 100.0 * steer_degrees / MAX_ROAD_WHEEL_STEER_DEG
    return _clip(handle, -100.0, 100.0), curvature


class SmoothDriveController:
    """GPIOに依存しない走行判断。正のHandleは左、負のHandleは右。

    update(Fr, FrLh, FrRh, RrLh, RrRh, dt) は
    (Accel, Handle, comment) を返す。距離はcm、dtは秒。
    """

    def __init__(self):
        self._reset(0.0, CURVE_ACCEL)

    def _reset(self, handle, accel):
        self._filtered = None
        self._handle = handle
        self._accel = accel
        self._turn = 0
        self._clear_time = 0.0
        self._opposite_time = 0.0
        self._resume_forward = False
        self._wall_score_before = None
        self._wall_rate = 0.0
        self._gap_usable = [False, False, False]
        self._narrow_mode = False
        self._narrow_count = 0
        self._narrow_exit_count = 0
        self._side_close_count = 0
        self._divider_count = 0
        self._divider_direction = 0
        self._divider_pending = 0
        self._gap_pending = None
        self._gap_confirm = 0
        self.debug = {"p": 0.0, "d": 0.0, "corner": 0.0, "approach": 0.0,
                      "pp": 0.0, "curvature": 0.0, "gap": "none",
                      "gap_index": None, "gap_angle_deg": None,
                      "goal_x": None, "goal_y": None, "lookahead_cm": 0.0,
                      "goal_advance_cm": 0.0, "goal_range_cm": 0.0,
                      "blocked": (), "gaps": (), "fallback": False, "narrow": False,
                      "side_close_count": 0, "safety_reason": "",
                      "divider": 0, "divider_count": 0}

    def _choose_gap(self, ranges, front_for_turn, wall_handle, step_dt):
        avoid_front = front_for_turn < CORNER_START_CM
        minimum_range = PP_MIN_ADVANCE_CM + GAP_END_MARGIN_CM
        for index, distance in enumerate(ranges):
            # 有効化50cm / 無効化45cm。45cm付近の微小ノイズで
            # PPと低速の代替処理を毎周期行き来させない。
            if distance < minimum_range:
                self._gap_usable[index] = False
            elif distance >= minimum_range + GAP_REENTRY_MARGIN_CM:
                self._gap_usable[index] = True
        gaps, blocked = _sparse_gaps(ranges, avoid_front, self._gap_usable)
        self.debug.update(gaps=tuple(gaps), blocked=blocked)

        # 正面が十分見通せるときは中央を優先。横の開口部へ引っ張られない。
        if not avoid_front and not blocked[1]:
            self._opposite_time = 0.0
            return 1
        if not gaps:
            self._opposite_time = 0.0
            return None

        # 最も角度幅の広い候補を優先し、同じ幅なら観測距離で比較する。
        # 3本しかないため、中央を除外したカーブでは左右1本ずつの比較になる。
        widest = max(FRONT_RAY_ANGLES_DEG[gap[-1]] - FRONT_RAY_ANGLES_DEG[gap[0]]
                     for gap in gaps)
        candidates = []
        for gap in gaps:
            width = FRONT_RAY_ANGLES_DEG[gap[-1]] - FRONT_RAY_ANGLES_DEG[gap[0]]
            if width == widest:
                candidates.append(max(gap, key=lambda index: ranges[index]))
        best = max(candidates, key=lambda index: ranges[index])
        current = 2 if self._turn > 0 else 0 if self._turn < 0 else None
        # 左右2本の差が小さい場合、任意の方向へ切り込まない。
        # すでに選んだ側が有効なら保持。それ以外は停止して再測距。
        if 0 in candidates and 2 in candidates:
            if abs(ranges[2] - ranges[0]) < DIVIDER_SIDE_DIFFERENCE_CM:
                if current in candidates:
                    best = current
                else:
                    self._turn = 0
                    return None

        # 初回と方向変更は2回の一致を要求。単発の左右逆転で舵を振らない。
        if best in (0, 2) and best != current:
            if self._gap_pending == best:
                self._gap_confirm += 1
            else:
                self._gap_pending = best
                self._gap_confirm = 1
            if current is None and self._gap_confirm < TURN_CONFIRM_CYCLES:
                return None
            if current is not None and current in candidates:
                best = current
            elif self._gap_confirm < TURN_CONFIRM_CYCLES:
                return None
        else:
            self._gap_pending = None
            self._gap_confirm = 0

        # 進行中の候補が塞がれた場合は、保持時間を待たず選び直す。
        if current is not None and current in candidates:
            if best != current and ranges[best] - ranges[current] > TURN_SWITCH_MARGIN_CM:
                self._opposite_time += step_dt
                if self._opposite_time < TURN_SWITCH_SECONDS:
                    best = current
                else:
                    self._opposite_time = 0.0
            else:
                best = current
                self._opposite_time = 0.0
        else:
            self._opposite_time = 0.0
            # 車線中央補正は曲がる方向の証拠ではない。
            # gapに基づく候補だけを選択し、微差なら上の判定で保留する。

        self._turn = 1 if best == 2 else -1 if best == 0 else 0
        return best

    def _gap_goal(self, index, ranges, approach):
        if index is None:
            return None
        available = ranges[index] - GAP_END_MARGIN_CM
        if available < PP_MIN_ADVANCE_CM:
            # 最小値へ切り上げて、障害物の中に目標を置いてはいけない。
            return None
        command_fraction = _clip((self._accel - CURVE_ACCEL)
                                 / max(FORWARD_ACCEL - CURVE_ACCEL, 1.0), 0.0, 1.0)
        straight_advance = (PP_STRAIGHT_ADVANCE_CM
                            + command_fraction * (PP_FAST_ADVANCE_CM - PP_STRAIGHT_ADVANCE_CM))
        desired_advance = ((1.0 - approach) * straight_advance
                           + approach * PP_CORNER_ADVANCE_CM)
        advance = min(max(PP_MIN_ADVANCE_CM, desired_advance), available)
        angle = math.radians(FRONT_RAY_ANGLES_DEG[index])
        origin_x, origin_y = FRONT_RAY_ORIGINS_CM[index]
        goal_x = origin_x + advance * math.cos(angle)
        goal_y = origin_y + advance * math.sin(angle)
        # 原点オフセットを加えた後の実際のx/yからPPを計算する。
        pp_handle, curvature = _pure_pursuit_handle(goal_x, goal_y)
        return goal_x, goal_y, advance, pp_handle, curvature

    def update(self, Fr, FrLh, FrRh, RrLh, RrRh, dt):
        # Mesureはタイムアウト時に負値などを返し得る。
        # 0.02秒の測定上限は約340cm。500cm超は異常値として扱う。
        # 測定関数やGPIOの信号は変更せず、判断側で混入を防ぐ。
        values = (Fr, FrLh, FrRh, RrLh, RrRh)
        try:
            raw = [float(value) for value in values]
            dt = float(dt)
            valid = all(math.isfinite(value) and 0.0 < value <= 500.0
                        for value in raw)
            valid = valid and math.isfinite(dt) and dt > 0.0
        except (TypeError, ValueError, OverflowError):
            valid = False
        if not valid:
            self._reset(0.0, CURVE_ACCEL)
            return 0.0, 0.0, "距離の異常値：停止（正常値で再開）"

        Fr, FrLh, FrRh, RrLh, RrRh = raw

        # 正面仕切りの左右候補。単一の射線は通行幅の証明ではない。
        side_ranges = (FrRh, FrLh)  # 右、左
        right, left = side_ranges
        divider_candidate = (REVERSE_DISTANCE_CM < Fr < DIVIDER_DETECT_CM
                             and max(side_ranges) >= max(DIVIDER_MIN_SIDE_CM,
                                                         Fr + DIVIDER_OPEN_EXTRA_CM)
                             # 通常カーブは内側斜め射線が短くなりがち。
                             # 両側の空きが見えない限り専用モードを開始しない。
                             and min(side_ranges) >= max(DIVIDER_OTHER_SIDE_MIN_CM,
                                                          Fr * DIVIDER_OTHER_SIDE_FRONT_RATIO))
        side_difference = left - right
        side_clear = abs(side_difference) >= DIVIDER_SIDE_DIFFERENCE_CM
        proposed = (1 if side_difference > 0 else -1) if side_clear else 0
        if divider_candidate and proposed:
            if self._divider_direction == 0:
                if self._divider_pending == proposed:
                    self._divider_count += 1
                else:
                    self._divider_pending = proposed
                    self._divider_count = 1
                if self._divider_count >= DIVIDER_CONFIRM_CYCLES:
                    self._divider_direction = proposed
                    self._divider_count = 0
            elif proposed == self._divider_direction:
                self._divider_pending = 0
                self._divider_count = 0
            else:
                # 一時的に相手側の読みが伸びても即反転しない。
                if self._divider_pending == proposed:
                    self._divider_count += 1
                else:
                    self._divider_pending = proposed
                    self._divider_count = 1
                if self._divider_count >= DIVIDER_REVERSE_CONFIRM_CYCLES:
                    # 進行方向の変更は操舵で即反転せず、停止して再評価する。
                    self._divider_direction = 0
                    self._divider_pending = 0
                    self._divider_count = 0
        else:
            self._divider_pending = 0
            self._divider_count = 0
            if not divider_candidate or Fr > DIVIDER_DETECT_CM + 20.0:
                self._divider_direction = 0
        # 確定側が観測できなくなった場合は進行指令を作らず停止。
        selected_range = (left if self._divider_direction > 0 else right)
        if self._divider_direction and selected_range < DIVIDER_MIN_SIDE_CM:
            self._divider_direction = 0
        self.debug['divider'] = self._divider_direction
        self.debug['divider_count'] = self._divider_count

        # 狭路候補: 斜め前方の左右が近く、正面に余裕がある場合のみ。
        # 3本の疎な射線では入口の幅・端点は証明できない。未確認時は従来の保護を使う。
        side_lateral_l = FrLh * abs(math.sin(math.radians(FRONT_RAY_ANGLES_DEG[2])))
        side_lateral_r = FrRh * abs(math.sin(math.radians(FRONT_RAY_ANGLES_DEG[0])))
        narrow_candidate = (Fr >= NARROW_FRONT_CLEAR_CM
                            and NARROW_SIDE_MIN_CM <= side_lateral_l <= NARROW_SIDE_MAX_CM
                            and NARROW_SIDE_MIN_CM <= side_lateral_r <= NARROW_SIDE_MAX_CM
                            and abs(side_lateral_l - side_lateral_r) <= NARROW_BALANCE_CM)
        if narrow_candidate:
            self._narrow_count += 1
            self._narrow_exit_count = 0
        else:
            self._narrow_count = 0
            self._narrow_exit_count += 1
        if self._narrow_count >= NARROW_CONFIRM_CYCLES:
            self._narrow_mode = True
        if self._narrow_exit_count >= NARROW_EXIT_CYCLES:
            self._narrow_mode = False
        self.debug['narrow'] = self._narrow_mode
        # 狭路モードでも正面と極端な側方接近は保護する。
        narrow_safe = (self._narrow_mode and narrow_candidate
                       and min(side_lateral_l, side_lateral_r) > NARROW_EMERGENCY_CM
                       and min(RrLh, RrRh) > NARROW_EMERGENCY_CM)
        # 先に正面の衝突危険を評価する。側方の反射は入口や壁面の
        # 近距離値になり得るため、単発測定で後退を繰り返さない。
        near_right = min(FrRh, RrRh)
        near_left = min(FrLh, RrLh)
        front_danger = Fr < REVERSE_DISTANCE_CM
        side_close = FrRh < REVERSE_DISTANCE_CM or FrLh < REVERSE_DISTANCE_CM
        severe_side = min(FrRh, FrLh) < SIDE_REVERSE_CRITICAL_CM
        # narrow_candidate は前方の開放・左右の対称性を要求するが、
        # センサー取付角が未確定なので候補中は走らず測距を続ける。
        if side_close and not narrow_safe:
            self._side_close_count += 1
        else:
            self._side_close_count = 0
        self.debug['side_close_count'] = self._side_close_count

        # 斜め前センサー単独の値は壁角・反射で短くなるため停止して確認。
        # 同じ側の後方センサーも近く、連続観測された場合のみ側方後退。
        confirmed_left = (FrLh < REVERSE_DISTANCE_CM and RrLh < REVERSE_DISTANCE_CM)
        confirmed_right = (FrRh < REVERSE_DISTANCE_CM and RrRh < REVERSE_DISTANCE_CM)
        side_reverse = (self._side_close_count >= SIDE_REVERSE_CONFIRM_CYCLES
                        and (confirmed_left or confirmed_right) and not narrow_safe)
        reverse = front_danger or side_reverse
        if reverse:
            handle = -REVERSE_HANDLE if near_right <= near_left else REVERSE_HANDLE
            reason = '正面' if front_danger else '側方'
            self._reset(handle, CURVE_ACCEL)
            self._resume_forward = True
            direction = '右' if handle < 0.0 else '左'
            self.debug['safety_reason'] = reason + '接近・後退'
            return REVERSE_ACCEL, handle, '接近回避（' + reason + '）：' + direction + '後退'
        if side_close and not narrow_safe:
            # 正面が空いていて狭路候補なら3回の確認が終わるまで停止する。
            # 狭路候補でない側方接近も、最初の数回は停止して再確認する。
            self._accel = CURVE_ACCEL
            self._handle = 0.0
            self.debug['safety_reason'] = ('狭路候補を確認中' if narrow_candidate
                                           else '側方接近を再測距中')
            return 0.0, 0.0, self.debug['safety_reason'] + '：停止'
        self.debug['safety_reason'] = ''

        # 処理が長引いても通常操舵を大きく飛ばさない（後退からの復帰は別扱い）。
        step_dt = min(dt, 0.10)
        alpha = 1.0 - math.exp(-step_dt / DISTANCE_FILTER_TAU)
        if self._filtered is None:
            self._filtered = list(raw)
        else:
            self._filtered = [old + alpha * (new - old)
                              for old, new in zip(self._filtered, raw)]
        front, fl, fr, rl, rr = self._filtered

        # 同じ位置の左右を比較する。前後センサーの取付角度は仮定しない。
        front_error = _deadband(min(fl, FRONT_COMPARE_MAX_CM)
                                - min(fr, FRONT_COMPARE_MAX_CM), FRONT_DEADBAND_CM)
        rear_error = _deadband(min(rl, REAR_COMPARE_MAX_CM)
                               - min(rr, REAR_COMPARE_MAX_CM), REAR_DEADBAND_CM)
        wall_position = FRONT_WALL_GAIN * front_error + REAR_WALL_GAIN * rear_error

        # 正の距離差は左操舵。変化率も加算する。
        # 例: 左壁から離れて中央へ戻ると負の距離差が0へ増加するため、
        # Dは正となり、それまでの右操舵を中央に着く前から弱める。
        # 前後のセンサー取付角度から車体角度を推定する処理は行わない。
        wall_score = (FRONT_WALL_GAIN * (min(fl, FRONT_COMPARE_MAX_CM)
                                        - min(fr, FRONT_COMPARE_MAX_CM))
                      + REAR_WALL_GAIN * (min(rl, REAR_COMPARE_MAX_CM)
                                         - min(rr, REAR_COMPARE_MAX_CM)))
        if self._wall_score_before is None or dt > WALL_HISTORY_GAP_SECONDS:
            self._wall_rate = 0.0
        else:
            # 変化率の分母には上限を付けたstep_dtではなく実際の測定間隔を使う。
            observed_rate = _clip((wall_score - self._wall_score_before) / dt,
                                  -WALL_RATE_LIMIT, WALL_RATE_LIMIT)
            rate_alpha = 1.0 - math.exp(-dt / WALL_DAMPING_TAU)
            self._wall_rate += rate_alpha * (observed_rate - self._wall_rate)
        self._wall_score_before = wall_score
        damping = _clip(_deadband(WALL_DAMPING_SECONDS * self._wall_rate,
                                  WALL_DAMPING_DEADBAND),
                        -WALL_DAMPING_LIMIT, WALL_DAMPING_LIMIT)
        wall_handle = _clip(wall_position + damping,
                            -WALL_HANDLE_LIMIT, WALL_HANDLE_LIMIT)
        if abs(wall_handle) < 2.0:
            wall_handle = 0.0

        # 接近時は生値を優先し、開口部が現れた時はフィルターの確認を待つ。
        front_for_turn = min(front, Fr)
        if self._turn:
            if front > CORNER_EXIT_CM and Fr > CORNER_EXIT_CM:
                self._clear_time += step_dt
            else:
                self._clear_time = 0.0
            if self._clear_time >= CORNER_EXIT_SECONDS:
                self._turn = 0
                self._clear_time = 0.0
                self._opposite_time = 0.0

        approach = _smoothstep((CORNER_START_CM - front_for_turn)
                                / (CORNER_START_CM - CORNER_FULL_CM))
        # 後方センサーは前方の射線に混ぜない。並びは右・正面・左。
        gap_ranges = (min(fr, FrRh), front_for_turn, min(fl, FrLh))
        gap_index = self._choose_gap(gap_ranges, front_for_turn, wall_handle, step_dt)
        # 仕切り板が確認されている間は選んだ左右候補を保持し、早期に操舵する。
        # 実際にその射線が開いていなければ進行目標を作らない。
        if self._divider_direction and divider_candidate and front_for_turn < DIVIDER_DETECT_CM:
            divider_idx = 2 if self._divider_direction > 0 else 0
            if (not self.debug['blocked'][divider_idx]
                    and gap_ranges[divider_idx] >= max(DIVIDER_MIN_SIDE_CM,
                                                      PP_MIN_ADVANCE_CM + GAP_END_MARGIN_CM)):
                gap_index = divider_idx
                self._turn = self._divider_direction
            else:
                gap_index = None
        # 仕切り板の確定待ちでも通常のGap/PPを妨げない。
        # 両側が曖昧で候補を選べない場合は、後段の安全停止に委ねる。
        goal = self._gap_goal(gap_index, gap_ranges, approach)
        fallback = goal is None
        if fallback:
            # 通れるという根拠のない方向を「最も遠いからfree」に戻さない。
            # 旋回目標が作れない間は既存の弱い壁補正を使い、即アクセル30へ。
            # 35cmの生値による短い後退判断は、上で必ず先に実行される。
            corner_weight = 0.0
            target_handle = wall_handle
            self.debug.update(gap="none", gap_index=None, gap_angle_deg=None,
                              goal_x=None, goal_y=None, lookahead_cm=0.0,
                              goal_advance_cm=0.0, goal_range_cm=0.0,
                              pp=0.0, curvature=0.0)
        else:
            goal_x, goal_y, advance, pp_handle, curvature = goal
            corner_weight = approach
            if self._divider_direction and divider_candidate and gap_index != 1:
                corner_weight = max(corner_weight, DIVIDER_MIN_CORNER_WEIGHT)
            # 目標を別のgapと平均しない。PD→PPの移行と実操舵側だけを平滑化。
            # 曲がる方向と逆の直線PD補正をカーブ初動へ混ぜない。
            # PPへの寄与を増やしても、前方障害物に向かう逆舵は出さない。
            wall_for_turn = wall_handle
            if gap_index in (0, 2) and wall_for_turn * pp_handle < 0:
                wall_for_turn = 0.0
            target_handle = ((1.0 - corner_weight) * wall_for_turn
                             + corner_weight * pp_handle)
            if gap_index in (0, 2) and target_handle * pp_handle < 0:
                target_handle = 0.0
            self.debug.update(gap=("right", "front", "left")[gap_index],
                              gap_index=gap_index, gap_angle_deg=FRONT_RAY_ANGLES_DEG[gap_index],
                              goal_x=goal_x, goal_y=goal_y,
                              lookahead_cm=math.hypot(goal_x, goal_y),
                              goal_advance_cm=advance, goal_range_cm=gap_ranges[gap_index],
                              pp=pp_handle, curvature=curvature)

        # 狭路では局所PPが左右壁へ向かうのを抑え、距離差で中央を保持。
        if narrow_safe:
            narrow_error = side_lateral_l - side_lateral_r
            target_handle = _clip(NARROW_SIDE_GAIN * narrow_error,
                                  -NARROW_HANDLE_LIMIT, NARROW_HANDLE_LIMIT)
            corner_weight = 0.0
            fallback = False

        # 正面の仕切りが近いのに候補が無ければ、壁へ向けて直進しない。
        if fallback and Fr < DIVIDER_DETECT_CM:
            self._handle = 0.0
            self._accel = CURVE_ACCEL
            self.debug['safety_reason'] = '進路未確認・停止'
            return 0.0, 0.0, '進路未確認：停止・再測距'

        # カーブの強さに応じて平滑化と変化量制限を緩める。
        # カーブ状態が残っていても、前方が開けて重み0なら通常の穏やかさに戻る。
        urgency = _smoothstep((CORNER_FULL_CM - Fr)
                              / (CORNER_FULL_CM - REVERSE_DISTANCE_CM))
        steer_tau = ((1.0 - corner_weight) * STEERING_FILTER_TAU
                     + corner_weight * CORNER_STEERING_TAU)
        steer_tau *= 1.0 - 0.35 * urgency
        # カーブの大きな舵角を直線へ持ち越さない。戻す間だけカーブ用の応答を使う。
        unwinding_large_turn = (
            abs(self._handle) > WALL_HANDLE_LIMIT
            and (self._handle * target_handle <= 0.0
                 or abs(target_handle) < abs(self._handle)))
        if unwinding_large_turn:
            steer_tau = min(steer_tau, CORNER_STEERING_TAU)
        steer_alpha = 1.0 - math.exp(-step_dt / steer_tau)
        filtered_handle = self._handle + steer_alpha * (target_handle - self._handle)
        rate = ((1.0 - corner_weight) * STEERING_RATE
                + corner_weight * CORNER_STEERING_RATE)
        rate += (NEAR_STEERING_RATE - rate) * urgency
        if unwinding_large_turn:
            rate = max(rate, CORNER_STEERING_RATE)
        max_step = rate * step_dt
        resuming = self._resume_forward
        if resuming:
            # 前進再開時だけは後退用の逆向き舵角を持ち越さない。
            # 新しい前進舵角を先に出し、アクセル30で復帰する。
            self._handle = target_handle
            self._resume_forward = False
        else:
            self._handle += _clip(filtered_handle - self._handle, -max_step, max_step)
        # 0への漸近でPWM換算後に1カウントだけずれ続けることを防ぐ。
        if target_handle == 0.0 and abs(self._handle) < 0.5:
            self._handle = 0.0

        # 大きく補正している最中や壁が近いときは、30側へ減速して立て直す。
        # 左右が落ち着いた後でゆっくり前進上限へ戻す。
        correction_weight = (1.0 - corner_weight) * _smoothstep(
            (abs(wall_handle) - CORRECTION_SLOW_HANDLE)
            / (WALL_HANDLE_LIMIT - CORRECTION_SLOW_HANDLE))
        # 前方斜めと後方は取付角度が不明なので、別々の距離基準を使う。
        side_caution = max(
            _smoothstep((55.0 - min(FrLh, FrRh, fl, fr)) / 20.0),
            _smoothstep((30.0 - min(RrLh, RrRh, rl, rr)) / 12.0))
        curve_amount = max(approach, abs(self._handle) / 100.0,
                           correction_weight, side_caution)
        target_accel = FORWARD_ACCEL - (FORWARD_ACCEL - CURVE_ACCEL) * curve_amount
        accel_rate = ACCEL_RISE_RATE if target_accel > self._accel else ACCEL_FALL_RATE
        if resuming or fallback:
            self._accel = CURVE_ACCEL
        else:
            self._accel += _clip(target_accel - self._accel,
                                 -accel_rate * step_dt, accel_rate * step_dt)
        self._accel = _clip(self._accel, CURVE_ACCEL, FORWARD_ACCEL)
        if narrow_safe:
            self._accel = min(self._accel, NARROW_ACCEL_LIMIT)
        if self._divider_direction and divider_candidate:
            self._accel = min(self._accel, DIVIDER_ACCEL_LIMIT)
        self._handle = _clip(self._handle, -100.0, 100.0)
        self.debug.update(p=wall_position, d=damping, corner=corner_weight,
                          approach=approach, fallback=fallback)

        if self._divider_direction and divider_candidate:
            comment = '仕切り板：左側へ先行誘導' if self._divider_direction > 0 else '仕切り板：右側へ先行誘導'
        elif narrow_safe:
            comment = "狭路中央維持（左右の前方射線で推定）"
        elif fallback:
            comment = "旋回目標なし：減速して再測距"
        elif corner_weight > 0.01:
            comment = "Gap+PPで右カーブ" if self._turn < 0 else "Gap+PPで左カーブ"
        else:
            comment = "直線・戻りを見ながら補正"
        return self._accel, self._handle, comment


#障害物センサ測定関数
def Mesure(GPIO,time,trig,echo):
    sigoff = 0
    sigon = 0
    GPIO.output(trig,GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(trig,GPIO.LOW)
    kijyun=time.time()
    while(GPIO.input(echo)==GPIO.LOW):
        sigoff=time.time()
        if sigoff - kijyun > 0.02:
            break
    while(GPIO.input(echo)==GPIO.HIGH):
        sigon=time.time()
        if sigon - sigoff > 0.02:
            break
    dis = (sigon - sigoff)*34000/2
    return dis

def main():
    # 実機用ライブラリは走行開始時だけ読み込む。
    # このファイルをimportして走行判断を検証するだけならGPIOは動かない。
    import RPi.GPIO as GPIO
    import Adafruit_PCA9685

    # GPIO初期設定
    GPIO.setmode(GPIO.BOARD)          # GPIOの番号を物理ピン番号で指定
    GPIO.cleanup()                    # GPIO初期化

    # 超音波センサ初期設定
    t_list=[15,13,35,32,36]         # Triger -- Fr:15, FrLH:13, RrLH:35, FrRH:32, RrRH:36
    GPIO.setup(t_list,GPIO.OUT,initial=GPIO.LOW)
    e_list=[33,40,37,31,38]         # Echo -- Fr:33, FrLH:40, RrLH:37, FrRH:31, RrRH:38
    GPIO.setup(e_list,GPIO.IN)

    # PWM初期化
    pwm = Adafruit_PCA9685.PCA9685(address=0x40)
    pwm.set_pwm_freq(60)              # PWMの周波数を60Hzに設定

    STEERING_CHANNEL = 1              # PCA9685のステアリングサーボのチャンネル
    STEERING_RIGHT_PWM = 330          # 右に最大切ったときのPWM
    STEERING_CENTER_PWM = 435         # 直進時のPWM
    STEERING_LEFT_PWM = 540           # 左に最大切ったときのPWM

    THROTTLE_CHANNEL = 7              # PCA9685のスピードコントローラのチャンネル
    THROTTLE_FORWARD_PWM = 500        # 前進全開時のPWM
    THROTTLE_STOPPED_PWM = 375        # 停止時のPWM
    THROTTLE_REVERSE_PWM = 220        # 後退全開時のPWM

    pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)      # 初期値はモータ停止
    pwm.set_pwm(STEERING_CHANNEL, 0, STEERING_CENTER_PWM)       # ステアリング中央

    controller = SmoothDriveController()
    # ESCへの後退開始手順を済ませたか。前進指令を出したときに解除する。
    # 停止して測距している間は維持し、反復後退でブレーキ指令を重ねない。
    reverse_ready = False
    last_log = float('-inf')
    last_comment = None
    try:
        input('Press Enter to start...')
        t = time.monotonic()
        while True:
            # センサーのピン、測定順、測定関数は元と同じ。
            Fr   = Mesure(GPIO,time,15,33)     # Frセンサ距離
            FrLh = Mesure(GPIO,time,13,40)     # FrLhセンサ距離
            FrRh = Mesure(GPIO,time,32,31)     # FrRhセンサ距離
            RrLh = Mesure(GPIO,time,35,37)     # RrLhセンサ距離
            RrRh = Mesure(GPIO,time,36,38)     # RrRhセンサ距離

            now = time.monotonic()
            dt = now - t
            t = now
            Accel, Handle, comment = controller.update(Fr, FrLh, FrRh, RrLh, RrRh, dt)

            # 後退を始める前に、その後退で使うハンドルを反映する。
            # GPIO/PWM設定・換算式は元のまま。後退は短い指令ごとに停止する。
            # サーボドライバーに、ステアリング量を出力
            if Handle <= 0:           # 右折または直進の場合
                steer_pwm = int(STEERING_CENTER_PWM + (STEERING_CENTER_PWM - STEERING_RIGHT_PWM) * Handle / 100)
                pwm.set_pwm(STEERING_CHANNEL, 0, steer_pwm)
            else:                     # 左折の場合
                steer_pwm = int(STEERING_CENTER_PWM + (STEERING_LEFT_PWM - STEERING_CENTER_PWM) * Handle / 100)
                pwm.set_pwm(STEERING_CHANNEL, 0, steer_pwm)

            # サーボドライバーに、スロットル量を出力
            if Accel > 0:             # 前進の場合
                throttle_pwm = int(THROTTLE_STOPPED_PWM + (THROTTLE_FORWARD_PWM - THROTTLE_STOPPED_PWM) * Accel / 100)
                pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)
                reverse_ready = False
            elif Accel == 0:          # 停止の場合
                pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
                time.sleep(0.01)
            else:                     # 後退の場合。初回だけ元の2段階の手順を使う
                throttle_pwm = int(THROTTLE_STOPPED_PWM + (THROTTLE_STOPPED_PWM - THROTTLE_REVERSE_PWM) * Accel / 100)
                if not reverse_ready:
                    pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)       # 初回はブレーキ
                    time.sleep(BRAKE_SECONDS)
                    pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
                    time.sleep(REVERSE_NEUTRAL_SECONDS)
                    reverse_ready = True
                pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)           # 短く後退
                time.sleep(REVERSE_PULSE_SECONDS)
                pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)    # 測距前に必ず停止
                time.sleep(REVERSE_NEUTRAL_SECONDS)  # 60Hzの1周期以上、停止指令を保つ

            if now - last_log >= LOG_INTERVAL_SECONDS or comment != last_comment:
                print('Fr:{:.0f}  FrLh:{:.0f}  FrRh:{:.0f}  RrLh:{:.0f}  RrRh:{:.0f}'
                      .format(Fr, FrLh, FrRh, RrLh, RrRh))
                print('{}  ハンドル={:+.1f}  アクセル={:.1f}  周期={:.3f}s  P={:+.1f} D={:+.1f} C={:.2f}'
                      .format(comment, Handle, Accel, dt,
                              controller.debug['p'], controller.debug['d'], controller.debug['corner']))
                print('Gap={}  PP={:+.1f}  目標距離={:.0f}cm'
                      .format(controller.debug['gap'], controller.debug['pp'],
                              controller.debug['lookahead_cm']))
                print('狭路={} 側方連続={} 安全判定={}'.format(
                    controller.debug['narrow'], controller.debug['side_close_count'],
                    controller.debug['safety_reason']))
                last_log = now
                last_comment = comment
    except KeyboardInterrupt:
        print('停止します')
    finally:
        # Enter待ち中のCtrl+Cや実行時エラーでも、元の停止PWMへ戻す。
        try:
            pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
        finally:
            try:
                pwm.set_pwm(STEERING_CHANNEL, 0, STEERING_CENTER_PWM)
            finally:
                GPIO.cleanup()


if __name__ == '__main__':
    main()
