#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sonic_drive 第6版: 疎な Follow the Gap + 局所目標 Pure Pursuit。

前方3センサーで進路候補を選び、その目標点へPure Pursuitで舵角を計算。
直線では第3版の左右距離PD補正を使い、カーブに近づくほどPPへ移行する。
地図・自己位置を使う経路追従ではなく、毎回作り直す近くの目標を追う方式。
3本の射線間は未観測なので、LiDARと同じ精度で隙間を測れるわけではない。
後方2センサーは左右距離の補正と、従来の接近判定に使う。

GPIO・PWMの設定、Mesure、PWM換算式、短い後退手順は添付版と同じ。
添付版の前進上限80・カーブ下限50を維持。直進中の誤後退を抑える。
距離はcm、時間は秒。車体寸法・実舵角・センサー位置/角度は下の仮設定。
Python 3.6以降。標準ライブラリと既存の実機ライブラリだけで実行できる。

方式の参考（この車両向けの調整値を示す資料ではありません）:
Pure Pursuit: R. Craig Coulter, CMU-RI-TR-92-01 (1992)
https://www.ri.cmu.edu/pub_files/pub3/coulter_r_craig_1992_1/coulter_r_craig_1992_1.pdf
Follow the Gap: F1TENTH Lab 4
https://f1tenth-coursekit.readthedocs.io/en/stable/assignments/labs/lab4.html
"""

import math
import time


# ===== 走行判断の調整値（GPIO・PWMの設定ではありません） =====
FORWARD_ACCEL = 80.0              # 今回の添付版の前進上限を維持。実速度cm/sではない
CURVE_ACCEL = 50.0                # 元と同じカーブのアクセル下限
REVERSE_ACCEL = -50.0             # 元と同じ後退アクセル
REVERSE_HANDLE = 40.0             # 元と同じ後退時のハンドル量
REVERSE_DISTANCE_CM = 35.0        # 元と同じ後退判定距離。生の測定値で判定
BRAKE_SECONDS = 0.20             # 後退に入れる最初のブレーキ時間は維持
REVERSE_NEUTRAL_SECONDS = 0.02   # 元のニュートラル時間。後退パルスの終了時にも確保
REVERSE_PULSE_SECONDS = 0.12     # 1回の後退指令。終了後は必ず停止して再測距

FRONT_WALL_GAIN = 0.28            # 前方左右の距離差 → ハンドル量。前方の補正を主に使う
REAR_WALL_GAIN = 0.20             # 後方の補正を弱め、戻り始めても切り続ける動きを抑える
FRONT_DEADBAND_CM = 6.0           # 前方左右の差がこの範囲なら補正しない
REAR_DEADBAND_CM = 4.0            # 後方左右の差がこの範囲なら補正しない
FRONT_COMPARE_MAX_CM = 160.0      # 遠い開口部に急に引っ張られないよう上限を設ける
REAR_COMPARE_MAX_CM = 80.0
WALL_HANDLE_LIMIT = 22.0          # 直線の通常補正は±22まで。カーブは別に最大±100
WALL_DAMPING_SECONDS = 0.55       # 距離差の変化に応じ、中央へ戻る途中から舵を戻す強さ
WALL_DAMPING_TAU = 0.12           # 変化率だけを平滑化して測距ノイズの増幅を抑える
WALL_DAMPING_LIMIT = 12.0         # 変化率による補正の上限 [%ポイント]
WALL_RATE_LIMIT = 100.0           # 変化率の異常な跳ねを抑える [%ポイント/秒]
WALL_DAMPING_DEADBAND = 1.0       # 小さな変化率の補正は出さない [%ポイント]
WALL_HISTORY_GAP_SECONDS = 0.25   # 間隔が空いたら変化率の履歴を捨てる
CORRECTION_SLOW_HANDLE = 6.0      # 強めの直線補正中は加速を抑える

DISTANCE_FILTER_TAU = 0.10        # 距離の平滑化。大きいほど穏やか、反応は遅い
STEERING_FILTER_TAU = 0.07        # 戻す指令が遅れないよう、通常の出力側の遅れを小さく
STEERING_RATE = 140.0            # 通常の最大ハンドル変化量 [%ポイント/秒]
CORNER_STEERING_TAU = 0.055       # カーブ中は平滑化による遅れを小さくする
CORNER_STEERING_RATE = 360.0      # カーブ中の最大ハンドル変化量
NEAR_STEERING_RATE = 400.0        # 壁が近いときは曲がり遅れを抑える

CORNER_START_CM = 260.0           # 正面260cmからPD→PPを移行。後退距離とは別
CORNER_FULL_CM = 150.0             # この距離でPPの寄与100%。最大舵角100%の意味ではない
CORNER_EXIT_CM = 280.0            # 解除を別の距離にして境目での切替を防ぐ
CORNER_EXIT_SECONDS = 0.15
TURN_CHOICE_MARGIN_CM = 12.0     # 左右の開き具合がほぼ同じなら方向を維持
TURN_SWITCH_MARGIN_CM = 45.0     # 反対側が明確に開いている場合だけ方向変更
TURN_SWITCH_SECONDS = 0.15       # 明確な逆カーブへの切り返しも早める
ACCEL_RISE_RATE = 15.0           # 前進中の加速を穏やかにする [%ポイント/秒]
ACCEL_FALL_RATE = 60.0
LOG_INTERVAL_SECONDS = 0.20      # 毎周期の大量表示による処理時間のばらつきを抑える


# ===== 車体モデルの仮設定（GPIO・PWM設定は変更しません） =====
# 元コードに実測値がないため仮置き。取り付け位置と実タイヤ舵角に合わせること。
# 後輪軸中心を(0,0)、x=前方、y=左とする。長さはすべてcm。
WHEELBASE_CM = 25.0               # 前後輪の軸間距離。車体の全長ではない
MAX_ROAD_WHEEL_STEER_DEG = 25.0   # Handle±100に対応するタイヤの実舵角の絶対値
VEHICLE_WIDTH_CM = 18.0           # 車幅。隙間候補の障害物余裕に使用
# 右FrRh → 正面Fr → 左FrLh。位置も角度も仮定であり実測値ではない。
FRONT_RAY_ANGLES_DEG = (-45.0, 0.0, 45.0)
FRONT_RAY_ORIGINS_CM = ((25.0, -8.0), (30.0, 0.0), (25.0, 8.0))

# ===== Follow the Gap / Pure Pursuit の調整値 =====
GAP_SIDE_MARGIN_CM = 8.0          # 車幅の半分に加える、観測障害物周囲の余裕
GAP_END_MARGIN_CM = 20.0          # 測距した終端より手前に目標を置く余裕
GAP_REENTRY_MARGIN_CM = 5.0       # 一度無効になった射線は5cmの余裕が戻るまで再使用しない
PP_MIN_ADVANCE_CM = 25.0          # センサーから目標までに必要な最小距離
PP_STRAIGHT_ADVANCE_CM = 95.0     # センサーから目標までの通常の距離
PP_FAST_ADVANCE_CM = 125.0        # 大きい前進指令で遠くを見る（速度計測ではない）
PP_CORNER_ADVANCE_CM = 45.0       # カーブでは近い目標へ。32cmより過大な初動操舵を抑える

# 中央仕切り板（直線140cmの中央に障害物、左右どちらかに通行帯）
# 3本の超音波射線で「候補方向」を推定するだけで、70cmの実幅は保証できない。
DIVIDER_DETECT_CM = 260.0
DIVIDER_OPEN_EXTRA_CM = 20.0       # 斜め側が正面よりどれだけ遠いか
DIVIDER_MIN_SIDE_CM = 80.0       # 安全を優先し、短い側方射線では進入しない
DIVIDER_CONFIRM_CYCLES = 2
DIVIDER_ACCEL_LIMIT = 50.0
DIVIDER_REVERSE_CONFIRM_CYCLES = 3  # 逆側への切替は連続観測で確認
DIVIDER_SIDE_DIFFERENCE_CM = 18.0  # 左右が曖昧な場合は方向を決めない
DIVIDER_MIN_CORNER_WEIGHT = 0.55
# 仕切り板は「左右双方が見通せる」形を優先。通常のL字カーブを横取りしない。
DIVIDER_OTHER_SIDE_MIN_CM = 75.0
DIVIDER_OTHER_SIDE_FRONT_RATIO = 0.38  # 正面距離に対する短い側の必要割合

# 狭路モード: 前方左右が両方壁を見ている場合のみ確認する。角度は仮設定。
NARROW_FRONT_CLEAR_CM = 90.0
NARROW_SIDE_MIN_CM = 18.0
NARROW_SIDE_MAX_CM = 65.0
NARROW_BALANCE_CM = 18.0
NARROW_CONFIRM_CYCLES = 3
NARROW_EXIT_CYCLES = 5
NARROW_ACCEL_LIMIT = 50.0
NARROW_HANDLE_LIMIT = 18.0
NARROW_SIDE_GAIN = 0.40
NARROW_EMERGENCY_CM = 15.0
# 側方の1回だけの近距離エコーでは後退しない（停止して再測距）。
SIDE_REVERSE_CONFIRM_CYCLES = 3
SIDE_REVERSE_CRITICAL_CM = 15.0  # 単発値は即後退せず停止確認
TURN_CONFIRM_CYCLES = 2  # 初回旋回方向は2測定で確認
# 狭路の判定が確定するまで、候補中は停止して確認する。
# 正面の後退判定（35cm未満）は必ず優先する。



def _clip(value, low, high):
    return max(low, min(high, value))


def _deadband(value, width):
    if value > width:
        return value - width
    if value < -width:
        return value + width
    return 0.0


def _smoothstep(value):
    value = _clip(value, 0.0, 1.0)
    return value * value * (3.0 - 2.0 * value)


def _sparse_gaps(ranges, avoid_front, depth_usable):
    """右/正面/左の3本だけから、隣接する進路候補の組を返す。

    射線間に架空の測距点を増やさない。連続した候補は通行保証ではない。
    中央は早めの旋回計画のため150cmから除外する。一方、左右には
    近い局所目標を置ける長さが必要。中央と左右の計画距離を分ける。
    """
    minimum_range = PP_MIN_ADVANCE_CM + GAP_END_MARGIN_CM
    blocked = [not usable or distance < minimum_range
               for usable, distance in zip(depth_usable, ranges)]
    if avoid_front:
        blocked[1] = True

    # 障害物の周囲に車幅+余裕の角度領域を設け、近隣の候補も除外する。
    # 十分遠い直線で、最短の射線を無条件に消して左右へ逸れる処理はしない。
    # 角度領域は共通原点での近似。実センサーのビーム幅は不明である。
    radius = VEHICLE_WIDTH_CM / 2.0 + GAP_SIDE_MARGIN_CM
    seeds = list(blocked)
    for index, is_blocked in enumerate(seeds):
        if not is_blocked:
            continue
        half_angle = math.degrees(math.asin(_clip(radius / ranges[index], 0.0, 1.0)))
        for other, angle in enumerate(FRONT_RAY_ANGLES_DEG):
            if abs(angle - FRONT_RAY_ANGLES_DEG[index]) <= half_angle:
                blocked[other] = True

    gaps = []
    start = None
    for index in range(len(ranges) + 1):
        is_free = index < len(ranges) and not blocked[index]
        if is_free and start is None:
            start = index
        elif not is_free and start is not None:
            gaps.append(tuple(range(start, index)))
            start = None
    return gaps, tuple(blocked)


def _pure_pursuit_handle(goal_x_cm, goal_y_cm):
    """後輪軸から見た局所目標 → (Handle, 曲率[1/cm])。正は左。

    車両への舵角指令は atan(L * 2y / (x*x+y*y))。
    PWMではなく実タイヤ舵角を使ってHandleへ換算する線形モデル。
    """
    distance_squared = goal_x_cm * goal_x_cm + goal_y_cm * goal_y_cm
    if distance_squared <= 1e-9:
        return 0.0, 0.0
    curvature = 2.0 * goal_y_cm / distance_squared
    steer_degrees = math.degrees(math.atan(WHEELBASE_CM * curvature))
    handle = 100.0 * steer_degrees / MAX_ROAD_WHEEL_STEER_DEG
    return _clip(handle, -100.0, 100.0), curvature


class SmoothDriveController:
    """Five-range right-wall follower. No map, position, elapsed-route script or simulator API."""
    PARAMS = dict(target=48.0, angle_gain=2.7, distance_gain=1.1,
                  turn_start=100.0, turn_release=150.0, accel=30.0,
                  fit_limit=55.0, max_handle=100.0, rate=260.0)

    def __init__(self):
        self.params=dict(self.PARAMS)
        self._filtered=None
        self._handle=0.0
        self._turn=False
        self._last_angle=0.0
        self._follow_left=False
        self.debug=dict(p=0.,d=0.,corner=0.,gap='right_wall',pp=0.,
                        lookahead_cm=0.,narrow=False,side_close_count=0,safety_reason='')

    def update(self, Fr, FrLh, FrRh, RrLh, RrRh, dt):
        try:
            raw=[float(v) for v in (Fr,FrLh,FrRh,RrLh,RrRh)]
            dt=float(dt)
            valid=all(math.isfinite(v) and 0<v<=500 for v in raw)
            valid=valid and math.isfinite(dt) and 0<dt<=.5
        except (ValueError,TypeError,OverflowError):
            valid=False
        if not valid:
            self._follow_left=False
            self._filtered=None
            self._handle=0.
            self._turn=False
            self.debug['safety_reason']='測距・周期異常：停止'
            return 0.,0.,self.debug['safety_reason']
        if raw[0]<16 or min(raw[1:3])<12 or min(raw[3:])<8:
            self.debug['safety_reason']='接近限界：停止'
            return 0.,0.,self.debug['safety_reason']
        self.debug['safety_reason']=''
        step=min(dt,.1)
        if self._filtered is None:self._filtered=raw[:]
        alpha=1-math.exp(-step/0.06)
        self._filtered=[a+alpha*(b-a) for a,b in zip(self._filtered,raw)]
        f,fl,fr,sl,sr=self._filtered
        front=min(f,raw[0]); p=self.params
        # Local endpoints from provisional sensor mounts: front-right (20,-7.5),
        # side-right (14,-9). Estimate wall orientation only when consistent.
        ray=fr/math.sqrt(2)
        slope=(1.5+sr-ray)/(6+ray)
        angle=math.degrees(math.atan(slope))
        reliable=fr<300 and sr<250 and abs(angle)<p['fit_limit']
        if reliable:
            self._last_angle=angle
            clearance=(9+sr+14*slope)/math.sqrt(1+slope*slope)
            demand=p['angle_gain']*angle+p['distance_gain']*(p['target']-clearance)
        elif sr<200:
            demand=p['distance_gain']*(p['target']-(sr+9))
        else:
            # Search right when the right wall disappears; re-evaluate every scan.
            demand=-60.0
        # 右側が凹んだ広い区間では、遠ざかった右壁を追って寄り込まない。
        # 左の壁が観測でき、左との間隔が広すぎる場合は左壁基準を保持。
        left_ray=fl/math.sqrt(2)
        left_slope=(left_ray-1.5-sl)/(6+left_ray)
        left_angle=math.degrees(math.atan(left_slope))
        left_reliable=fl<250 and sl<170 and abs(left_angle)<p['fit_limit']
        if self._follow_left:
            if not left_reliable or front<120 or sr>160:
                self._follow_left=False
        elif (left_reliable and abs(left_angle)<20 and front>160
              and sl>80.0 and sr<95 and ray>sr+15):
            self._follow_left=True
        if self._follow_left:
            left_clearance=(9+sl-14*left_slope)/math.sqrt(1+left_slope*left_slope)
            demand=p['angle_gain']*left_angle+p['distance_gain']*(left_clearance-69.0)
        self.debug['wall_reference']='left' if self._follow_left else 'right'
        if front<p['turn_start']: self._turn=True
        if self._turn and front>p['turn_release']:self._turn=False
        if self._turn:
            demand=p['max_handle']
        # Escape a close right diagonal toward the left rather than wait forever.
        if raw[2]<35 and front>50:demand=max(demand,50.)
        if raw[1]<25 and front>50:demand=min(demand,-50.)
        demand=_clip(demand,-p['max_handle'],p['max_handle'])
        self._handle+=_clip(demand-self._handle,-p['rate']*step,p['rate']*step)
        # 両側の壁が近く、正面に余裕がある狭路では操舵量による
        # 減速を掛けず、通常アクセル指令30を維持する。
        # 接近限界・異常値の停止判定は、この処理より前で実施済み。
        narrow = (raw[0] >= 90.0 and min(raw[1:3]) >= 25.0
                  and max(raw[1:3]) <= 100.0 and max(raw[3:]) <= 65.0)
        accel = p['accel'] if narrow else p['accel']*max(.5,1-0.3*abs(self._handle)/100)
        self.debug['narrow'] = narrow
        self.debug.update(p=demand,d=angle,corner=float(self._turn),pp=self._handle,
                          lookahead_cm=front,gap='left_corner' if self._turn else 'right_wall')
        if self._turn:comment='右壁基準・左旋回'
        elif self._follow_left:comment='凹み回避：左壁との間隔を維持'
        else:comment='右壁の向きと間隔を維持'
        return accel,self._handle,comment


#障害物センサ測定関数
def Mesure(GPIO,time,trig,echo):
    sigoff = 0
    sigon = 0
    GPIO.output(trig,GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(trig,GPIO.LOW)
    kijyun=time.time()
    while(GPIO.input(echo)==GPIO.LOW):
        sigoff=time.time()
        if sigoff - kijyun > 0.02:
            break
    while(GPIO.input(echo)==GPIO.HIGH):
        sigon=time.time()
        if sigon - sigoff > 0.02:
            break
    dis = (sigon - sigoff)*34000/2
    return dis

def main():
    # 実機用ライブラリは走行開始時だけ読み込む。
    # このファイルをimportして走行判断を検証するだけならGPIOは動かない。
    import RPi.GPIO as GPIO
    import Adafruit_PCA9685

    # GPIO初期設定
    GPIO.setmode(GPIO.BOARD)          # GPIOの番号を物理ピン番号で指定
    GPIO.cleanup()                    # GPIO初期化

    # 超音波センサ初期設定
    t_list=[15,13,35,32,36]         # Triger -- Fr:15, FrLH:13, RrLH:35, FrRH:32, RrRH:36
    GPIO.setup(t_list,GPIO.OUT,initial=GPIO.LOW)
    e_list=[33,40,37,31,38]         # Echo -- Fr:33, FrLH:40, RrLH:37, FrRH:31, RrRH:38
    GPIO.setup(e_list,GPIO.IN)

    # PWM初期化
    pwm = Adafruit_PCA9685.PCA9685(address=0x40)
    pwm.set_pwm_freq(60)              # PWMの周波数を60Hzに設定

    STEERING_CHANNEL = 1              # PCA9685のステアリングサーボのチャンネル
    STEERING_RIGHT_PWM = 330          # 右に最大切ったときのPWM
    STEERING_CENTER_PWM = 435         # 直進時のPWM
    STEERING_LEFT_PWM = 540           # 左に最大切ったときのPWM

    THROTTLE_CHANNEL = 7              # PCA9685のスピードコントローラのチャンネル
    THROTTLE_FORWARD_PWM = 500        # 前進全開時のPWM
    THROTTLE_STOPPED_PWM = 375        # 停止時のPWM
    THROTTLE_REVERSE_PWM = 220        # 後退全開時のPWM

    pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)      # 初期値はモータ停止
    pwm.set_pwm(STEERING_CHANNEL, 0, STEERING_CENTER_PWM)       # ステアリング中央

    controller = SmoothDriveController()
    # ESCへの後退開始手順を済ませたか。前進指令を出したときに解除する。
    # 停止して測距している間は維持し、反復後退でブレーキ指令を重ねない。
    reverse_ready = False
    last_log = float('-inf')
    last_comment = None
    try:
        input('Press Enter to start...')
        t = time.monotonic()
        while True:
            # センサーのピン、測定順、測定関数は元と同じ。
            Fr   = Mesure(GPIO,time,15,33)     # Frセンサ距離
            FrLh = Mesure(GPIO,time,13,40)     # FrLhセンサ距離
            FrRh = Mesure(GPIO,time,32,31)     # FrRhセンサ距離
            RrLh = Mesure(GPIO,time,35,37)     # RrLhセンサ距離
            RrRh = Mesure(GPIO,time,36,38)     # RrRhセンサ距離

            now = time.monotonic()
            dt = now - t
            t = now
            Accel, Handle, comment = controller.update(Fr, FrLh, FrRh, RrLh, RrRh, dt)

            # 後退を始める前に、その後退で使うハンドルを反映する。
            # GPIO/PWM設定・換算式は元のまま。後退は短い指令ごとに停止する。
            # サーボドライバーに、ステアリング量を出力
            if Handle <= 0:           # 右折または直進の場合
                steer_pwm = int(STEERING_CENTER_PWM + (STEERING_CENTER_PWM - STEERING_RIGHT_PWM) * Handle / 100)
                pwm.set_pwm(STEERING_CHANNEL, 0, steer_pwm)
            else:                     # 左折の場合
                steer_pwm = int(STEERING_CENTER_PWM + (STEERING_LEFT_PWM - STEERING_CENTER_PWM) * Handle / 100)
                pwm.set_pwm(STEERING_CHANNEL, 0, steer_pwm)

            # サーボドライバーに、スロットル量を出力
            if Accel > 0:             # 前進の場合
                throttle_pwm = int(THROTTLE_STOPPED_PWM + (THROTTLE_FORWARD_PWM - THROTTLE_STOPPED_PWM) * Accel / 100)
                pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)
                reverse_ready = False
            elif Accel == 0:          # 停止の場合
                pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
                time.sleep(0.01)
            else:                     # 後退の場合。初回だけ元の2段階の手順を使う
                throttle_pwm = int(THROTTLE_STOPPED_PWM + (THROTTLE_STOPPED_PWM - THROTTLE_REVERSE_PWM) * Accel / 100)
                if not reverse_ready:
                    pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)       # 初回はブレーキ
                    time.sleep(BRAKE_SECONDS)
                    pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
                    time.sleep(REVERSE_NEUTRAL_SECONDS)
                    reverse_ready = True
                pwm.set_pwm(THROTTLE_CHANNEL, 0, throttle_pwm)           # 短く後退
                time.sleep(REVERSE_PULSE_SECONDS)
                pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)    # 測距前に必ず停止
                time.sleep(REVERSE_NEUTRAL_SECONDS)  # 60Hzの1周期以上、停止指令を保つ

            if now - last_log >= LOG_INTERVAL_SECONDS or comment != last_comment:
                print('Fr:{:.0f}  FrLh:{:.0f}  FrRh:{:.0f}  RrLh:{:.0f}  RrRh:{:.0f}'
                      .format(Fr, FrLh, FrRh, RrLh, RrRh))
                print('{}  ハンドル={:+.1f}  アクセル={:.1f}  周期={:.3f}s  P={:+.1f} D={:+.1f} C={:.2f}'
                      .format(comment, Handle, Accel, dt,
                              controller.debug['p'], controller.debug['d'], controller.debug['corner']))
                print('Gap={}  PP={:+.1f}  目標距離={:.0f}cm'
                      .format(controller.debug['gap'], controller.debug['pp'],
                              controller.debug['lookahead_cm']))
                print('狭路={} 側方連続={} 安全判定={}'.format(
                    controller.debug['narrow'], controller.debug['side_close_count'],
                    controller.debug['safety_reason']))
                last_log = now
                last_comment = comment
    except KeyboardInterrupt:
        print('停止します')
    finally:
        # Enter待ち中のCtrl+Cや実行時エラーでも、元の停止PWMへ戻す。
        try:
            pwm.set_pwm(THROTTLE_CHANNEL, 0, THROTTLE_STOPPED_PWM)
        finally:
            try:
                pwm.set_pwm(STEERING_CHANNEL, 0, STEERING_CENTER_PWM)
            finally:
                GPIO.cleanup()


if __name__ == '__main__':
    main()
