'use strict';
const $ = id => document.getElementById(id);
const ctx = $('view').getContext('2d');
let data, time = 0, playing = false, last;
function pause() { playing = false; $('play').textContent = '再生'; }
function load() { pause(); data = window.TOF_REPLAYS[$('trial').value]; time = 0; $('seek').max = data.frames.at(-1).t; draw(); }
function line(points, color, width) {
  if (!points.length) return;
  ctx.beginPath(); points.forEach(([x,y],i) => i ? ctx.lineTo(x,760-y) : ctx.moveTo(x,760-y));
  ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
}
function draw() {
  const frames = data.frames;
  let index = 0;
  while (index + 1 < frames.length && frames[index + 1].t <= time) index++;
  const f = frames[index];
  ctx.clearRect(0,0,1190,760);
  data.course.walls.forEach(([a,b,c,d]) => line([[a,b],[c,d]],'#526477',4));
  line(frames.slice(0,index+1).map(f=>[f.x,f.y]),'#eb8b23',3);
  ctx.beginPath(); f.body.forEach(([x,y],i)=>i?ctx.lineTo(x,760-y):ctx.moveTo(x,760-y)); ctx.closePath(); ctx.fillStyle='#eb8b23'; ctx.fill();
  line([[f.x,f.y],[f.x+30*Math.cos(f.heading),f.y+30*Math.sin(f.heading)]],'#172b40',3);
  $('seek').value = time;
  const sensors = Object.entries(f.measured).map(([k,v])=>`${k}: ${Number(v).toFixed(1)} cm`).join(' / ');
  $('status').textContent = `時刻 ${time.toFixed(2)} / ${Number($('seek').max).toFixed(2)} 秒　速度 ${f.speed.toFixed(1)} cm/s\n走行距離 ${(f.distance_cm/100).toFixed(2)} m　接触 ${f.collisions}　後退パルス ${f.reverse_pulses}\n${f.comment || f.phase}\n${sensors}`;
}
$('trial').onchange = load;
$('play').onclick = () => { if (playing) pause(); else { if(time >= Number($('seek').max)) time = 0; playing = true; $('play').textContent='一時停止'; } };
$('reset').onclick = () => { pause(); time=0; draw(); };
$('seek').oninput = () => { time=Number($('seek').value); draw(); };
function tick(now) { if(playing && last !== undefined) { time = Math.min(Number($('seek').max),time+(now-last)/1000*Number($('rate').value)); if(time>=Number($('seek').max)) pause(); draw(); } last=now; requestAnimationFrame(tick); }
load(); requestAnimationFrame(tick);
