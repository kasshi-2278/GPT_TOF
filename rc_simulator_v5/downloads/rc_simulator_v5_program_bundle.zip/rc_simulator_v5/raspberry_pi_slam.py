"""HC-SR04 + the original PCA9685 wiring; imports hardware only on Raspberry Pi.

Use a measured calibration JSON. The simulation contains no hardware drivers.
"""
import argparse
import csv
import json
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from learned_navigation import DriveCalibration, NAMES
from sonar_slam_drive import Controller

def measure(GPIO, trig, echo, sound_speed):
    GPIO.output(trig, True)
    time.sleep(.00001)
    GPIO.output(trig, False)
    deadline = time.monotonic()+.003
    while not GPIO.input(echo):
        if time.monotonic() >= deadline:
            return None
    rise = time.monotonic()
    while GPIO.input(echo):
        if time.monotonic()-rise > .025:
            return None
    fall = time.monotonic()
    distance = (fall-rise)*sound_speed/2
    return min(250., distance) if distance > 0 else None

def export(controller, directory):
    controller.slam.save(directory/'learned_map.npz')
    if controller.route:
        (directory/'learned_route.json').write_text(json.dumps(controller.route.path.tolist()))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--calibration',required=True,type=Path,
                        help='Measured drive/mount values; see calibration_slam.example.json')
    parser.add_argument('--hardware',type=Path,default=Path(__file__).with_name('hardware.json'))
    parser.add_argument('--output',type=Path,default=Path('sonar_slam_run'))
    args = parser.parse_args()
    calibration = json.loads(args.calibration.read_text())
    hardware = json.loads(args.hardware.read_text())
    controller = Controller(DriveCalibration(**calibration['drive']),
                            [calibration['mounts'][name] for name in NAMES])
    import RPi.GPIO as GPIO
    import Adafruit_PCA9685
    GPIO.setmode(GPIO.BOARD)
    pins = hardware['sensor_pins_board']
    triggers = [pins[n][0] for n in NAMES]
    echoes = [pins[n][1] for n in NAMES]
    GPIO.setup(triggers,GPIO.OUT,initial=GPIO.LOW)
    GPIO.setup(echoes,GPIO.IN)
    pwm = Adafruit_PCA9685.PCA9685(address=hardware['pca9685_address'])
    pwm.set_pwm_freq(hardware['pwm_frequency_hz'])
    lock = threading.Lock()
    halt = threading.Event()
    watchdog_fault = threading.Event()
    last_output = [time.monotonic()]

    def write(accel, handle):
        with lock:
            if watchdog_fault.is_set():
                accel,handle = 0.,0.
            if accel < 0:
                raise ValueError('This hardware runner uses forward/stop only')
            throttle = hardware['throttle_stopped_pwm']+(hardware['throttle_forward_pwm']-hardware['throttle_stopped_pwm'])*accel/100
            if handle >= 0:
                steering = hardware['steering_center_pwm']+(hardware['steering_left_pwm']-hardware['steering_center_pwm'])*handle/100
            else:
                steering = hardware['steering_center_pwm']+(hardware['steering_center_pwm']-hardware['steering_right_pwm'])*handle/100
            pwm.set_pwm(hardware['throttle_channel'],0,round(throttle))
            pwm.set_pwm(hardware['steering_channel'],0,round(steering))
            last_output[0] = time.monotonic()

    def watchdog():
        while not halt.wait(.01):
            if time.monotonic()-last_output[0] > .25:
                watchdog_fault.set()
                write(0.,0.)
                return

    worker = None
    io = ThreadPoolExecutor(max_workers=1,thread_name_prefix='map-export')
    args.output.mkdir(parents=True,exist_ok=True)
    saved = False
    try:
        write(0.,0.)
        input('Press Enter to start ultrasonic mapping...')
        last = time.monotonic()
        last_output[0] = last
        worker = threading.Thread(target=watchdog,daemon=True)
        worker.start()
        with (args.output/'drive.csv').open('w',newline='') as stream:
            log = csv.writer(stream)
            log.writerow(['elapsed_s',*NAMES,'accel','handle','estimated_x_cm','estimated_y_cm','estimated_heading_rad','phase'])
            beginning = last
            while not watchdog_fault.is_set():
                cycle = time.monotonic()
                sensors = {}; stamps = {}
                for name in NAMES:
                    sensors[name] = measure(GPIO,*pins[name],hardware['sound_speed_cm_s'])
                    stamps[name] = time.monotonic()
                    time.sleep(.002)
                now = time.monotonic()
                sensors['_ages_s'] = {name:now-stamps[name] for name in NAMES}
                accel, handle, state = controller.step(sensors,now-last)
                last = now
                if watchdog_fault.is_set():
                    break
                write(accel,handle)
                log.writerow([now-beginning,*[sensors[n] for n in NAMES],accel,handle,*controller.slam.pose,controller.phase])
                if controller.route and not saved:
                    io.submit(export,controller,args.output)
                    saved = True
                if controller.fault_reason or controller.reactive.stopped:
                    print(state)
                    break
                time.sleep(max(0.,.1-(time.monotonic()-cycle)))
    finally:
        halt.set()
        write(0.,0.)
        if worker:
            worker.join(timeout=.5)
        io.shutdown(wait=True)
        export(controller,args.output)
        GPIO.cleanup(triggers+echoes)

if __name__ == '__main__':
    main()
