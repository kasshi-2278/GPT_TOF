# 超音波だけの地図学習走行（Raspberry Pi 3 / 1 GBを設計目安）

## 動作

- 1周目：5個のHC-SR04で壁の反射点と空き領域を学習します。
- 自己位置は前回のモーター・操舵出力から予測し、超音波反射点と自作地図の壁との照合で補正します。真の車体座標、既存コース図、GPS、カメラ、追加センサーは入力しません。
- 初期位置付近への帰還を自分の推定位置と測距の一致から検知し、地図を固定します。
- 2周目以降：観測済みの安全領域でA*による経路短縮を行い、Pure Pursuitで追従します。周回を維持するため、1周目から学習した通過点の順序を維持します。「最短」はこの順序と観測範囲、安全距離の条件内です。未知領域を横切る大域的最短経路は保証しません。
- 生の近距離測距を常に優先し、危険時は元の超音波回避へ戻ります。計画できない場合は地図走行へ移行せず探索を継続します。

## Pi向けの処理量

制御・地図照合は目標10 Hzです。初回マッピング速度は衝突リスクを確認して30設定にしました。4 cm刻み・768×768のグリッドは約1.18 MBです。壁点2万、記録位置5千の上限と地図範囲を超えたら停止します。経路計算と地図保存は別スレッドです。重い描画やシミュレーターは実機で起動しません。

シミュレーターで初回マッピングは約171〜174秒（以前の約200秒から約14%短縮）でした。100秒には届いていません。より速い設定では見通し外の支柱との接触や、地図不足の安全停止が起きたため採用していません。クラウドでの処理時間は検証レポートに記載します。Pi 3実機での時間・GPIO精度・超音波干渉は未測定です。Linux上のPythonはハードリアルタイムではありません。

## 100試行の速度最適化

2026-10-08に、速度・Pure Pursuit先読み距離・Follow the Gap操舵・安全回避値を変えた100回の3周シミュレーションを行いました。安全に3周した単発最速は試行75、探索アクセル36・地図走行アクセル75・先読み60 cmで263.20秒（約143.95 / 59.82 / 59.33秒）でした。ただし、この設定は10回の追加検証で安定完走せず、衝突も起きたため既定値には採用していません。

既定値は探索アクセル30、周回アクセル45を維持します。選んだ速度設定の追加10回は8回完走、衝突0回でしたが、0.5 cmセンサーノイズの2回で1周目の地図作成が安全停止しました（うち1回で危険接近判定1回）。このため安定完走が確認できたとは扱わず、実走行前にセンサー配置・ノイズ・回避挙動を再確認してください。100秒の初回マッピングと100%の再検証完走率は達成できていません。

全試行の設定・ラップ時間・衝突/危険接近・操舵指標は`optimization/sonar_slam/optimization_100.csv`と各`opt100_NNN.json`に保存しました。追加10回は`final_validation.csv`と`final_XX.csv`にあります。

## インストール（Raspberry Pi OS、Python 3.10以上）

```bash
sudo apt-get update
sudo apt-get install python3-numpy python3-scipy python3-rpi.gpio python3-venv
python3 -m venv --system-site-packages .venv-pi
.venv-pi/bin/python -m pip install Adafruit-PCA9685
```

I2Cを有効にし、元の`hardware.json`のBOARDピン番号とPCA9685設定を確認してください。HC-SR04のEchoは5Vなので、Piの3.3V入力には分圧またはレベル変換が必要です。

## 実機校正と起動

`calibration_slam.example.json`をコピーして`calibration_slam.json`を作成します。サンプルの運動係数はシミュレーター用であり、そのまま実機性能の保証にはなりません。速度とアクセル指令、最大操舵角、操舵応答、加減速応答を実車で測定し、係数を置き換えてください。指令と速度が大きく非線形の場合は予測モデルにも変更が必要です。

車体は28×20 cm、ホイールベース17 cm、タイヤ直径5.5 cmを想定します。前センサーは前端から2 cm・左右中央です。他4個の取り付け座標は暫定値なので実測して置き換えてください。距離単位はcmです。`RrLh/RrRh`という従来の名前は、前半分に取り付けた左右90度センサーを表します。

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv-pi/bin/python raspberry_pi_slam.py \
  --calibration calibration_slam.json --output sonar_slam_run
```

Enterで開始、Ctrl+Cで終了します。測距異常や制御更新停止は停止指令を出し、異常は解除せず再起動を要求します。ソフトウェアの停止指令はモーター・I2C故障時の物理停止を保証しません。実機の停止手段も用意してください。ログ、`learned_map.npz`、`learned_route.json`を出力します。地図を次回起動で自動ロードする機能はありません。

## シミュレーターと再検証

```bash
python -m pip install -r requirements_slam.txt
python -m unittest tests.test_learned_navigation
python -m optimization.sonar_slam.evaluate --name my_run
python -m optimization.sonar_slam.validate
```

GUIでは`sonar_slam_drive.py`を走行プログラムに指定します。センサー値と制御周期だけを受け取るインターフェースです。

Pi上の計算時間の目安を測る場合は、走行ログだけを再生します。

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv-pi/bin/python benchmark_slam.py \
  optimization/sonar_slam/final_01.csv --output pi_benchmark.json
```

ベンチマークは測距待ち・GPIO出力を含みません。実走行では`drive.csv`の更新周期も確認してください。詳細と未解決事項は`optimization/sonar_slam/REPORT.md`を参照してください。
