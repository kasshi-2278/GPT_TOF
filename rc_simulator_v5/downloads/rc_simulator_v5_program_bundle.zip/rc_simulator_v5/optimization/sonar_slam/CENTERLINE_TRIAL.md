# Learned centerline trial

Compared two three-lap runs from the same initial state (seed 7, no added sensor noise). Both mapped the course on lap one and used only the five ultrasonic readings for driving decisions on later laps. `center_weight=0` is the current shortest-path behavior; `center_weight=1` adds a cost for cells with less clearance from walls observed in the learned map.

|Result|Shortest path (`center_weight=0`)|Clearance-weighted (`center_weight=1`)|
|---|---:|---:|
|Three-lap time|371.90 s|373.70 s|
|Lap times|173.37 / 99.23 / 99.29 s|173.28 / 100.19 / 100.21 s|
|Collisions / danger|0 / 0|0 / 0|
|Weave count|45|56|
|Planned route length|3422 cm|3579 cm|
|Mean route-cell distance from mapped occupied cells|58.2 cm|60.5 cm|
|Minimum vehicle clearance|14.3 cm|14.3 cm|

This single trial moved the planned path about 2.3 cm farther from mapped wall returns on average. It also added 1.8 seconds and increased the weave metric by 11. The vehicle completed without a collision, but the measured time and smoothness were slightly worse. Center weighting is available through `Controller.CENTER_WEIGHT` and the evaluator's `center_weight` option; the production default remains zero pending a better smooth centerline method.

Run artifacts: `centerline_baseline.csv/json` and `centerline_weight_1.csv/json`. The replay video is `../../videos/sonar_slam_centerline_trial.mp4`.
