"""Render a two-panel replay from a completed final ultrasonic SLAM run."""
import csv
import json
import math
import argparse
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter, FuncAnimation
from matplotlib.patches import Circle, Polygon

from config import VehicleConfig
from geometry import direction, local_to_world, rectangle
from world import World

ROOT = Path(__file__).resolve().parents[2]
FPS = 12
SENSORS = ('Fr', 'FrLh', 'RrLh', 'FrRh', 'RrRh')
COLORS = ('#52d6ff', '#ffbc42', '#ff5f77', '#b88cff', '#76e3a2')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--trace', default='optimization/sonar_slam/final_01.csv')
    parser.add_argument('--result', default='optimization/sonar_slam/final_01.json')
    parser.add_argument('--output', default='videos/sonar_slam_100trial_final_validation.mp4')
    args = parser.parse_args()
    trace_path = ROOT / args.trace
    result_path = ROOT / args.result
    output_path = ROOT / args.output
    with trace_path.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    numeric = ('time_s', 'x_cm', 'y_cm', 'heading_deg', 'speed_cm_s', 'Handle', 'lap_count') + SENSORS
    for row in rows:
        for key in numeric:
            row[key] = float(row[key] or 0)
    result = json.loads(result_path.read_text(encoding='utf-8'))
    world = World.load()
    cfg = VehicleConfig()
    specs = cfg.sensor_specs()
    extent = world.extents

    plt.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 10,
        'figure.facecolor': '#0c1422', 'axes.facecolor': '#101c2c',
        'text.color': '#e8f0fa', 'axes.labelcolor': '#b5c7db',
        'xtick.color': '#8da2ba', 'ytick.color': '#8da2ba',
    })
    fig = plt.figure(figsize=(16, 9), dpi=90, constrained_layout=True)
    grid = fig.add_gridspec(1, 2, width_ratios=(1.65, 1))
    ax = fig.add_subplot(grid[0, 0])
    panel = fig.add_subplot(grid[0, 1])
    ax.set_title('COURSE MAP  |  ultrasonic echoes + steering direction', loc='left', pad=12,
                 fontsize=15, fontweight='bold')
    ax.set_xlim(extent[0], extent[2]); ax.set_ylim(extent[1], extent[3]); ax.set_aspect('equal')
    ax.grid(True, color='#26384d', linewidth=.45)
    ax.set_xlabel('X (cm)'); ax.set_ylabel('Y (cm)')
    for wall in world.data.get('walls', []):
        if wall.get('solid', True):
            a, b = wall['a'], wall['b']
            ax.plot([a[0], b[0]], [a[1], b[1]], color='#65788e',
                    linewidth=max(1.0, wall['thickness_cm']*.45), solid_capstyle='round')
    for post in world.data.get('posts', []):
        if post.get('solid', True):
            ax.add_patch(Circle(post['center'], post['radius_cm'], color='#65788e'))

    panel.set_xlim(0, 1); panel.set_ylim(0, 1); panel.axis('off')
    panel.text(.02, .975, 'LEARNED CENTERLINE • 3 LAPS', fontsize=16, fontweight='bold', va='top')
    panel.text(.02, .925, 'Ultrasonic map + clearance-weighted route', color='#8fa8c4', va='top')
    panel.text(.02, .855, 'HC-SR04 readings (cm)', fontsize=12, fontweight='bold', va='top')
    bar_y = [.80, .745, .69, .635, .58]
    for name, color, y in zip(SENSORS, COLORS, bar_y):
        panel.text(.03, y, name, color=color, fontsize=10, va='center')
        panel.add_patch(plt.Rectangle((.24, y-.012), .48, .024,
                                      color='#26384d', transform=panel.transAxes))
    value_texts = [panel.text(.75, y, '', fontsize=9, color=color, va='center', ha='right')
                   for y, color in zip(bar_y, COLORS)]
    steer_text = panel.text(.03, .505, '', fontsize=10, color='#dbe7f5', va='center')
    panel.text(.03, .445, 'RUN PROGRESS', fontsize=11, fontweight='bold', color='#8fa8c4', va='top')
    time_text = panel.text(.03, .405, '', fontsize=13, va='top')
    distance_text = panel.text(.03, .365, '', fontsize=13, va='top')
    lap_text = panel.text(.03, .325, '', fontsize=13, va='top')
    panel.plot([.03, .97], [.275, .275], color='#33465d', linewidth=1)
    panel.text(.03, .25, 'FINAL RUN RESULT', fontsize=11, fontweight='bold', color='#8fa8c4', va='top')
    panel.text(.03, .205, f"3-lap time       {result['elapsed_s']:.2f} s", fontsize=11, family='monospace', va='top')
    panel.text(.03, .165, f"Lap times        {' / '.join(f'{v:.2f}' for v in result['lap_times_s'])} s",
               fontsize=9, family='monospace', va='top')
    panel.text(.03, .125, f"Collisions {result['collisions']}   Danger {result['danger']}   Score {result['score']:.2f}",
               fontsize=10, family='monospace', va='top')
    panel.text(.03, .045, 'Map view and sensor decisions are shown separately.',
               fontsize=9, color='#8fa8c4', va='bottom')

    trail, = ax.plot([], [], color='#41e0b4', linewidth=2, alpha=.88, zorder=3)
    body = Polygon([[0, 0]]*4, closed=True, facecolor='#f4f7fb', edgecolor='#07111d',
                   linewidth=1.2, zorder=5)
    ax.add_patch(body)
    sensor_lines = [ax.plot([], [], color=color, linewidth=1.2, alpha=.8, zorder=4)[0]
                    for color in COLORS]
    chosen_line, = ax.plot([], [], color='white', linewidth=2, alpha=.95,
                           linestyle='--', zorder=4)
    ax.plot([rows[0]['x_cm']], [rows[0]['y_cm']], marker='o', color='#76e3a2', markersize=5)

    frame_indices = [i for i, row in enumerate(rows)
                     if i == 0 or int(row['time_s']) > int(rows[i-1]['time_s'])]
    if frame_indices[-1] != len(rows)-1:
        frame_indices.append(len(rows)-1)
    cumulative = [0.]
    for a, b in zip(rows, rows[1:]):
        cumulative.append(cumulative[-1] + math.hypot(b['x_cm']-a['x_cm'], b['y_cm']-a['y_cm']))

    def draw(frame):
        i = frame_indices[frame]
        row = rows[i]
        x, y, heading = row['x_cm'], row['y_cm'], row['heading_deg']
        trail.set_data([r['x_cm'] for r in rows[:i+1]], [r['y_cm'] for r in rows[:i+1]])
        body.set_xy(rectangle(x, y, heading, cfg.length_cm, cfg.width_cm))
        for name, (forward, left, angle), line in zip(SENSORS, specs.values(), sensor_lines):
            origin = local_to_world(x, y, heading, forward, left)
            dx, dy = direction(heading + angle)
            distance = row[name]
            line.set_data([origin[0], origin[0]+distance*dx], [origin[1], origin[1]+distance*dy])
        desired_heading = heading - row['Handle']*cfg.max_steer_deg/100
        dx, dy = direction(desired_heading)
        chosen_line.set_data([x, x+50*dx], [y, y+50*dy])
        for name, color, value, y0 in zip(SENSORS, COLORS, value_texts, bar_y):
            distance = row[name]
            value.set_text(f'{distance:5.1f}')
            bars = [p for p in panel.patches if p.get_gid() == name]
            if bars:
                bars[0].set_width(.48*min(1, distance/cfg.sensor_range_cm))
        command = 'LEFT' if row['Handle'] > 2 else 'RIGHT' if row['Handle'] < -2 else 'STRAIGHT'
        steer_text.set_text(f"Steering intent: {command}  ({row['Handle']:+.1f}%)")
        time_text.set_text(f"Elapsed: {row['time_s']:6.1f} / {result['elapsed_s']:.1f} s")
        distance_text.set_text(f"Distance: {cumulative[i]:7.0f} / {result['actual_distance_cm']:.0f} cm")
        lap_text.set_text(f"Lap: {min(3, int(row['lap_count'])+1)} / 3     Speed: {row['speed_cm_s']:.1f} cm/s")
        return [trail, body, *sensor_lines, chosen_line, *value_texts, steer_text,
                time_text, distance_text, lap_text]

    for name, color, y in zip(SENSORS, COLORS, bar_y):
        bar = plt.Rectangle((.24, y-.012), .48, .024, color=color, alpha=.75,
                            transform=panel.transAxes, zorder=2)
        bar.set_gid(name)
        panel.add_patch(bar)
    writer = FFMpegWriter(fps=FPS, codec='libx264', bitrate=3500,
                          extra_args=['-pix_fmt', 'yuv420p', '-movflags', '+faststart'])
    animation = FuncAnimation(fig, draw, frames=len(frame_indices), interval=1000/FPS,
                              blit=False, repeat=False)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    animation.save(output_path, writer=writer, dpi=90)
    plt.close(fig)
    print(json.dumps({'video': str(output_path.relative_to(ROOT)), 'frames': len(frame_indices),
                      'duration_s': round(len(frame_indices)/FPS, 2),
                      'source': str(trace_path.relative_to(ROOT))}, ensure_ascii=False))


if __name__ == '__main__':
    main()
