"""Ten independent safety/consistency runs for the selected 100-run candidate."""
import json
from optimization.sonar_slam.evaluate import OUT, run

cfg = {'explore': 30., 'cruise': 45., 'lookahead': 45., 'radius': 30.,
       'prior': 10., 'anchors': 100., 'sensor': {}}
results = []
for i, seed in enumerate((61, 67, 71, 73, 79, 83, 89, 97, 101, 103)):
    results.append(run(
        f'final_{i+1:02d}', noise=(0., .15, .3, .5)[i % 4], seed=seed,
        dx=(.5 if i % 3 == 0 else 0.), dy=(-.5 if i % 4 == 1 else 0.),
        dh=(.5 if i % 5 == 2 else 0.), lookahead=cfg['lookahead'],
        cruise=cfg['cruise'], radius=cfg['radius'], prior=cfg['prior'],
        anchors=cfg['anchors'], explore=cfg['explore'], sensor=cfg['sensor'],
        limit=480., control_hz=10.))
    (OUT / 'final_validation.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
