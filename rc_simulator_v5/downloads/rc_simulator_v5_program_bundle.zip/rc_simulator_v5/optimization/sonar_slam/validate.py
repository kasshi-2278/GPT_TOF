"""Ten independent final validations; no parameter changes between runs."""
import json
from pathlib import Path
from optimization.sonar_slam.evaluate import run, OUT
cases = [
    {}, {'seed':8},
    {'noise':.15,'seed':11}, {'noise':.3,'seed':13},
    {'noise':.5,'seed':17}, {'noise':.5,'seed':19},
    {'noise':.3,'seed':23,'dx':1,'dy':-1,'dh':1},
    {'noise':.3,'seed':29,'dx':-1,'dy':1,'dh':-1},
    {'noise':.5,'seed':31,'dh':.5},
    {'noise':.5,'seed':37,'dh':-.5},
]
if __name__=='__main__':
    results=[]
    for i,case in enumerate(cases,1):
        results.append(run(f'final_{i:02}', **case))
        (OUT/'final_validation.json').write_text(json.dumps(results,indent=2))
