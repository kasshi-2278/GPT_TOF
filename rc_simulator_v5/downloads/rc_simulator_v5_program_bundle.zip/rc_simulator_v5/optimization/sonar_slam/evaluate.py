"""External observer only: original collision and lap rules are unchanged."""
import argparse
import csv
import importlib.util
import json
import math
import time
import hashlib
import shutil
import resource
from pathlib import Path
import numpy as np
from config import VehicleConfig, PHYSICS_HZ
from simulation import Simulation
from world import World
from lap_timer import LapTimer
from optimization.evaluate import Metrics, user_score, ROOT
from sonar_slam_drive import Controller

OUT = ROOT/'optimization/sonar_slam'

def run(name, *, noise=0., seed=7, dx=0., dy=0., dh=0., lookahead=45., cruise=45., radius=30., prior=10., anchors=100., center_weight=0., limit=700., control_hz=10., explore=30., sensor=None):
    start = time.monotonic()
    snapshot = OUT/'versions'/name
    snapshot.mkdir(parents=True,exist_ok=True)
    hashes = {}
    for source in ('sonar_slam_drive.py','learned_navigation.py','examples/sonic_drive_smooth.py'):
        target = snapshot/source
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/source,target)
        hashes[source] = hashlib.sha256(target.read_bytes()).hexdigest()
    sim = Simulation(World.load(), VehicleConfig(sensor_noise_std_cm=noise), seed=seed, mode='manual')
    sim.car.x += dx; sim.car.y += dy; sim.car.heading += dh
    initial = (sim.car.x, sim.car.y, math.radians(sim.car.heading))
    controller = Controller(explore_accel=explore)
    sensor = sensor or {}
    for key,value in sensor.get('p',{}).items():
        if key not in controller.reactive.p: raise ValueError(f'Unknown reactive parameter: {key}')
        controller.reactive.p[key] = value
    for key,value in sensor.get('q',{}).items():
        if key not in controller.reactive.q: raise ValueError(f'Unknown gap parameter: {key}')
        controller.reactive.q[key] = value
    for key,value in sensor.get('guard',{}).items():
        attr={'target_cm':'guard_target_cm','angle_gain':'guard_angle_gain',
              'distance_gain':'guard_distance_gain','limit':'guard_limit'}.get(key)
        if attr is None: raise ValueError(f'Unknown wall guard parameter: {key}')
        setattr(controller.reactive,attr,value)
    controller.LOOKAHEAD_CM = lookahead
    controller.CRUISE_ACCEL = cruise
    controller.CLEARANCE_CM = radius
    controller.ANCHOR_SPACING_CM = anchors
    controller.CENTER_WEIGHT = center_weight
    controller.slam.scan_prior = prior
    metrics = Metrics(sim); timer = LapTimer(sim, 3)
    rows = []; errors = []; heading_errors = []; exception = None
    command = (0.,0.)
    period = round(PHYSICS_HZ/control_hz)
    try:
        for _ in range(round(limit*PHYSICS_HZ)):
            if sim.steps % period == 0:
                sim.read_sensors(); sim._sampled_step = sim.steps
                accel, handle, state = controller.step(dict(sim.sensors), period/PHYSICS_HZ)
                command = (accel,handle)
                dx0, dy0 = sim.car.x-initial[0], sim.car.y-initial[1]
                true_local = np.array((dx0*math.cos(initial[2])-dy0*math.sin(initial[2]),
                                       dx0*math.sin(initial[2])+dy0*math.cos(initial[2])))
                errors.append(float(np.linalg.norm(controller.slam.pose[:2]-true_local)))
                heading_errors.append(abs((math.degrees(controller.slam.pose[2])-sim.car.heading+math.degrees(initial[2])+180)%360-180))
            sim.step(command)
            if sim.steps % 6 == 0 or sim.collision_id:
                metrics.sample(sim); timer.sample(sim)
                row = sim.record(); row['state'] = state
                row['lap_count'] = len(timer.lap_times)
                row['clearance_cm'] = sim.world.clearance(sim.car.polygon(sim.config))
                row['estimated_x_cm'], row['estimated_y_cm'], row['estimated_heading_rad'] = controller.slam.pose
                row['phase'] = controller.phase
                row['localization_error_cm'] = errors[-1]
                rows.append(row)
            if sim.collision_id or timer.completed or metrics.stop_duration >= 5:
                break
    except Exception as error:
        exception = repr(error)
    finally:
        sim.close()
    result = dict(name=name, noise_cm=noise, seed=seed, dx=dx,dy=dy,dh=dh,
                  lookahead=lookahead,cruise=cruise,radius=radius,prior=prior,anchors=anchors,center_weight=center_weight,explore=explore,sensor=sensor,
                  completed_three_laps=timer.completed,lap_times_s=timer.lap_times,
                  elapsed_s=sim.time,collisions=int(bool(sim.collision_id)),collision=sim.collision_id,
                  danger=metrics.danger,sharp_steer=metrics.sharp,weave=metrics.weave,stops=metrics.stops,
                  min_clearance_cm=metrics.min_clearance,
                  score=user_score(timer.completed,int(bool(sim.collision_id)),metrics.danger,metrics.sharp,metrics.weave,metrics.stops,sim.time),
                  program_error=exception,phase=controller.phase,
                  loop_time_s=controller.slam.loop_time,plan_error=controller.plan_error,
                  planned_length_cm=controller.route.length if controller.route else None,
                  estimated_travel_cm=controller.slam.travel,actual_distance_cm=sim.distance,
                  localization_mean_error_cm=float(np.mean(errors)) if errors else None,
                  localization_max_error_cm=max(errors) if errors else None,
                  localization_max_heading_error_deg=max(heading_errors) if errors else None,
                  map_commands=controller.map_commands,fallback_commands=controller.fallback_commands,
                  control_hz=control_hz,controller_mean_ms=1000*controller.step_total_seconds/max(1,controller.step_count),
                  controller_max_ms=1000*controller.step_max_seconds,
                  planning_seconds=controller.route.build_seconds if controller.route else None,
                  map_array_mb=controller.slam.evidence.nbytes/1e6,
                  mapped_wall_points=len(controller.slam.points),
                  source_sha256=hashes,process_peak_rss_mb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024.,
                  final_state=locals().get('state',''),wall_seconds=time.monotonic()-start)
    OUT.mkdir(exist_ok=True)
    (OUT/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    if timer.completed and not sim.collision_id and metrics.danger==0 and not exception:
        best_path = OUT/f'best_{control_hz:g}hz.json'
        old = json.loads(best_path.read_text()) if best_path.exists() else None
        if old is None or result['score'] > old['score']:
            best_path.write_text(json.dumps(result,ensure_ascii=False,indent=2))
            shutil.copytree(snapshot,OUT/f'Best_{control_hz:g}Hz',dirs_exist_ok=True)
    if rows:
        with (OUT/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    if controller.route:
        np.save(OUT/(name+'_route.npy'),controller.route.path)
    controller.slam.save(OUT/(name+'_map.npz'))
    print(json.dumps(result,ensure_ascii=False))
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--name',default='initial')
    for key,default in [('noise',0),('lookahead',45),('cruise',45),('radius',30),('prior',10),('anchors',100),('center_weight',0),('limit',700),('control_hz',10),('explore',25)]:
        parser.add_argument('--'+key,type=float,default=default)
    args=vars(parser.parse_args()); run(**args)
