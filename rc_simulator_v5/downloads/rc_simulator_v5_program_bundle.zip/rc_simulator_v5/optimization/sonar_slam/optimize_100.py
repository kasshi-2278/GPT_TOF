"""Adaptive 100-run sensor/controller search; retains every result and best safe candidate."""
import csv,json,math,random
from pathlib import Path
from optimization.sonar_slam.evaluate import run,OUT

RNG=random.Random(1030)
NOISE=(0.,.3,.5,.15)
SEEDS=(7,13,17,23,31,37,41,47,53,59)
BASE={'explore':30.,'cruise':45.,'lookahead':45.,'radius':30.,'prior':10.,'anchors':100.,'sensor':{'p':{},'q':{},'guard':{}}}
GRID=[]
GRID.append(BASE.copy())
for speed in (50,55,60,65):
 c={**BASE,'cruise':float(speed)};GRID.append(c)
for speed in (32,34,35,36,38,40):
 c={**BASE,'explore':float(speed)};GRID.append(c)
for look in (35,40,50,55,60):
 c={**BASE,'lookahead':float(look)};GRID.append(c)
GRID.extend([
 {**BASE,'sensor':{'p':{'turn_slowdown':.35},'q':{},'guard':{}}},
 {**BASE,'sensor':{'p':{'slow_distance':80},'q':{},'guard':{}}},
 {**BASE,'sensor':{'p':{'target_cm':50},'q':{},'guard':{}}},
 {**BASE,'sensor':{'p':{},'q':{'bubble_cm':20},'guard':{}}},
 {**BASE,'sensor':{'p':{},'q':{'lookahead_cm':95},'guard':{}}},
])

def copy(c):return json.loads(json.dumps(c))
def valid(r):return bool(r['completed_three_laps'] and r['collisions']==0 and r['danger']==0 and r['program_error'] is None and r['phase']=='navigation' and not r['plan_error'])
def rank(r):return (r['elapsed_s'],r['weave'],r['sharp_steer'],r['stops'])
def clamp(x,a,b):return max(a,min(b,x))
def mutate(parent):
 c=copy(parent)
 choices=['explore','cruise','lookahead','radius','prior','anchors','p','q','guard']
 which=RNG.choices(choices,weights=[25,20,10,5,4,3,14,14,5])[0]
 if which=='explore':c['explore']=clamp(c['explore']+RNG.choice([-4,-3,-2,2,3,4]),25,48)
 elif which=='cruise':c['cruise']=clamp(c['cruise']+RNG.choice([-15,-10,-5,5,10,15]),40,75)
 elif which=='lookahead':c['lookahead']=clamp(c['lookahead']+RNG.choice([-15,-10,-5,5,10,15]),30,70)
 elif which=='radius':c['radius']=clamp(c['radius']+RNG.choice([-4,-2,2,4]),24,36)
 elif which=='prior':c['prior']=clamp(c['prior']+RNG.choice([-5,-2,2,5]),4,20)
 elif which=='anchors':c['anchors']=clamp(c['anchors']+RNG.choice([-30,-15,15,30]),70,160)
 elif which=='p':
  k=RNG.choice(['turn_slowdown','slow_distance','target_cm','angle_gain','distance_gain','turn_start','turn_release'])
  bounds={'turn_slowdown':(.25,.7),'slow_distance':(60,145),'target_cm':(35,58),'angle_gain':(2,4.5),'distance_gain':(.7,1.8),'turn_start':(120,180),'turn_release':(160,215)}[k]
  step={'turn_slowdown':.1,'slow_distance':20,'target_cm':5,'angle_gain':.5,'distance_gain':.25,'turn_start':15,'turn_release':15}[k]
  c['sensor']['p'][k]=clamp(c['sensor']['p'].get(k,{'turn_slowdown':.5,'slow_distance':100,'target_cm':44,'angle_gain':3,'distance_gain':1.2,'turn_start':150,'turn_release':185}[k])+RNG.choice([-step,step]),*bounds)
 elif which=='q':
  k=RNG.choice(['lookahead_cm','bubble_cm','gap_weight','steer_rate','local_limit','filter_s'])
  bounds={'lookahead_cm':(60,120),'bubble_cm':(15,28),'gap_weight':(.05,.4),'steer_rate':(70,140),'local_limit':(35,60),'filter_s':(.08,.35)}[k]
  step={'lookahead_cm':15,'bubble_cm':3,'gap_weight':.1,'steer_rate':15,'local_limit':5,'filter_s':.05}[k]
  base={'lookahead_cm':85,'bubble_cm':18,'gap_weight':.15,'steer_rate':100,'local_limit':50,'filter_s':.2}[k]
  c['sensor']['q'][k]=clamp(c['sensor']['q'].get(k,base)+RNG.choice([-step,step]),*bounds)
 else:
  k=RNG.choice(['target_cm','angle_gain','distance_gain','limit'])
  bounds={'target_cm':(20,40),'angle_gain':(1.5,4),'distance_gain':(.1,.8),'limit':(6,18)}[k]
  step={'target_cm':5,'angle_gain':.5,'distance_gain':.15,'limit':3}[k]
  base={'target_cm':25,'angle_gain':2.5,'distance_gain':.3,'limit':10}[k]
  c['sensor']['guard'][k]=clamp(c['sensor']['guard'].get(k,base)+RNG.choice([-step,step]),*bounds)
 return c

def main():
 outcsv=OUT/'optimization_100.csv';outjson=OUT/'optimization_100.json'
 all_rows=[];elite=[];best=None
 for prior in sorted(OUT.glob('opt100_[0-9][0-9][0-9].json')):
  saved=json.loads(prior.read_text());all_rows.append(saved)
 for saved in all_rows:
  if valid(saved):
   elite.append({'config':saved['config'],'result':saved});elite.sort(key=lambda item:rank(item['result']));elite=elite[:12]
   if best is None or rank(saved)<rank(best):best=saved
 if all_rows:print(json.dumps({'resume_after':len(all_rows),'best_elapsed_s':best['elapsed_s'] if best else None}),flush=True)
 for i in range(len(all_rows),100):
  if i<len(GRID):cfg=copy(GRID[i])
  elif len(elite)<3:cfg=mutate(copy(BASE))
  else:
   parent=copy(RNG.choice(elite[:min(8,len(elite))])['config'])
   cfg=mutate(parent)
  noise=NOISE[i%len(NOISE)];seed=SEEDS[(i//len(NOISE))%len(SEEDS)]
  result=run(f'opt100_{i+1:03}',noise=noise,seed=seed,dx=(.5 if i%11==0 else 0.),dy=(-.5 if i%13==0 else 0.),dh=(.5 if i%17==0 else 0.),
             lookahead=cfg['lookahead'],cruise=cfg['cruise'],radius=cfg['radius'],prior=cfg['prior'],anchors=cfg['anchors'],
             explore=cfg['explore'],sensor=cfg['sensor'],limit=480.,control_hz=10.)
  result['attempt']=i+1;result['config']=cfg;result['valid_fast_finish']=valid(result)
  all_rows.append(result)
  (OUT/f'opt100_{i+1:03}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
  if valid(result):
   elite.append({'config':cfg,'result':result});elite.sort(key=lambda item:rank(item['result']));elite=elite[:12]
   if best is None or rank(result)<rank(best):
    best=result
    (OUT/'best_100.json').write_text(json.dumps(best,ensure_ascii=False,indent=2))
    current=OUT/'versions'/result['name'];destination=OUT/'Best_100'
    import shutil;shutil.copytree(current,destination,dirs_exist_ok=True)
  with outcsv.open('w',newline='',encoding='utf-8-sig') as f:
   fields=['attempt','name','noise_cm','seed','explore','cruise','lookahead','radius','prior','anchors','completed_three_laps','valid_fast_finish','collisions','danger','sharp_steer','weave','stops','elapsed_s','score','loop_time_s','phase','plan_error','planned_length_cm','localization_max_error_cm','min_clearance_cm','controller_mean_ms','planning_seconds','wall_seconds']
   writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader()
   for x in all_rows:writer.writerow({**x,**x['config']})
  outjson.write_text(json.dumps({'attempts':all_rows,'best_safe_finish':best,'elite':[{'config':x['config'],'result':{k:x['result'].get(k) for k in ('name','elapsed_s','score','noise_cm','seed')}} for x in elite]},ensure_ascii=False,indent=2))
  print(json.dumps({'attempt':i+1,'valid':valid(result),'elapsed_s':result['elapsed_s'],'lap_times_s':result['lap_times_s'],'collisions':result['collisions'],'danger':result['danger'],'explore':cfg['explore'],'cruise':cfg['cruise'],'best_elapsed_s':best['elapsed_s'] if best else None,'best_name':best['name'] if best else None}),flush=True)
if __name__=='__main__':main()
