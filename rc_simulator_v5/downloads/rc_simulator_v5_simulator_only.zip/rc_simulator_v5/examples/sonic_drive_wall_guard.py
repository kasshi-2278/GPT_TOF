"""HC-SR04-only policy derived from sonic_drive_2_OK1.py.

Inputs: five distances in cm and measured cycle interval in seconds only.
No imports from the simulator; no pose, map, route, score or goal access.
Positive Handle turns left. Right-wall following gives CCW traversal.
Sensor mounts: forward (12,0), right diagonal (13,10), right side (7,10).
Side/diagonal mount positions remain provisional until physically measured.
"""
import math

PARAMS = {'filter_s': 0.08, 'target_cm': 44, 'angle_gain': 3, 'distance_gain': 1.2, 'fit_angle_limit': 55, 'gap_handle': 8, 'side_gain': 0, 'side_buffer': 25, 'diag_gain': 0, 'diag_buffer': 50, 'turn_start': 150, 'turn_release': 185, 'min_turn_s': 0.6, 'turn_handle': 100, 'protect_diag': 25, 'near_turn_limit': 100, 'emergency_front': 16, 'emergency_diag': 12, 'emergency_side': 8, 'deadband': 2, 'steer_rate': 140, 'turn_slowdown': 0.5, 'slow_distance': 100, 'base_accel': 35, 'decel_rate': 100, 'accel_rate': 20, 'mode': 'original', 'center_gain': 0.05, 'small_turn': 25}

def clamp(x,a,b):
    return max(a,min(b,x))

class PreviousController:
    def __init__(self):
        self.p=PARAMS
        self.filtered=None
        self.handle=0.0
        self.accel=0.0
        self.turn=0
        self.turn_time=0.0
        self.stopped=False
        self.last_angle=0.0
        self.wall_gap_time=0.0
        self.previous_side=None
        self.stop_reason='安全停止：測距/周期異常'

    def step(self,sensors,dt):
        names=('Fr','FrLh','RrLh','FrRh','RrRh')
        if not isinstance(dt,(float,int)) or not math.isfinite(dt) or not 0<dt<=.3:
            self.stopped=True
        if any(n not in sensors or not isinstance(sensors[n],(float,int)) or not math.isfinite(sensors[n]) or not 0<sensors[n]<=450 for n in names):
            self.stopped=True
        if self.stopped:
            self.accel=0
            return 0,self.handle,self.stop_reason
        raw=[sensors[n] for n in names]
        if raw[0]<self.p['emergency_front'] or min(raw[1],raw[3])<self.p['emergency_diag'] or min(raw[2],raw[4])<self.p['emergency_side']:
            self.stopped=True
            self.stop_reason='安全停止：接近限界'
            self.accel=0
            return 0,self.handle,'安全停止：接近限界'
        if self.filtered is None:
            self.filtered=raw[:]
        alpha=1-math.exp(-dt/self.p['filter_s'])
        self.filtered=[old+alpha*(new-old) for old,new in zip(self.filtered,raw)]
        # A nearer obstacle is never delayed by the smoothing filter.
        f,fl,sl,fr,sr=self.filtered
        if self.p.get('bridge_gaps',False):
            if self.previous_side is not None and sr>self.previous_side+self.p.get('gap_jump_cm',35):
                self.wall_gap_time+=dt
                if self.wall_gap_time<self.p.get('gap_hold_s',3):
                    sr=self.previous_side
                    # Across a missing wall, keep its prior local direction;
                    # do not fit endpoints on two unrelated walls.
                    fr=(sr+6*math.tan(math.radians(self.last_angle)))/(1/math.sqrt(2)-math.tan(math.radians(self.last_angle))/math.sqrt(2))
            else:
                self.wall_gap_time=0
            self.previous_side=sr
        forward=min(f,raw[0])
        fa=13+fr/math.sqrt(2)
        ra=10+fr/math.sqrt(2)
        fb=7
        rb=10+sr
        slope=(ra-rb)/max(6,fa-fb)
        angle=math.degrees(math.atan(slope))
        clearance=rb-slope*fb-10
        reliable=fr<245 and sr<245 and abs(angle)<self.p['fit_angle_limit'] and fr<self.p.get('gap_ratio',99)*max(sr,10)
        if reliable:
            self.last_angle=angle
            demand=-self.p['angle_gain']*angle-self.p['distance_gain']*(clearance-self.p['target_cm'])
        elif self.p.get('gap_hold',False) and fr>self.p.get('gap_ratio',2.4)*max(sr,10):
            demand=-self.p['angle_gain']*clamp(self.last_angle,-8,8)
        elif sr<180:
            demand=-self.p['distance_gain']*(sr-self.p['target_cm'])
        else:
            demand=-self.p['gap_handle']
        if self.p.get('mode','wall')=='center':
            demand=self.p.get('center_gain',.35)*(sl-sr)
            if sr>180 and sl>180:
                demand=0
        if self.p.get('mode')=='original':
            # Preserve the original ordered decision structure, but make the
            # near-wall demands continuous and cycle-time independent.
            demand=0.0
            if sl<self.p['side_buffer'] or fl<self.p['diag_buffer']:
                demand=-self.p.get('small_turn',30)
            elif sr<self.p['side_buffer'] or fr<self.p['diag_buffer']:
                demand=self.p.get('small_turn',30)
            elif abs(sl-sr)>12:
                demand=self.p.get('center_gain',.15)*(sl-sr)
        # Side protection overrides attraction to a wall across a corner.
        demand+=self.p['side_gain']*max(0,(self.p['side_buffer']-sr)/self.p['side_buffer'])
        demand-=self.p['side_gain']*max(0,(self.p['side_buffer']-sl)/self.p['side_buffer'])
        demand+=self.p['diag_gain']*max(0,(self.p['diag_buffer']-fr)/self.p['diag_buffer'])
        demand-=self.p['diag_gain']*max(0,(self.p['diag_buffer']-fl)/self.p['diag_buffer'])
        if self.turn:
            self.turn_time+=dt
            if forward>self.p['turn_release'] and self.turn_time>self.p['min_turn_s']:
                self.turn=0
        elif forward<self.p['turn_start']:
            self.turn=1 if .7*fl+.3*sl >= .7*fr+.3*sr else -1
            self.turn_time=0
        if self.turn:
            demand=self.turn*self.p['turn_handle']
            state='左回避' if self.turn>0 else '右回避'
        else:
            state='右壁追従'
        # Do not steer toward a dangerously close diagonal even during turns.
        if fr<self.p['protect_diag'] and demand<0:
            demand=max(demand,-self.p['near_turn_limit'])
        if fl<self.p['protect_diag'] and demand>0:
            demand=min(demand,self.p['near_turn_limit'])
        demand=clamp(demand,-100,100)
        if abs(demand)<self.p['deadband']:
            demand=0
        self.handle+=clamp(demand-self.handle,-self.p['steer_rate']*dt,self.p['steer_rate']*dt)
        turn_factor=1-self.p['turn_slowdown']*min(1,abs(self.handle)/100)
        front_factor=clamp((forward-self.p['emergency_front'])/self.p['slow_distance'],.15,1)
        target=self.p['base_accel']*min(turn_factor,front_factor)
        self.accel+=clamp(target-self.accel,-self.p['decel_rate']*dt,self.p['accel_rate']*dt)
        return self.accel,self.handle,state


# Divider avoidance; decisions use only the five ultrasonic distances.
class Controller(PreviousController):
    def __init__(self):
        super().__init__()
        self.p=dict(self.p)
        self.parallel_time=0.0
        self.guard_active=False
        self.guard_target_cm=25
        self.guard_angle_gain=2.5
        self.guard_distance_gain=0.3
        self.guard_limit=10
        self.guard_trust_deg=15.0
        self.guard_confirm_s=.25
        self.recent_diagonal=[250.0,250.0]

    def step(self,sensors,dt):
        previous_handle=self.handle
        names=('Fr','FrLh','RrLh','FrRh','RrRh')
        valid=all(isinstance(sensors.get(n),(int,float)) and math.isfinite(sensors[n]) and 0<sensors[n]<=450 for n in names)
        if valid:
            isolated=(sensors['FrLh']<35 and sensors['RrLh']>100) or (sensors['FrRh']<35 and sensors['RrRh']>100)
            self.p['emergency_diag']=22 if isolated else 12
        if valid and self.guard_active and self.filtered is not None and sensors["Fr"]<180:
            self.turn=1 if sensors["FrLh"]>=sensors["FrRh"] else -1
            self.turn_time=0
            self.guard_active=False
        accel,handle,state=super().step(sensors,dt)
        if self.stopped:
            return accel,handle,state
        f,fl,sl,fr,sr=self.filtered
        root_half=math.sqrt(.5)
        span=6+fr*root_half
        slope=(fr*root_half-sr)/span
        angle=math.degrees(math.atan(slope))
        clearance=sr-7*slope
        agrees=fr<240 and sr<150 and abs(angle)<self.guard_trust_deg and span>15
        corridor=sl<80 and sr<80 and fl<180 and fr<180 and f>180
        if self.turn or not agrees or f<150:
            self.guard_active=False
        self.parallel_time=self.parallel_time+dt if agrees and corridor and abs(previous_handle)<20 else 0
        if self.parallel_time>=self.guard_confirm_s:
            self.guard_active=True
        if not self.turn and self.guard_active:
            desired=-self.guard_angle_gain*angle-self.guard_distance_gain*(clearance-self.guard_target_cm)
            desired=max(-self.guard_limit,min(self.guard_limit,desired))
            self.handle=previous_handle+max(-100*dt,min(100*dt,desired-previous_handle))
            handle=self.handle
            state='仕切り壁予防：右壁の向き・離隔を保持'
        # A disappearing echo must not erase a recently seen wall end.
        left=min(sensors['FrLh'],self.recent_diagonal[0]+25*dt)
        right=min(sensors['FrRh'],self.recent_diagonal[1]+25*dt)
        self.recent_diagonal=[left,right]
        # Start lateral escape and braking before the endpoint reaches the body.
        if min(left,right)<45 and sl<100 and sr<100:
            desired=70 if right<left else -70
            self.handle=previous_handle+max(-140*dt,min(140*dt,desired-previous_handle))
            handle=self.handle
            target=max(4,min(14,(min(left,right)-12)*.45))
            self.accel=min(self.accel,target)
            accel=self.accel
            state='仕切り壁回避：斜め接近を保持して減速'
        return accel,handle,state
