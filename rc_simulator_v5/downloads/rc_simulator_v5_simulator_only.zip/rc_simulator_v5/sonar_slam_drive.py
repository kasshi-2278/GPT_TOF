"""First lap: ultrasonic mapping; later laps: learned-map localization/navigation.

Controller.step receives ONLY five HC-SR04 distances in cm and dt in seconds.
No simulator state, existing course map, timer or guide route is read.
"""
import math
import time
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from examples.sonic_drive_smooth import Controller as ReactiveController
from learned_navigation import SonarSLAM, LearnedCircuit, NAMES, wrap

MAP_NAVIGATION = 1

class Controller:
    CONTROL_PERIOD_S = .1
    EXPLORE_ACCEL = 30.
    LOOKAHEAD_CM = 45.
    CRUISE_ACCEL = 45.
    CLEARANCE_CM = 30.
    ANCHOR_SPACING_CM = 100.
    CENTER_WEIGHT = 0.

    def __init__(self, calibration=None, mounts=None, explore_accel=None):
        self.reactive = ReactiveController()
        # Exploration uses a lower corridor speed at the HC-SR04's 10 Hz
        # snapshot rate. Later laps may accelerate on the confirmed map.
        exploration = self.EXPLORE_ACCEL if explore_accel is None else explore_accel
        self.reactive.q['base_accel'] = exploration
        self.reactive.p['base_accel'] = exploration
        self.reactive.guard_distance_gain = 1.5
        self.reactive.guard_limit = 15.
        self.reactive.p['center_gain'] = 0.
        self.reactive.p['bridge_gaps'] = True
        self.reactive.p['gap_hold_s'] = 6.
        self.slam = SonarSLAM(calibration=calibration,mounts=mounts)
        self.route = None
        self.phase = 'mapping'
        self.plan_error = None
        self.output_handle = self.output_accel = 0.
        self.map_commands = self.fallback_commands = 0
        self.planner = None
        self.plan_future = None
        self.step_count = 0
        self.step_total_seconds = self.step_max_seconds = 0.
        self.fault_reason = None
        self.accumulated_dt = 0.
        self.explore_wall_heading = None
        self.last_state = '超音波地図：初回測距待ち'

    def step(self, sensors, dt):
        started = time.perf_counter()
        try:
            if not self.valid_input(sensors,dt) or self.fault_reason:
                return self._step(sensors,dt)
            self.accumulated_dt += dt
            if self.accumulated_dt < self.CONTROL_PERIOD_S-1e-8:
                return self.output_accel,self.output_handle,self.last_state
            elapsed = self.accumulated_dt
            self.accumulated_dt = 0.
            result = self._step(sensors,elapsed)
            self.last_state = result[2]
            return result
        finally:
            duration = time.perf_counter()-started
            self.step_count += 1
            self.step_total_seconds += duration
            self.step_max_seconds = max(self.step_max_seconds, duration)

    @staticmethod
    def valid_input(sensors, dt):
        if not isinstance(sensors,dict):
            return False
        valid = (isinstance(dt, (int,float)) and math.isfinite(dt) and 0 < dt <= .3 and
                 all(isinstance(sensors.get(n), (int,float)) and math.isfinite(sensors[n]) and
                     0 < sensors[n] <= 450 for n in NAMES))
        ages = sensors.get('_ages_s', {})
        valid = valid and isinstance(ages,dict) and all(
            isinstance(ages.get(n,0),(int,float)) and math.isfinite(ages.get(n,0)) and
            0 <= ages.get(n,0) <= .25 for n in NAMES)
        return valid

    def _step(self, sensors, dt):
        valid = self.valid_input(sensors,dt)
        if not valid or self.fault_reason is not None:
            self.fault_reason = 'SLAM安全停止：センサー/周期異常'
            self.slam.previous_command = (0., self.output_handle)
            self.output_accel = 0.
            return 0., self.output_handle, self.fault_reason
        self.slam.update(sensors, dt)
        if self.slam.capacity_fault:
            self.fault_reason = 'SLAM安全停止：地図の容量・範囲上限'
            self.slam.previous_command = (0., self.output_handle)
            self.output_accel = 0.
            return 0., self.output_handle, self.fault_reason
        # Keep the fallback's actuator state consistent with commands actually
        # sent while map navigation was in control.
        self.reactive.handle = self.reactive.output_handle = self.output_handle
        self.reactive.accel = self.output_accel
        self.reactive.profile_target = self.output_handle
        accel, handle, state = self.reactive.step(sensors, dt)
        if self.route is None and not self.reactive.stopped:
            gap = self.reactive.wall_gap_time
            safe = (not self.reactive.turn and sensors['Fr'] > 180 and
                    min(sensors['FrLh'],sensors['FrRh']) > 45 and
                    min(sensors['RrLh'],sensors['RrRh']) > 25)
            if gap <= dt+1e-6:
                self.explore_wall_heading = self.slam.pose[2]
            if gap > 0 and safe and self.explore_wall_heading is not None:
                demand = -3*math.degrees(wrap(self.explore_wall_heading-self.slam.pose[2]))
                demand = float(np.clip(demand,-15,15))
                handle = self.output_handle+float(np.clip(demand-self.output_handle,-100*dt,100*dt))
                state = '探索：壁の開口部で進入時の方向を保持'
        if self.reactive.stopped:
            accel = 0.
        elif (self.route is None and self.plan_future is None and self.slam.loop_closed and
              MAP_NAVIGATION and self.plan_error is None):
            # Freeze lap-one map and plotting buffers before planning lap two.
            self.slam.frozen = True
            self.slam.first_lap_trace = np.array(self.slam.trace)
            self.phase = 'planning'
            self.planner = ThreadPoolExecutor(max_workers=1, thread_name_prefix='sonar-planner')
            self.plan_future = self.planner.submit(LearnedCircuit, self.slam,
                                                   self.CLEARANCE_CM, self.ANCHOR_SPACING_CM,
                                                   self.CENTER_WEIGHT)
        if self.plan_future is not None and self.plan_future.done() and self.route is None:
            try:
                self.route = self.plan_future.result()
                self.route.index = int(self.route.tree.query(self.slam.pose[:2])[1])
                self.phase = 'navigation'
            except ValueError as error:
                self.plan_error = str(error)
                self.phase = 'map_incomplete'
            finally:
                self.planner.shutdown(wait=False)
                self.plan_future = None
        if self.route is not None and not self.reactive.stopped:
            target, route_error = self.route.target(self.slam.pose, self.LOOKAHEAD_CM)
            delta = target-self.slam.pose[:2]
            heading = self.slam.pose[2]
            right = delta[0]*math.cos(heading)-delta[1]*math.sin(heading)
            forward = delta[0]*math.sin(heading)+delta[1]*math.cos(heading)
            curvature = -2.*right/max(1., float(delta@delta))
            c = self.slam.calibration
            demand = math.degrees(math.atan(c.wheelbase_cm*curvature))/c.max_steer_deg*100.
            protected = (sensors['Fr'] < 75 or min(sensors['FrLh'],sensors['FrRh']) < 28 or
                         min(sensors['RrLh'],sensors['RrRh']) < 18 or route_error > 30 or
                         forward < 0 or self.slam.position_uncertainty_cm > 8 or
                         (self.slam.matched_rays >= 2 and self.slam.innovation_cm > 4))
            if not protected:
                handle = self.output_handle+float(np.clip(demand-self.output_handle, -100*dt, 100*dt))
                handle = float(np.clip(handle, -100., 100.))
                target_accel = self.CRUISE_ACCEL*(1.-.4*min(1.,abs(handle)/100.))
                accel = self.output_accel+float(np.clip(target_accel-self.output_accel, -100*dt, 20*dt))
                self.map_commands += 1
                state = '学習地図：自己位置推定＋短縮経路追従'
            else:
                self.fallback_commands += 1
                state = '学習地図：超音波安全回避優先：'+state
        fresh_danger = (sensors['Fr'] < 90 or min(sensors['FrLh'], sensors['FrRh']) < 30 or
                        min(sensors['RrLh'], sensors['RrRh']) < 20)
        if not self.reactive.stopped and not fresh_danger:
            accel, handle, shielded = self.slam.safe_command(accel, handle, self.output_handle, dt)
            if shielded:
                state = '超音波局所地図：予測接近回避：'+state
        self.output_handle, self.output_accel = handle, accel
        self.slam.previous_command = (accel, handle)
        x, y, h = self.slam.pose
        telemetry = (f' | phase={self.phase} | estimated_x_cm={x:.2f} | estimated_y_cm={y:.2f}'
                     f' | estimated_heading_deg={math.degrees(h):.2f} | localization={self.slam.confidence:.2f}')
        return accel, handle, state+telemetry
