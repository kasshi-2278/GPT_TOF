"""Real GPIO/PCA9685 adapter preserving the original pin/PWM assignments.

The divider-avoidance policy remains a development candidate; some runs stop safely.
Run in simulator first. No physical-car performance has been validated.
HC-SR04 readings are serialized; each successful reading updates the policy
using cached readings with a strict freshness limit. No reverse is requested.
"""
import math
import time
from examples.sonic_drive_smooth import Controller

PINS={'Fr':(15,33),'FrLh':(13,40),'RrLh':(35,37),'FrRh':(32,31),'RrRh':(36,38)}
STEERING_CHANNEL=1
THROTTLE_CHANNEL=7
STEERING_RIGHT_PWM=330
STEERING_CENTER_PWM=435
STEERING_LEFT_PWM=540
THROTTLE_FORWARD_PWM=500
THROTTLE_STOPPED_PWM=375
PING_INTERVAL_S=.06
MAX_SAMPLE_AGE_S=.5
ECHO_TIMEOUT_S=.025

def measure(gpio,trig,echo):
    gpio.output(trig,gpio.HIGH)
    time.sleep(.00001)
    gpio.output(trig,gpio.LOW)
    deadline=time.monotonic()+ECHO_TIMEOUT_S
    while gpio.input(echo)==gpio.LOW:
        if time.monotonic()>=deadline:
            raise RuntimeError('HC-SR04 Echo rise timeout')
    start=time.monotonic()
    deadline=start+ECHO_TIMEOUT_S
    while gpio.input(echo)==gpio.HIGH:
        if time.monotonic()>=deadline:
            raise RuntimeError('HC-SR04 Echo fall timeout')
    distance=(time.monotonic()-start)*34000/2
    if not math.isfinite(distance) or not 2<=distance<=400:
        raise RuntimeError('HC-SR04 distance outside 2..400cm')
    return distance

def apply(pwm,accel,handle):
    if not 0<=accel<=100 or not -100<=handle<=100:
        raise ValueError('Invalid or reverse command')
    throttle=int(THROTTLE_STOPPED_PWM+(THROTTLE_FORWARD_PWM-THROTTLE_STOPPED_PWM)*accel/100)
    steering=int(STEERING_CENTER_PWM+105*handle/100)
    pwm.set_pwm(THROTTLE_CHANNEL,0,throttle)
    pwm.set_pwm(STEERING_CHANNEL,0,steering)

def main():
    import RPi.GPIO as GPIO
    import Adafruit_PCA9685
    pwm=None
    try:
        GPIO.setmode(GPIO.BOARD)
        GPIO.cleanup()
        GPIO.setup([p[0] for p in PINS.values()],GPIO.OUT,initial=GPIO.LOW)
        GPIO.setup([p[1] for p in PINS.values()],GPIO.IN)
        pwm=Adafruit_PCA9685.PCA9685(address=0x40)
        pwm.set_pwm_freq(60)
        apply(pwm,0,0)
        input('Press Enter to start...')
        controller=Controller()
        readings={};sample_times={}
        last_control=None
        while True:
            for name,(trig,echo) in PINS.items():
                tick=time.monotonic()
                readings[name]=measure(GPIO,trig,echo)
                now=time.monotonic()
                sample_times[name]=now
                if len(readings)==5:
                    if max(now-t for t in sample_times.values())>MAX_SAMPLE_AGE_S:
                        raise RuntimeError('HC-SR04 sample is stale')
                    dt=now-last_control if last_control is not None else PING_INTERVAL_S
                    accel,handle,state=controller.step(dict(readings),dt)
                    last_control=now
                    apply(pwm,accel,handle)
                    if controller.stopped:
                        print(state)
                        return 2
                time.sleep(max(0,PING_INTERVAL_S-(time.monotonic()-tick)))
    finally:
        try:
            if pwm is not None:
                apply(pwm,0,0)
        finally:
            GPIO.cleanup()

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print('Stopped')
