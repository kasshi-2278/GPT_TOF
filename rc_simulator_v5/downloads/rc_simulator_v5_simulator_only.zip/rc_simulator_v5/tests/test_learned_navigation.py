import unittest
import math
import numpy as np
from learned_navigation import SonarSLAM, LearnedCircuit, NAMES
from sonar_slam_drive import Controller

class LearnedNavigationTests(unittest.TestCase):
    def test_no_return_noise_does_not_create_phantom_walls(self):
        slam=SonarSLAM(size=192)
        for distance in (250.,249.8,248.,245.1):
            slam.update(dict.fromkeys(NAMES,distance),.1)
        self.assertEqual(len(slam.points),0)
        self.assertFalse(np.any(slam.evidence>0))
        self.assertTrue(np.any(slam.evidence<0))

    def test_real_echo_creates_an_obstacle(self):
        slam=SonarSLAM(size=192)
        slam.update(dict.fromkeys(NAMES,70.),.1)
        self.assertEqual(len(slam.points),5)
        self.assertTrue(np.any(slam.evidence>0))

    def test_unknown_area_is_not_a_navigation_shortcut(self):
        slam=SonarSLAM(size=96)
        slam.trace=[np.array((0.,0.,0.)),np.array((40.,0.,0.)),np.array((40.,40.,0.))]
        with self.assertRaisesRegex(ValueError,'observed clearance'):
            LearnedCircuit(slam)

    def test_astar_does_not_cut_a_blocked_diagonal_corner(self):
        planner=LearnedCircuit.__new__(LearnedCircuit)
        planner.slam=SonarSLAM(size=3)
        planner.safe=np.zeros((3,3),dtype=bool)
        planner.safe[0,0]=planner.safe[1,1]=True
        self.assertIsNone(planner.astar((0,0),(1,1)))

    def test_missing_echo_stops_and_latches(self):
        controller=Controller()
        sensors=dict.fromkeys(NAMES,100.)
        sensors['Fr']=None
        self.assertEqual(controller.step(sensors,.1)[0],0.)
        self.assertEqual(controller.step(dict.fromkeys(NAMES,250.),.1)[0],0.)
        self.assertIsNotNone(controller.fault_reason)

    def test_invalid_sensor_age_stops_before_mapping(self):
        controller=Controller()
        sensors=dict.fromkeys(NAMES,100.)
        sensors['_ages_s']={'Fr':float('nan')}
        self.assertEqual(controller.step(sensors,.1)[0],0.)
        self.assertEqual(len(controller.slam.points),0)

    def test_sonar_matching_corrects_a_pose_instead_of_only_dead_reckoning(self):
        slam=SonarSLAM(size=192)
        # Generic learned rectangular-room point fixture, not the race course.
        points=[]
        for v in np.linspace(-100,100,101):
            points.extend([(v,-100),(v,100),(-100,v),(100,v)])
        slam.points={p:np.array(p,dtype=float) for p in points}
        slam.frozen=True
        slam.pose[:]=[3.,-2.,.01]
        before=np.linalg.norm(slam.pose[:2])
        sensors={'Fr':88.,'FrLh':87*math.sqrt(2),'FrRh':87*math.sqrt(2),'RrLh':90.,'RrRh':90.}
        for _ in range(20):
            slam.match(sensors)
        self.assertLess(np.linalg.norm(slam.pose[:2]),before/2)
        self.assertGreaterEqual(slam.matched_rays,2)

    def test_map_capacity_exhaustion_latches_stop(self):
        controller=Controller()
        controller.slam.pose[0]=2000.
        self.assertEqual(controller.step(dict.fromkeys(NAMES,250.),.1)[0],0.)
        self.assertTrue(controller.slam.capacity_fault)
        self.assertIsNotNone(controller.fault_reason)

if __name__=='__main__':
    unittest.main()
