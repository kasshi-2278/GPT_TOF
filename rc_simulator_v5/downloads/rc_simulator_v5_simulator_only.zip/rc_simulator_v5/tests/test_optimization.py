import ast
import math
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from examples.sonic_drive_optimized import Controller
from optimization.evaluate import Metrics, rank, user_score
from program_bridge import ProgramProcess, ProgramSpec
from sonic_drive_improved import measure

ROOT=Path(__file__).resolve().parents[1]
READINGS=dict(Fr=200,FrLh=90,RrLh=70,FrRh=80,RrRh=55)

class OptimizationTests(unittest.TestCase):
    def test_requested_score_with_actual_time(self):
        self.assertEqual(user_score(True,1,2,3,4,1,50),255)
        self.assertEqual(user_score(False,1,4,48,0,0,76.017),-896.017)

    def test_safety_selection_rejects_fast_collision(self):
        safe=dict(collisions=0,program_error=None,completed=False,danger=0,weave=0,sharp_steer=0,stops=0,score=-100)
        unsafe=dict(safe,collisions=1,completed=True,score=400)
        self.assertGreater(rank(safe),rank(unsafe))

    def test_policy_contains_no_simulator_imports(self):
        tree=ast.parse((ROOT/'examples/sonic_drive_optimized.py').read_text())
        imports=[n.names[0].name for n in ast.walk(tree) if isinstance(n,ast.Import)]
        self.assertEqual(imports,['math'])
        self.assertFalse(any(isinstance(n,ast.ImportFrom) for n in ast.walk(tree)))

    def test_invalid_measurements_stop_and_latch(self):
        for broken in (dict(READINGS,Fr=float('nan')),dict(READINGS,Fr=-1),dict(READINGS,Fr=0),{k:v for k,v in READINGS.items() if k!='RrRh'}):
            policy=Controller()
            self.assertEqual(policy.step(broken,.05)[0],0)
            self.assertEqual(policy.step(READINGS,.05)[0],0)
            self.assertTrue(policy.stopped)

    def test_direct_and_worker_outputs_match(self):
        policy=Controller()
        spec=ProgramSpec.inspect(ROOT/'examples/sonic_drive_optimized.py','function')
        with ProgramProcess(spec) as worker:
            for i in range(10):
                expected=policy.step(READINGS,.05)
                actual=worker.step(READINGS,i*.05,.05)
                self.assertEqual((actual['accel'],actual['handle']),(expected[0],expected[1]))

    def test_dead_echo_times_out_without_distance(self):
        gpio=SimpleNamespace(HIGH=1,LOW=0,output=lambda *a:None,input=lambda *a:0)
        with self.assertRaisesRegex(RuntimeError,'rise timeout'):
            measure(gpio,15,33)

    def test_danger_episode_hysteresis(self):
        class World:
            clearance_value=30
            def clearance(self,polygon):return self.clearance_value
        world=World()
        car=SimpleNamespace(x=85,y=200,heading=180,steer=0,speed=10,polygon=lambda cfg:[])
        sim=SimpleNamespace(world=world,car=car,config=None,time=0,distance=0,sensors=READINGS)
        metrics=Metrics(sim)
        for value in (9,8,12,9,15,9):
            sim.time+=.05;world.clearance_value=value;metrics.sample(sim)
        self.assertEqual(metrics.danger,2)
        self.assertFalse(metrics.completed)

if __name__=='__main__':unittest.main()
