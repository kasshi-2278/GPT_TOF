"""Sensor-only corridor and safety regressions for the gap/pursuit policy."""
import ast
import math
from pathlib import Path
import unittest
from examples.sonic_drive_gap_pursuit import Controller
from program_bridge import ProgramProcess,ProgramSpec

ROOT=Path(__file__).resolve().parents[1]
# 70 cm parallel passage: vehicle 20 cm, 25 cm free on each side.
PARALLEL=dict(Fr=250,FrLh=25*math.sqrt(2),RrLh=25,
              FrRh=25*math.sqrt(2),RrRh=25)

class GapPursuitTests(unittest.TestCase):
    def test_parallel_walls_do_not_trigger_permanent_crawling(self):
        c=Controller()
        for _ in range(60):
            accel,handle,state=c.step(PARALLEL,.05)
        self.assertIn('ピュアパシュート',state)
        self.assertGreater(accel,80)
        self.assertLess(abs(handle),1)
        self.assertFalse(c.stopped)

    def test_front_close_echo_overrides_fast_corridor(self):
        c=Controller()
        for _ in range(60):c.step(PARALLEL,.05)
        self.assertEqual(c.step(dict(PARALLEL,Fr=10),.05)[0],0)
        self.assertEqual(c.step(PARALLEL,.05)[0],0)

    def test_missing_or_invalid_reading_latches_stop(self):
        for value in (float('nan'),float('inf'),0,-1):
            c=Controller()
            for _ in range(15):c.step(PARALLEL,.05)
            self.assertEqual(c.step(dict(PARALLEL,FrRh=value),.05)[0],0)
            self.assertTrue(c.stopped)
        c=Controller();self.assertEqual(c.step({'Fr':250},.05)[0],0)

    def test_inflated_front_obstacle_excludes_straight_gap(self):
        c=Controller()
        heading=c.gap_target([20,250,100,250,100],0)
        self.assertTrue(heading is None or abs(heading)>=35)

    def test_same_outputs_in_program_worker(self):
        c=Controller()
        spec=ProgramSpec.inspect(ROOT/'examples/sonic_drive_gap_pursuit.py','function')
        with ProgramProcess(spec) as worker:
            previous=0
            for i in range(50):
                readings=dict(PARALLEL,FrLh=PARALLEL['FrLh']+.4*math.sin(i))
                accel,handle,state=c.step(readings,.05)
                result=worker.step(readings,i*.05,.05)
                self.assertEqual((result['accel'],result['handle']),(accel,handle))
                self.assertLessEqual(abs(handle-previous),5.000000001)
                previous=handle

    def test_standalone_imports_only_math(self):
        tree=ast.parse((ROOT/'examples/sonic_drive_gap_pursuit.py').read_text())
        imports=[n.names[0].name for n in ast.walk(tree) if isinstance(n,ast.Import)]
        self.assertEqual(imports,['math'])
        self.assertFalse(any(isinstance(n,ast.ImportFrom) for n in ast.walk(tree)))

if __name__=='__main__':unittest.main()
