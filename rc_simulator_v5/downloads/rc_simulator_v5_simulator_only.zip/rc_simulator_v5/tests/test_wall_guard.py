"""Regression checks for the sensor-only divider policy."""
import ast
import math
from pathlib import Path
import unittest
from examples.sonic_drive_wall_guard import Controller
from program_bridge import ProgramProcess, ProgramSpec

ROOT=Path(__file__).resolve().parents[1]
READINGS=dict(Fr=250,FrLh=90,RrLh=65,FrRh=75,RrRh=55)

class WallGuardTests(unittest.TestCase):
    def test_standalone_sensor_only_imports(self):
        tree=ast.parse((ROOT/'examples/sonic_drive_wall_guard.py').read_text())
        self.assertEqual([n.names[0].name for n in ast.walk(tree) if isinstance(n,ast.Import)],['math'])
        self.assertFalse(any(isinstance(n,ast.ImportFrom) for n in ast.walk(tree)))

    def test_invalid_input_stops_even_after_guard_activation(self):
        for bad in (dict(READINGS,Fr=float('nan')),dict(READINGS,FrLh=0),dict(READINGS,FrRh=-1),{'Fr':100}):
            c=Controller()
            for _ in range(15):c.step(READINGS,.05)
            self.assertTrue(c.guard_active)
            self.assertEqual(c.step(bad,.05)[0],0)
            self.assertEqual(c.step(READINGS,.05)[0],0)

    def test_diagonal_close_echo_is_not_erased_by_next_far_echo(self):
        c=Controller()
        c.step(dict(READINGS,FrLh=35),.05)
        c.step(READINGS,.05)
        self.assertLess(c.recent_diagonal[0],40)
        self.assertLessEqual(c.accel,14)

    def test_worker_matches_standalone_controller(self):
        c=Controller()
        with ProgramProcess(ProgramSpec.inspect(ROOT/'examples/sonic_drive_wall_guard.py','function')) as worker:
            for i in range(25):
                r=dict(READINGS,FrRh=75+2*math.sin(i))
                accel,handle,_=c.step(r,.05)
                actual=worker.step(r,i*.05,.05)
                self.assertEqual((actual['accel'],actual['handle']),(accel,handle))

if __name__=='__main__':unittest.main()
