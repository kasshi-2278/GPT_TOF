"""Sonar mapping and navigation; no simulator, map file or pose input.

The motion constants are hardware calibration estimates. Commands seed motion
prediction; point-to-line matching of actual sonar returns corrects that pose.
Coordinates start at (0, 0), facing local north, wherever the car is started.
"""
import heapq
import math
import time
from dataclasses import dataclass
import numpy as np
from scipy.ndimage import distance_transform_edt, binary_dilation
from scipy.spatial import cKDTree

NAMES = ('Fr', 'FrLh', 'RrLh', 'FrRh', 'RrRh')
MOUNTS = ((12, 0, 0), (13, 10, -45), (7, 10, -90),
          (13, -10, 45), (7, -10, 90))

def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi

@dataclass(frozen=True)
class DriveCalibration:
    forward_cm_s: float = 80.
    reverse_cm_s: float = 40.
    wheelbase_cm: float = 17.
    max_steer_deg: float = 32.
    servo_deg_s: float = 80.
    acceleration_cm_s2: float = 65.
    braking_cm_s2: float = 100.
    motor_response_s_inv: float = 5.

    def __post_init__(self):
        if any(not math.isfinite(v) or v <= 0 for v in vars(self).values()):
            raise ValueError('Drive calibration values must be positive and finite')

class SonarSLAM:
    def __init__(self, cell_cm=4., size=768, scan_prior=10., calibration=None, mounts=None):
        self.calibration = calibration or DriveCalibration()
        self.mounts = tuple(mounts) if mounts is not None else MOUNTS
        if len(self.mounts)!=5 or any(len(m)!=3 or not all(math.isfinite(v) for v in m) for m in self.mounts):
            raise ValueError('Five finite sensor mount triples are required')
        self.cell = cell_cm
        self.size = size
        self.offset = size // 2
        self.evidence = np.zeros((size, size), np.int16)
        self.pose = np.zeros(3)
        self.previous_pose = self.pose.copy()
        self.speed = self.steer = self.travel = 0.
        self.previous_command = (0., 0.)
        self.time = 0.
        self.points = {}
        self.tree = None
        self.tree_time = -10.
        self.trace = []
        self.frames = []
        self.confidence = 0.
        self.innovation_cm = 0.
        self.last_match_time = -10.
        self.position_uncertainty_cm = 2.
        self.matched_rays = 0
        self.scan_prior = scan_prior
        self.frozen = False
        self.loop_closed = False
        self.loop_time = None
        self.capacity_fault = False

    def predict(self, dt):
        # Calibratable bicycle/servo/drive response, using our own last outputs.
        accel, handle = self.previous_command
        c = self.calibration
        steps = max(1, round(dt * 120))
        d = dt / steps
        for _ in range(steps):
            target = (c.forward_cm_s if accel >= 0 else c.reverse_cm_s) * accel / 100
            limit = c.braking_cm_s2 if abs(target) < abs(self.speed) or target*self.speed < 0 else c.acceleration_cm_s2
            self.speed += max(-limit*d, min(limit*d, (target-self.speed)*min(1., c.motor_response_s_inv*d)))
            self.steer += max(-c.servo_deg_s*d, min(c.servo_deg_s*d, c.max_steer_deg*handle/100-self.steer))
            yaw = -self.speed / c.wheelbase_cm * math.tan(math.radians(self.steer))
            heading = self.pose[2] + yaw*d/2
            movement = self.speed*d
            self.pose[0] += math.sin(heading)*movement
            self.pose[1] += math.cos(heading)*movement
            self.pose[2] = wrap(self.pose[2]+yaw*d)
            self.travel += abs(movement)
            self.position_uncertainty_cm += .002*abs(movement)+.005*d
        self.time += dt

    def rays(self, sensors, pose=None):
        x, y, heading = self.pose if pose is None else pose
        sh, ch = math.sin(heading), math.cos(heading)
        for name, (forward, left, angle) in zip(NAMES, self.mounts):
            # Real sequential sensors may include their own reading ages.
            # Correct within-cycle motion using our predicted velocity only.
            age = float(sensors.get('_ages_s', {}).get(name, 0.))
            yaw = -self.speed/self.calibration.wheelbase_cm*math.tan(math.radians(self.steer))
            old_heading = heading-yaw*age
            mid = heading-yaw*age/2
            ox, oy = x-self.speed*age*math.sin(mid), y-self.speed*age*math.cos(mid)
            old_sh, old_ch = math.sin(old_heading), math.cos(old_heading)
            origin = np.array((ox+forward*old_sh-left*old_ch, oy+forward*old_ch+left*old_sh))
            a = old_heading+math.radians(angle)
            distance = sensors[name]
            end = origin + distance*np.array((math.sin(a), math.cos(a)))
            # Near-range-limit noise must not invent a wall on a no-return ray.
            yield name, origin, end, distance < 245.

    def indices(self, points):
        return np.rint(np.asarray(points)/self.cell).astype(int)+self.offset

    def match(self, sensors):
        if len(self.points) < 50:
            self.confidence = 0.
            return
        if self.tree is None or (not self.frozen and self.time-self.tree_time > .5):
            self.tree = cKDTree(np.asarray(list(self.points.values())))
            self.tree_time = self.time
        observations = [(origin, end) for _, origin, end, hit in self.rays(sensors) if hit]
        rows, errors = [], []
        for origin, endpoint in observations:
            distances, ids = self.tree.query(endpoint, k=12)
            valid = distances < 18.
            if np.sum(valid) < 6:
                continue
            neighbors = self.tree.data[ids[valid]]
            center = neighbors.mean(axis=0)
            covariance = np.cov(neighbors.T)
            values, vectors = np.linalg.eigh(covariance)
            if values[1] < 6. or values[0] > .01*values[1]:
                continue
            normal = vectors[:, 0]
            residual = float((endpoint-center) @ normal)
            if abs(residual) > 8.:
                continue
            # d(endpoint)/d(heading), in centimeters per radian.
            relative = endpoint-self.pose[:2]
            jac = np.array((normal[0], normal[1], normal @ (relative[1], -relative[0])))
            rows.append(jac)
            errors.append(residual)
        self.confidence = min(1., len(rows)/3.)
        self.matched_rays = len(rows)
        self.innovation_cm = float(np.sqrt(np.mean(np.square(errors)))) if errors else 99.
        if len(rows) >= 2:
            self.last_match_time = self.time
            A = np.asarray(rows)
            if np.linalg.svd(A[:, :2], compute_uv=False)[-1] > .2:
                self.position_uncertainty_cm = max(1.5, self.position_uncertainty_cm*.98)
            # Prediction anchors the unobservable along-wall direction.
            regularizer = np.diag((self.scan_prior, self.scan_prior, 2000.))
            delta = np.linalg.solve(A.T@A+regularizer, -A.T@np.asarray(errors))
            # Sub-centimeter wall fitting residuals are largely ray noise.
            if self.innovation_cm > 1.:
                self.pose[:2] += np.clip(delta[:2], -1., 1.)
                self.pose[2] = wrap(self.pose[2]+float(np.clip(delta[2], -.003, .003)))

    def observe(self, sensors):
        # Fixed bounds for Pi 3 / 1 GB; stop rather than silently lose geometry.
        if (len(self.points) > 20000 or len(self.trace) > 5000 or
                np.any(self.indices(self.pose[:2]) < 32) or
                np.any(self.indices(self.pose[:2]) >= self.size-32)):
            self.capacity_fault = True
            return
        if not self.frozen:
            for _, origin, end, hit in self.rays(sensors):
                distance = np.linalg.norm(end-origin)
                count = max(2, int(distance/self.cell)+1)
                samples = np.linspace(origin, end, count)
                free = self.indices(samples[:-2] if hit else samples)
                valid = np.all((free >= 0) & (free < self.size), axis=1)
                free = np.unique(free[valid], axis=0)
                self.evidence[free[:, 1], free[:, 0]] = np.maximum(-20, self.evidence[free[:, 1], free[:, 0]]-1)
                if hit:
                    ix, iy = self.indices(end)
                    if 0 <= ix < self.size and 0 <= iy < self.size:
                        self.evidence[iy, ix] = min(20, int(self.evidence[iy, ix])+4)
                    self.points[tuple(np.rint(end))] = end
        if not self.frozen and (not self.trace or np.linalg.norm(self.pose[:2]-self.trace[-1][:2]) > 8):
            self.trace.append(self.pose.copy())
            self.frames.append(tuple(sensors[n] for n in NAMES))
        # Loop closure uses the learned initial scan and relative estimated pose.
        # No timing gate or map coordinate is supplied by the simulator.
        if (not self.loop_closed and self.travel > 2500 and len(self.trace) > 100 and
                np.linalg.norm(self.pose[:2]) < 60 and abs(self.pose[2]) < 1.2):
            initial = np.array(self.frames[0])
            observed = np.array([sensors[n] for n in NAMES])
            # A wide sonar fingerprint bound allows entry at a different lateral
            # offset; scan-to-map wall alignment provides the second check.
            if (np.median(np.abs(initial-observed)) < 60 and
                    self.time-self.last_match_time < 3 and self.position_uncertainty_cm < 6):
                self.loop_closed = True
                self.loop_time = self.time

    def update(self, sensors, dt):
        self.previous_pose = self.pose.copy()
        self.predict(dt)
        self.match(sensors)
        self.observe(sensors)

    def safe_command(self, accel, desired, previous_handle, dt, margin=10.):
        """Local collision shield against remembered ultrasonic endpoints.

        Evaluate the commanded bicycle motion, not a simulator future state.
        A small post observed earlier remains relevant when it lies between rays.
        """
        if self.tree is None:
            return accel, desired, False
        demands = [desired, desired-30, desired+30, desired-60, desired+60, 0.]
        candidates = sorted(set(float(np.clip(d, -100, 100)) for d in demands),
                            key=lambda d: abs(d-desired))
        paths = []
        actual = []
        c = self.calibration
        for demand in candidates:
            demand = previous_handle+float(np.clip(demand-previous_handle, -140*dt,140*dt))
            actual.append(demand)
            x,y,h = self.pose
            speed,steer = self.speed,self.steer
            path = []
            for _ in range(15):
                speed += float(np.clip((c.forward_cm_s*accel/100-speed)*min(1.,c.motor_response_s_inv*.1),
                                      -c.braking_cm_s2*.1,c.acceleration_cm_s2*.1))
                steer += float(np.clip(c.max_steer_deg*demand/100-steer,-c.servo_deg_s*.1,c.servo_deg_s*.1))
                yaw = -speed/c.wheelbase_cm*math.tan(math.radians(steer))
                mid = h+yaw*.05
                x += math.sin(mid)*speed*.1; y += math.cos(mid)*speed*.1
                h = wrap(h+yaw*.1)
                path.append((x,y,h))
            paths.append(path)
        poses = np.asarray(paths)
        centers = poses[:,:,:2].reshape(-1,2)
        _, ids = self.tree.query(centers,k=min(12,len(self.tree.data)))
        points = self.tree.data[ids].reshape(len(paths),15,-1,2)
        differences = points-poses[:,:,:2,None].transpose(0,1,3,2)
        sh = np.sin(poses[:,:,2])[:,:,None]; ch = np.cos(poses[:,:,2])[:,:,None]
        forward = differences[:,:,:,0]*sh+differences[:,:,:,1]*ch
        left = -differences[:,:,:,0]*ch+differences[:,:,:,1]*sh
        clearances = np.sqrt(np.maximum(0,abs(forward)-14)**2+np.maximum(0,abs(left)-10)**2)
        clearance = clearances.min(axis=(1,2))
        if clearance[0] >= margin:
            return accel, desired, False
        feasible = [i for i,c in enumerate(clearance) if c>=margin]
        if feasible:
            at = min(feasible,key=lambda i:abs(actual[i]-desired))
            return accel,actual[at],True
        at = int(np.argmax(clearance))
        return min(accel,10.),actual[at],True

    def save(self, path):
        np.savez_compressed(path, evidence=self.evidence, cell_cm=self.cell,
                            offset=self.offset, wall_points=np.array(list(self.points.values())),
                            estimated_trace=np.array(self.trace))

class LearnedCircuit:
    """Plan on a learned closed circuit, optionally favoring corridor centers.

    A lap cannot be defined as 'start to start' alone (its shortest path is zero).
    The first lap's ordered anchors define traversal of the learned circuit.
    A* finds the shortest grid path BETWEEN those anchors, on observed free cells.
    """
    def __init__(self, slam, radius_cm=30., anchor_spacing=100., center_weight=0.):
        start_time = time.perf_counter()
        self.slam = slam
        occupied = slam.evidence >= 2
        self.clearance = distance_transform_edt(~occupied)*slam.cell
        seen = slam.evidence < 0
        # One-cell dilation accommodates ray/grid discretization, not unseen
        # rooms. Occupied cells and clearance still reject walls and narrow gaps.
        self.safe = binary_dilation(seen, iterations=1) & (self.clearance >= radius_cm)
        self.radius = radius_cm
        self.center_weight = max(0., float(center_weight))
        frames = getattr(slam, 'first_lap_trace', np.asarray(slam.trace))
        trace = frames[:, :2]
        selected = {0}
        distance = 0.
        for i, (a, b) in enumerate(zip(trace, trace[1:]), 1):
            distance += np.linalg.norm(b-a)
            if distance >= anchor_spacing:
                selected.add(i)
                distance = 0.
        # Preserve turn extrema learned on lap one. These are generic heading
        # changes in our local frame, not fixed course gates or coordinates.
        headings = np.unwrap(frames[:, 2])
        for i in range(3, len(trace)-3):
            before, after = headings[i-3], headings[i+3]
            if abs(after-before) < math.radians(15):
                continue
            lo, hi = sorted((before, after))
            for quarter in range(math.ceil(lo/(math.pi/4)), math.floor(hi/(math.pi/4))+1):
                target = quarter*math.pi/4
                local = np.argmin(np.abs(headings[i-3:i+4]-target))+i-3
                selected.add(int(local))
        anchors = [trace[i] for i in sorted(selected)]
        anchors.append(trace[0])
        cells = [self.nearest_safe(p) for p in anchors]
        if any(p is None for p in cells):
            raise ValueError('Insufficient observed clearance around circuit anchors')
        route = []
        for a, b in zip(cells, cells[1:]):
            segment = self.astar(a, b)
            if segment is None:
                raise ValueError('Observed free cells do not connect circuit anchors')
            # Geometric simplification can cut back to one side of a corridor;
            # retain the clearance-weighted grid path when center bias is active.
            simple = segment if self.center_weight > 0 else self.simplify(segment)
            route.extend(simple if not route else simple[1:])
        self.path = (np.array(route)-slam.offset)*slam.cell
        self.path = self.resample(self.path, 5.)
        self.length = float(np.linalg.norm(np.diff(self.path, axis=0), axis=1).sum())
        self.tree = cKDTree(self.path)
        self.index = 0
        self.completed_laps = 0
        self.build_seconds = time.perf_counter()-start_time

    def nearest_safe(self, point):
        x, y = self.slam.indices(point)
        candidates = []
        for dy in range(-5, 6):
            for dx in range(-5, 6):
                xx, yy = x+dx, y+dy
                if 0 <= xx < self.slam.size and 0 <= yy < self.slam.size and self.safe[yy, xx]:
                    candidates.append((dx*dx+dy*dy, xx, yy))
        return min(candidates)[1:] if candidates else None

    def astar(self, start, goal):
        queue = [(math.dist(start, goal), 0., start)]
        costs = {start: 0.}
        parents = {}
        while queue:
            _, cost, current = heapq.heappop(queue)
            if cost != costs[current]:
                continue
            if current == goal:
                path = [goal]
                while path[-1] != start:
                    path.append(parents[path[-1]])
                return path[::-1]
            x, y = current
            for dx, dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
                xx, yy = x+dx, y+dy
                if not (0 <= xx < self.slam.size and 0 <= yy < self.slam.size and self.safe[yy,xx]):
                    continue
                if dx and dy and not (self.safe[y, xx] and self.safe[yy, x]):
                    continue
                node = (xx, yy)
                step = math.hypot(dx,dy)
                clearance = float(self.clearance[yy,xx])
                target_clearance = self.radius + min(18., self.radius*.6)
                center_penalty = (max(0., target_clearance-clearance) /
                                  max(1., target_clearance-self.radius))**2
                new = cost+step*(1.+self.center_weight*center_penalty)
                if new < costs.get(node, math.inf):
                    costs[node] = new
                    parents[node] = current
                    heapq.heappush(queue, (new+math.dist(node, goal), new, node))
        return None

    def visible(self, a, b, minimum_clearance=None):
        n = max(2, int(math.dist(a, b)*2)+1)
        points = np.rint(np.linspace(a, b, n)).astype(int)
        safe = self.safe[points[:,1], points[:,0]]
        if minimum_clearance is not None:
            safe &= self.clearance[points[:,1], points[:,0]] >= minimum_clearance
        return bool(np.all(safe))

    def simplify(self, route, minimum_clearance=None):
        result = [route[0]]
        at = 0
        while at < len(route)-1:
            far = at+1
            for nxt in range(at+2, len(route)):
                if self.visible(route[at], route[nxt], minimum_clearance):
                    far = nxt
                else:
                    break
            result.append(route[far])
            at = far
        return result

    @staticmethod
    def resample(points, spacing):
        result = [points[0]]
        for a, b in zip(points, points[1:]):
            count = max(1, math.ceil(np.linalg.norm(b-a)/spacing))
            result.extend(np.linspace(a,b,count+1)[1:])
        return np.asarray(result)

    def target(self, pose, lookahead=45.):
        # Restrict progression to the nearby route section to avoid jumping to
        # a different straight where lanes lie close together.
        n = len(self.path)-1
        candidates = [(self.index+j) % n for j in range(-4, 16)]
        closest = min(candidates, key=lambda i: np.linalg.norm(self.path[i]-pose[:2]))
        if self.index > n-35 and closest < 35:
            self.completed_laps += 1
        self.index = closest
        at = closest
        distance = 0.
        for _ in range(n):
            nxt = (at+1) % n
            distance += np.linalg.norm(self.path[nxt]-self.path[at])
            at = nxt
            if distance >= lookahead:
                break
        return self.path[at], float(np.linalg.norm(self.path[closest]-pose[:2]))
